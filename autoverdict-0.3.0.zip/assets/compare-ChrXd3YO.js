import{j as e,V as m,b as j,f as g,R as u,r as h,g as y,c as b}from"./format-DQu_chz1.js";import"./_commonjsHelpers-Cpj98o6Y.js";const S=({cars:s,colCount:c})=>e.jsxs(e.Fragment,{children:[e.jsx("tr",{children:e.jsx("td",{className:"ct-section-header",colSpan:c,children:"Summary"})}),e.jsxs("tr",{children:[e.jsx("td",{className:"ct-label",children:"Verdict"}),s.map(t=>e.jsx("td",{children:e.jsx("span",{className:"ct-verdict",style:{color:m[t.report.verdict]},children:t.report.verdict})},t.carId))]}),e.jsxs("tr",{children:[e.jsx("td",{className:"ct-label",children:"Score"}),s.map(t=>e.jsxs("td",{children:[e.jsx("strong",{children:t.report.score}),e.jsx("div",{style:{marginTop:4},children:e.jsx("span",{className:"ct-score-bar",children:e.jsx("span",{className:"ct-score-fill",style:{width:`${Math.min(t.report.score,100)}%`}})})})]},t.carId))]})]}),v=({cars:s,colCount:c})=>e.jsxs(e.Fragment,{children:[e.jsx("tr",{children:e.jsx("td",{className:"ct-section-header",colSpan:c,children:"Specs"})}),e.jsxs("tr",{children:[e.jsx("td",{className:"ct-label",children:"Price"}),s.map(t=>e.jsx("td",{style:{fontWeight:600},children:j(t.priceWon)},t.carId))]}),e.jsxs("tr",{children:[e.jsx("td",{className:"ct-label",children:"Year"}),s.map(t=>e.jsx("td",{children:t.year??"—"},t.carId))]}),e.jsxs("tr",{children:[e.jsx("td",{className:"ct-label",children:"Mileage"}),s.map(t=>e.jsx("td",{children:g(t.mileageKm)},t.carId))]}),e.jsxs("tr",{children:[e.jsx("td",{className:"ct-label",children:"Fuel"}),s.map(t=>e.jsx("td",{children:t.fuelType??"—"},t.carId))]})]}),k={pass:"PASS",warn:"WARN",fail:"FAIL",killer:"KILLER",unknown:"—"},w={pass:"#00C853",warn:"#FFD600",fail:"#FF1744",killer:"#FF1744",unknown:"#9E9E9E"},E=({cars:s,colCount:c,allRuleIds:t})=>{const a=r=>{const o=s.map(d=>{const i=d.report.results.find(l=>l.ruleId===r);return(i==null?void 0:i.severity)??"unknown"});return new Set(o).size>1};return e.jsxs(e.Fragment,{children:[e.jsx("tr",{children:e.jsx("td",{className:"ct-section-header",colSpan:c,children:"Rules"})}),t.map(r=>{const o=a(r),d=u[r];return e.jsxs("tr",{className:o?"ct-diff":"",children:[e.jsxs("td",{className:"ct-label",children:[r," ",(d==null?void 0:d.shortTitle)??""]}),s.map(i=>{const l=i.report.results.find(x=>x.ruleId===r),p=(l==null?void 0:l.severity)??"unknown";return e.jsxs("td",{children:[e.jsx("span",{style:{color:w[p],fontWeight:700},children:k[p]}),l&&p!=="pass"&&p!=="unknown"&&e.jsx("div",{style:{fontSize:"10px",color:"#666",marginTop:2},children:l.message})]},i.carId)})]},r)})]})},F=`
.ct-table {
  width: 100%;
  border-collapse: collapse;
  font-family: 'Inter Tight', sans-serif;
  font-size: 13px;
}
.ct-table th,
.ct-table td {
  border: 2px solid #000;
  padding: 10px 14px;
  text-align: center;
  vertical-align: middle;
}
.ct-table th {
  font-family: 'Archivo Black', sans-serif;
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  background: #000;
  color: #fff;
}
.ct-label {
  font-family: 'Space Mono', monospace;
  font-size: 10px;
  letter-spacing: 1px;
  text-transform: uppercase;
  text-align: left;
  background: #f5f5f5;
  font-weight: 700;
  white-space: nowrap;
}
.ct-section-header {
  font-family: 'Archivo Black', sans-serif;
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 1.5px;
  background: #000;
  color: #CCFF00;
  text-align: left;
}
.ct-diff {
  background: #FFFDE7;
}
.ct-verdict {
  font-family: 'Archivo Black', sans-serif;
  font-size: 16px;
}
.ct-score-bar {
  display: inline-block;
  width: 80px;
  height: 8px;
  background: #e0e0e0;
  position: relative;
  vertical-align: middle;
}
.ct-score-fill {
  height: 100%;
  background: #000;
}
.ct-link {
  font-family: 'Space Mono', monospace;
  font-size: 9px;
  letter-spacing: 0.5px;
  color: #000;
}
`,I=({cars:s})=>{const c=Array.from(new Set(s.flatMap(a=>a.report.results.map(r=>r.ruleId)))).sort(),t=s.length+1;return e.jsxs("div",{style:{padding:"0 24px 48px",overflowX:"auto"},children:[e.jsx("style",{children:F}),e.jsxs("table",{className:"ct-table",children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{style:{width:"140px"}}),s.map(a=>e.jsxs("th",{children:[e.jsx("div",{children:a.title||a.carId}),e.jsx("a",{className:"ct-link",href:a.url,target:"_blank",rel:"noopener noreferrer",style:{color:"#CCFF00"},children:"엔카에서 보기 →"})]},a.carId))]})}),e.jsxs("tbody",{children:[e.jsx(S,{cars:s,colCount:t}),e.jsx(v,{cars:s,colCount:t}),e.jsx(E,{cars:s,colCount:t,allRuleIds:c})]})]})]})},N=()=>{const[s,c]=h.useState([]),[t,a]=h.useState(!0),[r,o]=h.useState(null);return h.useEffect(()=>{var l;const i=((l=new URLSearchParams(window.location.search).get("ids"))==null?void 0:l.split(",").filter(Boolean))??[];if(i.length<2){o("비교할 차량을 2대 이상 선택해 주세요."),a(!1);return}(async()=>{try{const x=(await Promise.all(i.map(n=>chrome.runtime.sendMessage({type:"GET_SAVED_ONE",carId:n})))).filter(n=>!!n);if(x.length<2){o("저장된 차량을 찾을 수 없습니다. 목록을 확인해 주세요."),a(!1);return}c(x.map(n=>({carId:n.carId,url:n.url,title:n.title,year:n.year,mileageKm:n.mileageKm,priceWon:n.priceWon,fuelType:n.fuelType,facts:n.facts,report:n.report})))}catch{o("데이터를 불러오는 중 오류가 발생했습니다.")}a(!1)})()},[]),e.jsxs("div",{style:{minHeight:"100vh",background:"#fff",color:"#000"},children:[e.jsx("style",{children:y}),e.jsx("header",{style:{padding:"24px 32px",borderBottom:"4px solid #000",fontFamily:"'Archivo Black', sans-serif",fontSize:"24px",textTransform:"uppercase",letterSpacing:"-0.5px"},children:"AutoVerdict Compare"}),t&&e.jsx("div",{style:{padding:"48px",textAlign:"center",fontFamily:"'Space Mono', monospace",fontSize:"12px",letterSpacing:"2px",textTransform:"uppercase"},children:"LOADING..."}),r&&e.jsx("div",{style:{padding:"48px",textAlign:"center",fontFamily:"'Inter Tight', sans-serif",fontSize:"14px",color:"#666"},children:r}),!t&&!r&&s.length>=2&&e.jsx(I,{cars:s})]})},f=document.getElementById("app");f&&b(f).render(e.jsx(N,{}));
