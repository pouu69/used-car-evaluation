var $t=Object.defineProperty;var Pe=t=>{throw TypeError(t)};var Lt=(t,e,s)=>e in t?$t(t,e,{enumerable:!0,configurable:!0,writable:!0,value:s}):t[e]=s;var ne=(t,e,s)=>Lt(t,typeof e!="symbol"?e+"":e,s),Be=(t,e,s)=>e.has(t)||Pe("Cannot "+s);var G=(t,e,s)=>(Be(t,e,"read from private field"),s?s.call(t):e.get(t)),K=(t,e,s)=>e.has(t)?Pe("Cannot add the same private member more than once"):e instanceof WeakSet?e.add(t):e.set(t,s),H=(t,e,s,r)=>(Be(t,e,"write to private field"),r?r.call(t,s):e.set(t,s),s);import{j as i,r as g,R as Se,a as zt,C as vt,S as Le,V as Zt,f as Vt,b as Dt,g as Pt,c as Bt}from"./format-DQu_chz1.js";import{f as yt}from"./text-DLWN4rSv.js";import{i as Ue,a as Fe,b as We}from"./protocol-aCrcEs3a.js";import{e as Ut,i as Ft}from"./url-bXCR0w-S.js";import"./_commonjsHelpers-Cpj98o6Y.js";const Wt=`당신은 엔카 중고차 베테랑 컨설턴트다. 룰 엔진 결과를 반영해 실전 조치를 짧게 쓴다.

원칙:
- killers/warns 는 희석 금지. unknown/hidden 추측 금지 → dataQualityWarnings.
- 원본에 없는 수치는 지어내지 않는다.

길이 규칙 (엄수):
- summary: **1~2문장, 120자 이내**. 결론 + 핵심 이유만.
- strengths: 최대 3개, 각 20자 이내, 명사구.
- concerns: 2~3개. title 15자 이내, detail 1문장 60자 이내.
- negotiationPoints: 3~4개, 각 40~70자. 실행 가능한 문장만. "확인하세요" 금지. 다음 중에서 섞어쓴다:
  · 문서 요구 (예: "카히스토리 출력본 요구")
  · 현장 점검 (예: "하체 리프트 후 프레임 용접 확인")
  · 가격 협상 (예: "누적 수리 180만 근거로 100만 인하 요구")
  · 계약 특약 (예: "인수 후 14일 내 중대결함 환불 특약")
- dataQualityWarnings: 최대 3개, 15자 이내. "OO 미공개" 형식.
- 모든 리스트 중요도 내림차순. 중복 통합.
- 금지어: "것으로 보입니다", "할 수 있습니다", "전반적으로", "편입니다".

출력:
- JSON 객체 하나만. 코드블록/설명/주석 금지.
- 한국어. 수치는 원문 단위(만원/km/회).
- severity: low | medium | high | critical
- verdict: BUY | NEGOTIATE | AVOID | UNKNOWN
- overallRisk: low | medium | high | critical

스키마:
{"verdict":"...","overallRisk":"...","summary":"...","strengths":[],"concerns":[{"title":"...","severity":"...","detail":"...","evidenceRuleIds":[]}],"negotiationPoints":[],"dataQualityWarnings":[]}`,Gt=t=>t&&t.kind==="value"?t.value:null,Ge=t=>typeof t=="number"&&Number.isFinite(t)?Math.round(t/1e4):null,Ke=t=>{if(t===null)return null;if(t>=1e4){const e=Math.floor(t/1e4),s=t%1e4;return s>0?`${e}억${s}만`:`${e}억`}return`${t}만`},Kt=t=>{if(!t)return"알 수 없음";const e=[],s=[t.category.manufacturerName,t.category.modelName].filter(Boolean).join(" ");s&&e.push(s);const r=t.category.gradeDetailName??t.category.gradeName;r&&e.push(r);const n=yt(t.category.yearMonth);n&&e.push(n),t.spec.mileage!==void 0&&e.push(`${t.spec.mileage.toLocaleString()}km`),t.spec.fuelName&&e.push(t.spec.fuelName),t.spec.transmissionName&&e.push(t.spec.transmissionName);const a=Ge(t.advertisement.price),o=Ge(t.category.newPrice),c=Ke(a),l=Ke(o);return c&&e.push(l?`${c}(신차 ${l})`:c),e.join("·")},Ht=t=>{switch(t.kind){case"value":return{status:"known",value:t.value};case"hidden_by_dealer":return{status:"hidden"};case"parse_failed":return{status:"failed",reason:t.reason};case"loading":case"timeout":return{status:"pending"}}},Yt=t=>{const e={},s=[],r=[],n=[["insuranceHistoryDisclosed",t.insuranceHistoryDisclosed],["inspectionReportDisclosed",t.inspectionReportDisclosed],["hasEncarDiagnosis",t.hasEncarDiagnosis],["frameDamage",t.frameDamage],["usageHistory",t.usageHistory],["totalLossHistory",t.totalLossHistory],["ownerChangeCount",t.ownerChangeCount],["insuranceGap",t.insuranceGap],["unconfirmedAccident",t.unconfirmedAccident],["minorAccidents",t.minorAccidents],["priceVsMarket",t.priceVsMarket]];for(const[a,o]of n){const c=Ht(o);c.status==="known"?e[a]=c.value:c.status==="hidden"?r.push(a):s.push(a)}return{known:e,unknown:s,hidden:r}},He=t=>({id:t.ruleId,msg:t.message}),Jt=t=>{const e=Gt(t.parsed.raw.base),s=Yt(t.facts),r={car:Kt(e),preVerified:(e==null?void 0:e.advertisement.preVerified)??null,verdict:t.report.verdict,killers:t.report.killers.map(He),warns:t.report.warns.map(He),facts:s.known,unknown:s.unknown};return s.hidden.length>0&&(r.hidden=s.hidden),t.facts.bridgeWarnings.length>0&&(r.bridgeWarnings=t.facts.bridgeWarnings),r},Xt=t=>{const e=Jt(t);return["엔카 매물을 평가. 시스템 프롬프트의 길이 규칙 준수. JSON 객체 하나만.","",`[차량] ${e.car}`,`[preVerified] ${e.preVerified??"unknown"}`,`[룰엔진 verdict] ${e.verdict}`,`[killers] ${JSON.stringify(e.killers)}`,`[warns] ${JSON.stringify(e.warns)}`,`[known facts] ${JSON.stringify(e.facts)}`,`[unknown fields] ${e.unknown.join(", ")||"(없음)"}`,e.hidden?`[hidden by dealer] ${e.hidden.join(", ")}`:"",e.bridgeWarnings?`[bridge warnings] ${e.bridgeWarnings.join("; ")}`:"","","판정:","- killers≥1 → AVOID","- warns만 → NEGOTIATE","- 깨끗하고 known 충분 → BUY","- known<50% → UNKNOWN","",'특히 negotiationPoints는 딜러와 실제로 말할 수 있는 구체적 문장으로. 단순 "확인하세요" 금지.'].filter(s=>s!=="").join(`
`)},Qt=t=>({system:Wt,user:Xt(t)});var A;(function(t){t.assertEqual=n=>{};function e(n){}t.assertIs=e;function s(n){throw new Error}t.assertNever=s,t.arrayToEnum=n=>{const a={};for(const o of n)a[o]=o;return a},t.getValidEnumValues=n=>{const a=t.objectKeys(n).filter(c=>typeof n[n[c]]!="number"),o={};for(const c of a)o[c]=n[c];return t.objectValues(o)},t.objectValues=n=>t.objectKeys(n).map(function(a){return n[a]}),t.objectKeys=typeof Object.keys=="function"?n=>Object.keys(n):n=>{const a=[];for(const o in n)Object.prototype.hasOwnProperty.call(n,o)&&a.push(o);return a},t.find=(n,a)=>{for(const o of n)if(a(o))return o},t.isInteger=typeof Number.isInteger=="function"?n=>Number.isInteger(n):n=>typeof n=="number"&&Number.isFinite(n)&&Math.floor(n)===n;function r(n,a=" | "){return n.map(o=>typeof o=="string"?`'${o}'`:o).join(a)}t.joinValues=r,t.jsonStringifyReplacer=(n,a)=>typeof a=="bigint"?a.toString():a})(A||(A={}));var Ye;(function(t){t.mergeShapes=(e,s)=>({...e,...s})})(Ye||(Ye={}));const p=A.arrayToEnum(["string","nan","number","integer","float","boolean","date","bigint","symbol","function","undefined","null","array","object","unknown","promise","void","never","map","set"]),P=t=>{switch(typeof t){case"undefined":return p.undefined;case"string":return p.string;case"number":return Number.isNaN(t)?p.nan:p.number;case"boolean":return p.boolean;case"function":return p.function;case"bigint":return p.bigint;case"symbol":return p.symbol;case"object":return Array.isArray(t)?p.array:t===null?p.null:t.then&&typeof t.then=="function"&&t.catch&&typeof t.catch=="function"?p.promise:typeof Map<"u"&&t instanceof Map?p.map:typeof Set<"u"&&t instanceof Set?p.set:typeof Date<"u"&&t instanceof Date?p.date:p.object;default:return p.unknown}},u=A.arrayToEnum(["invalid_type","invalid_literal","custom","invalid_union","invalid_union_discriminator","invalid_enum_value","unrecognized_keys","invalid_arguments","invalid_return_type","invalid_date","invalid_string","too_small","too_big","invalid_intersection_types","not_multiple_of","not_finite"]);class D extends Error{get errors(){return this.issues}constructor(e){super(),this.issues=[],this.addIssue=r=>{this.issues=[...this.issues,r]},this.addIssues=(r=[])=>{this.issues=[...this.issues,...r]};const s=new.target.prototype;Object.setPrototypeOf?Object.setPrototypeOf(this,s):this.__proto__=s,this.name="ZodError",this.issues=e}format(e){const s=e||function(a){return a.message},r={_errors:[]},n=a=>{for(const o of a.issues)if(o.code==="invalid_union")o.unionErrors.map(n);else if(o.code==="invalid_return_type")n(o.returnTypeError);else if(o.code==="invalid_arguments")n(o.argumentsError);else if(o.path.length===0)r._errors.push(s(o));else{let c=r,l=0;for(;l<o.path.length;){const d=o.path[l];l===o.path.length-1?(c[d]=c[d]||{_errors:[]},c[d]._errors.push(s(o))):c[d]=c[d]||{_errors:[]},c=c[d],l++}}};return n(this),r}static assert(e){if(!(e instanceof D))throw new Error(`Not a ZodError: ${e}`)}toString(){return this.message}get message(){return JSON.stringify(this.issues,A.jsonStringifyReplacer,2)}get isEmpty(){return this.issues.length===0}flatten(e=s=>s.message){const s={},r=[];for(const n of this.issues)if(n.path.length>0){const a=n.path[0];s[a]=s[a]||[],s[a].push(e(n))}else r.push(e(n));return{formErrors:r,fieldErrors:s}}get formErrors(){return this.flatten()}}D.create=t=>new D(t);const Ce=(t,e)=>{let s;switch(t.code){case u.invalid_type:t.received===p.undefined?s="Required":s=`Expected ${t.expected}, received ${t.received}`;break;case u.invalid_literal:s=`Invalid literal value, expected ${JSON.stringify(t.expected,A.jsonStringifyReplacer)}`;break;case u.unrecognized_keys:s=`Unrecognized key(s) in object: ${A.joinValues(t.keys,", ")}`;break;case u.invalid_union:s="Invalid input";break;case u.invalid_union_discriminator:s=`Invalid discriminator value. Expected ${A.joinValues(t.options)}`;break;case u.invalid_enum_value:s=`Invalid enum value. Expected ${A.joinValues(t.options)}, received '${t.received}'`;break;case u.invalid_arguments:s="Invalid function arguments";break;case u.invalid_return_type:s="Invalid function return type";break;case u.invalid_date:s="Invalid date";break;case u.invalid_string:typeof t.validation=="object"?"includes"in t.validation?(s=`Invalid input: must include "${t.validation.includes}"`,typeof t.validation.position=="number"&&(s=`${s} at one or more positions greater than or equal to ${t.validation.position}`)):"startsWith"in t.validation?s=`Invalid input: must start with "${t.validation.startsWith}"`:"endsWith"in t.validation?s=`Invalid input: must end with "${t.validation.endsWith}"`:A.assertNever(t.validation):t.validation!=="regex"?s=`Invalid ${t.validation}`:s="Invalid";break;case u.too_small:t.type==="array"?s=`Array must contain ${t.exact?"exactly":t.inclusive?"at least":"more than"} ${t.minimum} element(s)`:t.type==="string"?s=`String must contain ${t.exact?"exactly":t.inclusive?"at least":"over"} ${t.minimum} character(s)`:t.type==="number"?s=`Number must be ${t.exact?"exactly equal to ":t.inclusive?"greater than or equal to ":"greater than "}${t.minimum}`:t.type==="bigint"?s=`Number must be ${t.exact?"exactly equal to ":t.inclusive?"greater than or equal to ":"greater than "}${t.minimum}`:t.type==="date"?s=`Date must be ${t.exact?"exactly equal to ":t.inclusive?"greater than or equal to ":"greater than "}${new Date(Number(t.minimum))}`:s="Invalid input";break;case u.too_big:t.type==="array"?s=`Array must contain ${t.exact?"exactly":t.inclusive?"at most":"less than"} ${t.maximum} element(s)`:t.type==="string"?s=`String must contain ${t.exact?"exactly":t.inclusive?"at most":"under"} ${t.maximum} character(s)`:t.type==="number"?s=`Number must be ${t.exact?"exactly":t.inclusive?"less than or equal to":"less than"} ${t.maximum}`:t.type==="bigint"?s=`BigInt must be ${t.exact?"exactly":t.inclusive?"less than or equal to":"less than"} ${t.maximum}`:t.type==="date"?s=`Date must be ${t.exact?"exactly":t.inclusive?"smaller than or equal to":"smaller than"} ${new Date(Number(t.maximum))}`:s="Invalid input";break;case u.custom:s="Invalid input";break;case u.invalid_intersection_types:s="Intersection results could not be merged";break;case u.not_multiple_of:s=`Number must be a multiple of ${t.multipleOf}`;break;case u.not_finite:s="Number must be finite";break;default:s=e.defaultError,A.assertNever(t)}return{message:s}};let qt=Ce;function es(){return qt}const ts=t=>{const{data:e,path:s,errorMaps:r,issueData:n}=t,a=[...s,...n.path||[]],o={...n,path:a};if(n.message!==void 0)return{...n,path:a,message:n.message};let c="";const l=r.filter(d=>!!d).slice().reverse();for(const d of l)c=d(o,{data:e,defaultError:c}).message;return{...n,path:a,message:c}};function f(t,e){const s=es(),r=ts({issueData:e,data:t.data,path:t.path,errorMaps:[t.common.contextualErrorMap,t.schemaErrorMap,s,s===Ce?void 0:Ce].filter(n=>!!n)});t.common.issues.push(r)}class L{constructor(){this.value="valid"}dirty(){this.value==="valid"&&(this.value="dirty")}abort(){this.value!=="aborted"&&(this.value="aborted")}static mergeArray(e,s){const r=[];for(const n of s){if(n.status==="aborted")return v;n.status==="dirty"&&e.dirty(),r.push(n.value)}return{status:e.value,value:r}}static async mergeObjectAsync(e,s){const r=[];for(const n of s){const a=await n.key,o=await n.value;r.push({key:a,value:o})}return L.mergeObjectSync(e,r)}static mergeObjectSync(e,s){const r={};for(const n of s){const{key:a,value:o}=n;if(a.status==="aborted"||o.status==="aborted")return v;a.status==="dirty"&&e.dirty(),o.status==="dirty"&&e.dirty(),a.value!=="__proto__"&&(typeof o.value<"u"||n.alwaysSet)&&(r[a.value]=o.value)}return{status:e.value,value:r}}}const v=Object.freeze({status:"aborted"}),oe=t=>({status:"dirty",value:t}),z=t=>({status:"valid",value:t}),Je=t=>t.status==="aborted",Xe=t=>t.status==="dirty",q=t=>t.status==="valid",ke=t=>typeof Promise<"u"&&t instanceof Promise;var h;(function(t){t.errToObj=e=>typeof e=="string"?{message:e}:e||{},t.toString=e=>typeof e=="string"?e:e==null?void 0:e.message})(h||(h={}));class F{constructor(e,s,r,n){this._cachedPath=[],this.parent=e,this.data=s,this._path=r,this._key=n}get path(){return this._cachedPath.length||(Array.isArray(this._key)?this._cachedPath.push(...this._path,...this._key):this._cachedPath.push(...this._path,this._key)),this._cachedPath}}const Qe=(t,e)=>{if(q(e))return{success:!0,data:e.value};if(!t.common.issues.length)throw new Error("Validation failed but no issues detected.");return{success:!1,get error(){if(this._error)return this._error;const s=new D(t.common.issues);return this._error=s,this._error}}};function k(t){if(!t)return{};const{errorMap:e,invalid_type_error:s,required_error:r,description:n}=t;if(e&&(s||r))throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);return e?{errorMap:e,description:n}:{errorMap:(o,c)=>{const{message:l}=t;return o.code==="invalid_enum_value"?{message:l??c.defaultError}:typeof c.data>"u"?{message:l??r??c.defaultError}:o.code!=="invalid_type"?{message:c.defaultError}:{message:l??s??c.defaultError}},description:n}}class N{get description(){return this._def.description}_getType(e){return P(e.data)}_getOrReturnCtx(e,s){return s||{common:e.parent.common,data:e.data,parsedType:P(e.data),schemaErrorMap:this._def.errorMap,path:e.path,parent:e.parent}}_processInputParams(e){return{status:new L,ctx:{common:e.parent.common,data:e.data,parsedType:P(e.data),schemaErrorMap:this._def.errorMap,path:e.path,parent:e.parent}}}_parseSync(e){const s=this._parse(e);if(ke(s))throw new Error("Synchronous parse encountered promise.");return s}_parseAsync(e){const s=this._parse(e);return Promise.resolve(s)}parse(e,s){const r=this.safeParse(e,s);if(r.success)return r.data;throw r.error}safeParse(e,s){const r={common:{issues:[],async:(s==null?void 0:s.async)??!1,contextualErrorMap:s==null?void 0:s.errorMap},path:(s==null?void 0:s.path)||[],schemaErrorMap:this._def.errorMap,parent:null,data:e,parsedType:P(e)},n=this._parseSync({data:e,path:r.path,parent:r});return Qe(r,n)}"~validate"(e){var r,n;const s={common:{issues:[],async:!!this["~standard"].async},path:[],schemaErrorMap:this._def.errorMap,parent:null,data:e,parsedType:P(e)};if(!this["~standard"].async)try{const a=this._parseSync({data:e,path:[],parent:s});return q(a)?{value:a.value}:{issues:s.common.issues}}catch(a){(n=(r=a==null?void 0:a.message)==null?void 0:r.toLowerCase())!=null&&n.includes("encountered")&&(this["~standard"].async=!0),s.common={issues:[],async:!0}}return this._parseAsync({data:e,path:[],parent:s}).then(a=>q(a)?{value:a.value}:{issues:s.common.issues})}async parseAsync(e,s){const r=await this.safeParseAsync(e,s);if(r.success)return r.data;throw r.error}async safeParseAsync(e,s){const r={common:{issues:[],contextualErrorMap:s==null?void 0:s.errorMap,async:!0},path:(s==null?void 0:s.path)||[],schemaErrorMap:this._def.errorMap,parent:null,data:e,parsedType:P(e)},n=this._parse({data:e,path:r.path,parent:r}),a=await(ke(n)?n:Promise.resolve(n));return Qe(r,a)}refine(e,s){const r=n=>typeof s=="string"||typeof s>"u"?{message:s}:typeof s=="function"?s(n):s;return this._refinement((n,a)=>{const o=e(n),c=()=>a.addIssue({code:u.custom,...r(n)});return typeof Promise<"u"&&o instanceof Promise?o.then(l=>l?!0:(c(),!1)):o?!0:(c(),!1)})}refinement(e,s){return this._refinement((r,n)=>e(r)?!0:(n.addIssue(typeof s=="function"?s(r,n):s),!1))}_refinement(e){return new te({schema:this,typeName:y.ZodEffects,effect:{type:"refinement",refinement:e}})}superRefine(e){return this._refinement(e)}constructor(e){this.spa=this.safeParseAsync,this._def=e,this.parse=this.parse.bind(this),this.safeParse=this.safeParse.bind(this),this.parseAsync=this.parseAsync.bind(this),this.safeParseAsync=this.safeParseAsync.bind(this),this.spa=this.spa.bind(this),this.refine=this.refine.bind(this),this.refinement=this.refinement.bind(this),this.superRefine=this.superRefine.bind(this),this.optional=this.optional.bind(this),this.nullable=this.nullable.bind(this),this.nullish=this.nullish.bind(this),this.array=this.array.bind(this),this.promise=this.promise.bind(this),this.or=this.or.bind(this),this.and=this.and.bind(this),this.transform=this.transform.bind(this),this.brand=this.brand.bind(this),this.default=this.default.bind(this),this.catch=this.catch.bind(this),this.describe=this.describe.bind(this),this.pipe=this.pipe.bind(this),this.readonly=this.readonly.bind(this),this.isNullable=this.isNullable.bind(this),this.isOptional=this.isOptional.bind(this),this["~standard"]={version:1,vendor:"zod",validate:s=>this["~validate"](s)}}optional(){return U.create(this,this._def)}nullable(){return se.create(this,this._def)}nullish(){return this.nullable().optional()}array(){return V.create(this)}promise(){return Ae.create(this,this._def)}or(e){return Ne.create([this,e],this._def)}and(e){return je.create(this,e,this._def)}transform(e){return new te({...k(this._def),schema:this,typeName:y.ZodEffects,effect:{type:"transform",transform:e}})}default(e){const s=typeof e=="function"?e:()=>e;return new Ie({...k(this._def),innerType:this,defaultValue:s,typeName:y.ZodDefault})}brand(){return new Ns({typeName:y.ZodBranded,type:this,...k(this._def)})}catch(e){const s=typeof e=="function"?e:()=>e;return new Re({...k(this._def),innerType:this,catchValue:s,typeName:y.ZodCatch})}describe(e){const s=this.constructor;return new s({...this._def,description:e})}pipe(e){return ze.create(this,e)}readonly(){return Oe.create(this)}isOptional(){return this.safeParse(void 0).success}isNullable(){return this.safeParse(null).success}}const ss=/^c[^\s-]{8,}$/i,rs=/^[0-9a-z]+$/,ns=/^[0-9A-HJKMNP-TV-Z]{26}$/i,as=/^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i,is=/^[a-z0-9_-]{21}$/i,os=/^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/,cs=/^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/,ls=/^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i,ds="^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$";let Te;const us=/^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/,fs=/^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/,ps=/^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/,hs=/^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/,ms=/^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/,gs=/^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/,bt="((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))",xs=new RegExp(`^${bt}$`);function _t(t){let e="[0-5]\\d";t.precision?e=`${e}\\.\\d{${t.precision}}`:t.precision==null&&(e=`${e}(\\.\\d+)?`);const s=t.precision?"+":"?";return`([01]\\d|2[0-3]):[0-5]\\d(:${e})${s}`}function vs(t){return new RegExp(`^${_t(t)}$`)}function ys(t){let e=`${bt}T${_t(t)}`;const s=[];return s.push(t.local?"Z?":"Z"),t.offset&&s.push("([+-]\\d{2}:?\\d{2})"),e=`${e}(${s.join("|")})`,new RegExp(`^${e}$`)}function bs(t,e){return!!((e==="v4"||!e)&&us.test(t)||(e==="v6"||!e)&&ps.test(t))}function _s(t,e){if(!os.test(t))return!1;try{const[s]=t.split(".");if(!s)return!1;const r=s.replace(/-/g,"+").replace(/_/g,"/").padEnd(s.length+(4-s.length%4)%4,"="),n=JSON.parse(atob(r));return!(typeof n!="object"||n===null||"typ"in n&&(n==null?void 0:n.typ)!=="JWT"||!n.alg||e&&n.alg!==e)}catch{return!1}}function ks(t,e){return!!((e==="v4"||!e)&&fs.test(t)||(e==="v6"||!e)&&hs.test(t))}class B extends N{_parse(e){if(this._def.coerce&&(e.data=String(e.data)),this._getType(e)!==p.string){const a=this._getOrReturnCtx(e);return f(a,{code:u.invalid_type,expected:p.string,received:a.parsedType}),v}const r=new L;let n;for(const a of this._def.checks)if(a.kind==="min")e.data.length<a.value&&(n=this._getOrReturnCtx(e,n),f(n,{code:u.too_small,minimum:a.value,type:"string",inclusive:!0,exact:!1,message:a.message}),r.dirty());else if(a.kind==="max")e.data.length>a.value&&(n=this._getOrReturnCtx(e,n),f(n,{code:u.too_big,maximum:a.value,type:"string",inclusive:!0,exact:!1,message:a.message}),r.dirty());else if(a.kind==="length"){const o=e.data.length>a.value,c=e.data.length<a.value;(o||c)&&(n=this._getOrReturnCtx(e,n),o?f(n,{code:u.too_big,maximum:a.value,type:"string",inclusive:!0,exact:!0,message:a.message}):c&&f(n,{code:u.too_small,minimum:a.value,type:"string",inclusive:!0,exact:!0,message:a.message}),r.dirty())}else if(a.kind==="email")ls.test(e.data)||(n=this._getOrReturnCtx(e,n),f(n,{validation:"email",code:u.invalid_string,message:a.message}),r.dirty());else if(a.kind==="emoji")Te||(Te=new RegExp(ds,"u")),Te.test(e.data)||(n=this._getOrReturnCtx(e,n),f(n,{validation:"emoji",code:u.invalid_string,message:a.message}),r.dirty());else if(a.kind==="uuid")as.test(e.data)||(n=this._getOrReturnCtx(e,n),f(n,{validation:"uuid",code:u.invalid_string,message:a.message}),r.dirty());else if(a.kind==="nanoid")is.test(e.data)||(n=this._getOrReturnCtx(e,n),f(n,{validation:"nanoid",code:u.invalid_string,message:a.message}),r.dirty());else if(a.kind==="cuid")ss.test(e.data)||(n=this._getOrReturnCtx(e,n),f(n,{validation:"cuid",code:u.invalid_string,message:a.message}),r.dirty());else if(a.kind==="cuid2")rs.test(e.data)||(n=this._getOrReturnCtx(e,n),f(n,{validation:"cuid2",code:u.invalid_string,message:a.message}),r.dirty());else if(a.kind==="ulid")ns.test(e.data)||(n=this._getOrReturnCtx(e,n),f(n,{validation:"ulid",code:u.invalid_string,message:a.message}),r.dirty());else if(a.kind==="url")try{new URL(e.data)}catch{n=this._getOrReturnCtx(e,n),f(n,{validation:"url",code:u.invalid_string,message:a.message}),r.dirty()}else a.kind==="regex"?(a.regex.lastIndex=0,a.regex.test(e.data)||(n=this._getOrReturnCtx(e,n),f(n,{validation:"regex",code:u.invalid_string,message:a.message}),r.dirty())):a.kind==="trim"?e.data=e.data.trim():a.kind==="includes"?e.data.includes(a.value,a.position)||(n=this._getOrReturnCtx(e,n),f(n,{code:u.invalid_string,validation:{includes:a.value,position:a.position},message:a.message}),r.dirty()):a.kind==="toLowerCase"?e.data=e.data.toLowerCase():a.kind==="toUpperCase"?e.data=e.data.toUpperCase():a.kind==="startsWith"?e.data.startsWith(a.value)||(n=this._getOrReturnCtx(e,n),f(n,{code:u.invalid_string,validation:{startsWith:a.value},message:a.message}),r.dirty()):a.kind==="endsWith"?e.data.endsWith(a.value)||(n=this._getOrReturnCtx(e,n),f(n,{code:u.invalid_string,validation:{endsWith:a.value},message:a.message}),r.dirty()):a.kind==="datetime"?ys(a).test(e.data)||(n=this._getOrReturnCtx(e,n),f(n,{code:u.invalid_string,validation:"datetime",message:a.message}),r.dirty()):a.kind==="date"?xs.test(e.data)||(n=this._getOrReturnCtx(e,n),f(n,{code:u.invalid_string,validation:"date",message:a.message}),r.dirty()):a.kind==="time"?vs(a).test(e.data)||(n=this._getOrReturnCtx(e,n),f(n,{code:u.invalid_string,validation:"time",message:a.message}),r.dirty()):a.kind==="duration"?cs.test(e.data)||(n=this._getOrReturnCtx(e,n),f(n,{validation:"duration",code:u.invalid_string,message:a.message}),r.dirty()):a.kind==="ip"?bs(e.data,a.version)||(n=this._getOrReturnCtx(e,n),f(n,{validation:"ip",code:u.invalid_string,message:a.message}),r.dirty()):a.kind==="jwt"?_s(e.data,a.alg)||(n=this._getOrReturnCtx(e,n),f(n,{validation:"jwt",code:u.invalid_string,message:a.message}),r.dirty()):a.kind==="cidr"?ks(e.data,a.version)||(n=this._getOrReturnCtx(e,n),f(n,{validation:"cidr",code:u.invalid_string,message:a.message}),r.dirty()):a.kind==="base64"?ms.test(e.data)||(n=this._getOrReturnCtx(e,n),f(n,{validation:"base64",code:u.invalid_string,message:a.message}),r.dirty()):a.kind==="base64url"?gs.test(e.data)||(n=this._getOrReturnCtx(e,n),f(n,{validation:"base64url",code:u.invalid_string,message:a.message}),r.dirty()):A.assertNever(a);return{status:r.value,value:e.data}}_regex(e,s,r){return this.refinement(n=>e.test(n),{validation:s,code:u.invalid_string,...h.errToObj(r)})}_addCheck(e){return new B({...this._def,checks:[...this._def.checks,e]})}email(e){return this._addCheck({kind:"email",...h.errToObj(e)})}url(e){return this._addCheck({kind:"url",...h.errToObj(e)})}emoji(e){return this._addCheck({kind:"emoji",...h.errToObj(e)})}uuid(e){return this._addCheck({kind:"uuid",...h.errToObj(e)})}nanoid(e){return this._addCheck({kind:"nanoid",...h.errToObj(e)})}cuid(e){return this._addCheck({kind:"cuid",...h.errToObj(e)})}cuid2(e){return this._addCheck({kind:"cuid2",...h.errToObj(e)})}ulid(e){return this._addCheck({kind:"ulid",...h.errToObj(e)})}base64(e){return this._addCheck({kind:"base64",...h.errToObj(e)})}base64url(e){return this._addCheck({kind:"base64url",...h.errToObj(e)})}jwt(e){return this._addCheck({kind:"jwt",...h.errToObj(e)})}ip(e){return this._addCheck({kind:"ip",...h.errToObj(e)})}cidr(e){return this._addCheck({kind:"cidr",...h.errToObj(e)})}datetime(e){return typeof e=="string"?this._addCheck({kind:"datetime",precision:null,offset:!1,local:!1,message:e}):this._addCheck({kind:"datetime",precision:typeof(e==null?void 0:e.precision)>"u"?null:e==null?void 0:e.precision,offset:(e==null?void 0:e.offset)??!1,local:(e==null?void 0:e.local)??!1,...h.errToObj(e==null?void 0:e.message)})}date(e){return this._addCheck({kind:"date",message:e})}time(e){return typeof e=="string"?this._addCheck({kind:"time",precision:null,message:e}):this._addCheck({kind:"time",precision:typeof(e==null?void 0:e.precision)>"u"?null:e==null?void 0:e.precision,...h.errToObj(e==null?void 0:e.message)})}duration(e){return this._addCheck({kind:"duration",...h.errToObj(e)})}regex(e,s){return this._addCheck({kind:"regex",regex:e,...h.errToObj(s)})}includes(e,s){return this._addCheck({kind:"includes",value:e,position:s==null?void 0:s.position,...h.errToObj(s==null?void 0:s.message)})}startsWith(e,s){return this._addCheck({kind:"startsWith",value:e,...h.errToObj(s)})}endsWith(e,s){return this._addCheck({kind:"endsWith",value:e,...h.errToObj(s)})}min(e,s){return this._addCheck({kind:"min",value:e,...h.errToObj(s)})}max(e,s){return this._addCheck({kind:"max",value:e,...h.errToObj(s)})}length(e,s){return this._addCheck({kind:"length",value:e,...h.errToObj(s)})}nonempty(e){return this.min(1,h.errToObj(e))}trim(){return new B({...this._def,checks:[...this._def.checks,{kind:"trim"}]})}toLowerCase(){return new B({...this._def,checks:[...this._def.checks,{kind:"toLowerCase"}]})}toUpperCase(){return new B({...this._def,checks:[...this._def.checks,{kind:"toUpperCase"}]})}get isDatetime(){return!!this._def.checks.find(e=>e.kind==="datetime")}get isDate(){return!!this._def.checks.find(e=>e.kind==="date")}get isTime(){return!!this._def.checks.find(e=>e.kind==="time")}get isDuration(){return!!this._def.checks.find(e=>e.kind==="duration")}get isEmail(){return!!this._def.checks.find(e=>e.kind==="email")}get isURL(){return!!this._def.checks.find(e=>e.kind==="url")}get isEmoji(){return!!this._def.checks.find(e=>e.kind==="emoji")}get isUUID(){return!!this._def.checks.find(e=>e.kind==="uuid")}get isNANOID(){return!!this._def.checks.find(e=>e.kind==="nanoid")}get isCUID(){return!!this._def.checks.find(e=>e.kind==="cuid")}get isCUID2(){return!!this._def.checks.find(e=>e.kind==="cuid2")}get isULID(){return!!this._def.checks.find(e=>e.kind==="ulid")}get isIP(){return!!this._def.checks.find(e=>e.kind==="ip")}get isCIDR(){return!!this._def.checks.find(e=>e.kind==="cidr")}get isBase64(){return!!this._def.checks.find(e=>e.kind==="base64")}get isBase64url(){return!!this._def.checks.find(e=>e.kind==="base64url")}get minLength(){let e=null;for(const s of this._def.checks)s.kind==="min"&&(e===null||s.value>e)&&(e=s.value);return e}get maxLength(){let e=null;for(const s of this._def.checks)s.kind==="max"&&(e===null||s.value<e)&&(e=s.value);return e}}B.create=t=>new B({checks:[],typeName:y.ZodString,coerce:(t==null?void 0:t.coerce)??!1,...k(t)});function ws(t,e){const s=(t.toString().split(".")[1]||"").length,r=(e.toString().split(".")[1]||"").length,n=s>r?s:r,a=Number.parseInt(t.toFixed(n).replace(".","")),o=Number.parseInt(e.toFixed(n).replace(".",""));return a%o/10**n}class le extends N{constructor(){super(...arguments),this.min=this.gte,this.max=this.lte,this.step=this.multipleOf}_parse(e){if(this._def.coerce&&(e.data=Number(e.data)),this._getType(e)!==p.number){const a=this._getOrReturnCtx(e);return f(a,{code:u.invalid_type,expected:p.number,received:a.parsedType}),v}let r;const n=new L;for(const a of this._def.checks)a.kind==="int"?A.isInteger(e.data)||(r=this._getOrReturnCtx(e,r),f(r,{code:u.invalid_type,expected:"integer",received:"float",message:a.message}),n.dirty()):a.kind==="min"?(a.inclusive?e.data<a.value:e.data<=a.value)&&(r=this._getOrReturnCtx(e,r),f(r,{code:u.too_small,minimum:a.value,type:"number",inclusive:a.inclusive,exact:!1,message:a.message}),n.dirty()):a.kind==="max"?(a.inclusive?e.data>a.value:e.data>=a.value)&&(r=this._getOrReturnCtx(e,r),f(r,{code:u.too_big,maximum:a.value,type:"number",inclusive:a.inclusive,exact:!1,message:a.message}),n.dirty()):a.kind==="multipleOf"?ws(e.data,a.value)!==0&&(r=this._getOrReturnCtx(e,r),f(r,{code:u.not_multiple_of,multipleOf:a.value,message:a.message}),n.dirty()):a.kind==="finite"?Number.isFinite(e.data)||(r=this._getOrReturnCtx(e,r),f(r,{code:u.not_finite,message:a.message}),n.dirty()):A.assertNever(a);return{status:n.value,value:e.data}}gte(e,s){return this.setLimit("min",e,!0,h.toString(s))}gt(e,s){return this.setLimit("min",e,!1,h.toString(s))}lte(e,s){return this.setLimit("max",e,!0,h.toString(s))}lt(e,s){return this.setLimit("max",e,!1,h.toString(s))}setLimit(e,s,r,n){return new le({...this._def,checks:[...this._def.checks,{kind:e,value:s,inclusive:r,message:h.toString(n)}]})}_addCheck(e){return new le({...this._def,checks:[...this._def.checks,e]})}int(e){return this._addCheck({kind:"int",message:h.toString(e)})}positive(e){return this._addCheck({kind:"min",value:0,inclusive:!1,message:h.toString(e)})}negative(e){return this._addCheck({kind:"max",value:0,inclusive:!1,message:h.toString(e)})}nonpositive(e){return this._addCheck({kind:"max",value:0,inclusive:!0,message:h.toString(e)})}nonnegative(e){return this._addCheck({kind:"min",value:0,inclusive:!0,message:h.toString(e)})}multipleOf(e,s){return this._addCheck({kind:"multipleOf",value:e,message:h.toString(s)})}finite(e){return this._addCheck({kind:"finite",message:h.toString(e)})}safe(e){return this._addCheck({kind:"min",inclusive:!0,value:Number.MIN_SAFE_INTEGER,message:h.toString(e)})._addCheck({kind:"max",inclusive:!0,value:Number.MAX_SAFE_INTEGER,message:h.toString(e)})}get minValue(){let e=null;for(const s of this._def.checks)s.kind==="min"&&(e===null||s.value>e)&&(e=s.value);return e}get maxValue(){let e=null;for(const s of this._def.checks)s.kind==="max"&&(e===null||s.value<e)&&(e=s.value);return e}get isInt(){return!!this._def.checks.find(e=>e.kind==="int"||e.kind==="multipleOf"&&A.isInteger(e.value))}get isFinite(){let e=null,s=null;for(const r of this._def.checks){if(r.kind==="finite"||r.kind==="int"||r.kind==="multipleOf")return!0;r.kind==="min"?(s===null||r.value>s)&&(s=r.value):r.kind==="max"&&(e===null||r.value<e)&&(e=r.value)}return Number.isFinite(s)&&Number.isFinite(e)}}le.create=t=>new le({checks:[],typeName:y.ZodNumber,coerce:(t==null?void 0:t.coerce)||!1,...k(t)});class de extends N{constructor(){super(...arguments),this.min=this.gte,this.max=this.lte}_parse(e){if(this._def.coerce)try{e.data=BigInt(e.data)}catch{return this._getInvalidInput(e)}if(this._getType(e)!==p.bigint)return this._getInvalidInput(e);let r;const n=new L;for(const a of this._def.checks)a.kind==="min"?(a.inclusive?e.data<a.value:e.data<=a.value)&&(r=this._getOrReturnCtx(e,r),f(r,{code:u.too_small,type:"bigint",minimum:a.value,inclusive:a.inclusive,message:a.message}),n.dirty()):a.kind==="max"?(a.inclusive?e.data>a.value:e.data>=a.value)&&(r=this._getOrReturnCtx(e,r),f(r,{code:u.too_big,type:"bigint",maximum:a.value,inclusive:a.inclusive,message:a.message}),n.dirty()):a.kind==="multipleOf"?e.data%a.value!==BigInt(0)&&(r=this._getOrReturnCtx(e,r),f(r,{code:u.not_multiple_of,multipleOf:a.value,message:a.message}),n.dirty()):A.assertNever(a);return{status:n.value,value:e.data}}_getInvalidInput(e){const s=this._getOrReturnCtx(e);return f(s,{code:u.invalid_type,expected:p.bigint,received:s.parsedType}),v}gte(e,s){return this.setLimit("min",e,!0,h.toString(s))}gt(e,s){return this.setLimit("min",e,!1,h.toString(s))}lte(e,s){return this.setLimit("max",e,!0,h.toString(s))}lt(e,s){return this.setLimit("max",e,!1,h.toString(s))}setLimit(e,s,r,n){return new de({...this._def,checks:[...this._def.checks,{kind:e,value:s,inclusive:r,message:h.toString(n)}]})}_addCheck(e){return new de({...this._def,checks:[...this._def.checks,e]})}positive(e){return this._addCheck({kind:"min",value:BigInt(0),inclusive:!1,message:h.toString(e)})}negative(e){return this._addCheck({kind:"max",value:BigInt(0),inclusive:!1,message:h.toString(e)})}nonpositive(e){return this._addCheck({kind:"max",value:BigInt(0),inclusive:!0,message:h.toString(e)})}nonnegative(e){return this._addCheck({kind:"min",value:BigInt(0),inclusive:!0,message:h.toString(e)})}multipleOf(e,s){return this._addCheck({kind:"multipleOf",value:e,message:h.toString(s)})}get minValue(){let e=null;for(const s of this._def.checks)s.kind==="min"&&(e===null||s.value>e)&&(e=s.value);return e}get maxValue(){let e=null;for(const s of this._def.checks)s.kind==="max"&&(e===null||s.value<e)&&(e=s.value);return e}}de.create=t=>new de({checks:[],typeName:y.ZodBigInt,coerce:(t==null?void 0:t.coerce)??!1,...k(t)});class qe extends N{_parse(e){if(this._def.coerce&&(e.data=!!e.data),this._getType(e)!==p.boolean){const r=this._getOrReturnCtx(e);return f(r,{code:u.invalid_type,expected:p.boolean,received:r.parsedType}),v}return z(e.data)}}qe.create=t=>new qe({typeName:y.ZodBoolean,coerce:(t==null?void 0:t.coerce)||!1,...k(t)});class we extends N{_parse(e){if(this._def.coerce&&(e.data=new Date(e.data)),this._getType(e)!==p.date){const a=this._getOrReturnCtx(e);return f(a,{code:u.invalid_type,expected:p.date,received:a.parsedType}),v}if(Number.isNaN(e.data.getTime())){const a=this._getOrReturnCtx(e);return f(a,{code:u.invalid_date}),v}const r=new L;let n;for(const a of this._def.checks)a.kind==="min"?e.data.getTime()<a.value&&(n=this._getOrReturnCtx(e,n),f(n,{code:u.too_small,message:a.message,inclusive:!0,exact:!1,minimum:a.value,type:"date"}),r.dirty()):a.kind==="max"?e.data.getTime()>a.value&&(n=this._getOrReturnCtx(e,n),f(n,{code:u.too_big,message:a.message,inclusive:!0,exact:!1,maximum:a.value,type:"date"}),r.dirty()):A.assertNever(a);return{status:r.value,value:new Date(e.data.getTime())}}_addCheck(e){return new we({...this._def,checks:[...this._def.checks,e]})}min(e,s){return this._addCheck({kind:"min",value:e.getTime(),message:h.toString(s)})}max(e,s){return this._addCheck({kind:"max",value:e.getTime(),message:h.toString(s)})}get minDate(){let e=null;for(const s of this._def.checks)s.kind==="min"&&(e===null||s.value>e)&&(e=s.value);return e!=null?new Date(e):null}get maxDate(){let e=null;for(const s of this._def.checks)s.kind==="max"&&(e===null||s.value<e)&&(e=s.value);return e!=null?new Date(e):null}}we.create=t=>new we({checks:[],coerce:(t==null?void 0:t.coerce)||!1,typeName:y.ZodDate,...k(t)});class et extends N{_parse(e){if(this._getType(e)!==p.symbol){const r=this._getOrReturnCtx(e);return f(r,{code:u.invalid_type,expected:p.symbol,received:r.parsedType}),v}return z(e.data)}}et.create=t=>new et({typeName:y.ZodSymbol,...k(t)});class tt extends N{_parse(e){if(this._getType(e)!==p.undefined){const r=this._getOrReturnCtx(e);return f(r,{code:u.invalid_type,expected:p.undefined,received:r.parsedType}),v}return z(e.data)}}tt.create=t=>new tt({typeName:y.ZodUndefined,...k(t)});class st extends N{_parse(e){if(this._getType(e)!==p.null){const r=this._getOrReturnCtx(e);return f(r,{code:u.invalid_type,expected:p.null,received:r.parsedType}),v}return z(e.data)}}st.create=t=>new st({typeName:y.ZodNull,...k(t)});class rt extends N{constructor(){super(...arguments),this._any=!0}_parse(e){return z(e.data)}}rt.create=t=>new rt({typeName:y.ZodAny,...k(t)});class nt extends N{constructor(){super(...arguments),this._unknown=!0}_parse(e){return z(e.data)}}nt.create=t=>new nt({typeName:y.ZodUnknown,...k(t)});class W extends N{_parse(e){const s=this._getOrReturnCtx(e);return f(s,{code:u.invalid_type,expected:p.never,received:s.parsedType}),v}}W.create=t=>new W({typeName:y.ZodNever,...k(t)});class at extends N{_parse(e){if(this._getType(e)!==p.undefined){const r=this._getOrReturnCtx(e);return f(r,{code:u.invalid_type,expected:p.void,received:r.parsedType}),v}return z(e.data)}}at.create=t=>new at({typeName:y.ZodVoid,...k(t)});class V extends N{_parse(e){const{ctx:s,status:r}=this._processInputParams(e),n=this._def;if(s.parsedType!==p.array)return f(s,{code:u.invalid_type,expected:p.array,received:s.parsedType}),v;if(n.exactLength!==null){const o=s.data.length>n.exactLength.value,c=s.data.length<n.exactLength.value;(o||c)&&(f(s,{code:o?u.too_big:u.too_small,minimum:c?n.exactLength.value:void 0,maximum:o?n.exactLength.value:void 0,type:"array",inclusive:!0,exact:!0,message:n.exactLength.message}),r.dirty())}if(n.minLength!==null&&s.data.length<n.minLength.value&&(f(s,{code:u.too_small,minimum:n.minLength.value,type:"array",inclusive:!0,exact:!1,message:n.minLength.message}),r.dirty()),n.maxLength!==null&&s.data.length>n.maxLength.value&&(f(s,{code:u.too_big,maximum:n.maxLength.value,type:"array",inclusive:!0,exact:!1,message:n.maxLength.message}),r.dirty()),s.common.async)return Promise.all([...s.data].map((o,c)=>n.type._parseAsync(new F(s,o,s.path,c)))).then(o=>L.mergeArray(r,o));const a=[...s.data].map((o,c)=>n.type._parseSync(new F(s,o,s.path,c)));return L.mergeArray(r,a)}get element(){return this._def.type}min(e,s){return new V({...this._def,minLength:{value:e,message:h.toString(s)}})}max(e,s){return new V({...this._def,maxLength:{value:e,message:h.toString(s)}})}length(e,s){return new V({...this._def,exactLength:{value:e,message:h.toString(s)}})}nonempty(e){return this.min(1,e)}}V.create=(t,e)=>new V({type:t,minLength:null,maxLength:null,exactLength:null,typeName:y.ZodArray,...k(e)});function Q(t){if(t instanceof I){const e={};for(const s in t.shape){const r=t.shape[s];e[s]=U.create(Q(r))}return new I({...t._def,shape:()=>e})}else return t instanceof V?new V({...t._def,type:Q(t.element)}):t instanceof U?U.create(Q(t.unwrap())):t instanceof se?se.create(Q(t.unwrap())):t instanceof J?J.create(t.items.map(e=>Q(e))):t}class I extends N{constructor(){super(...arguments),this._cached=null,this.nonstrict=this.passthrough,this.augment=this.extend}_getCached(){if(this._cached!==null)return this._cached;const e=this._def.shape(),s=A.objectKeys(e);return this._cached={shape:e,keys:s},this._cached}_parse(e){if(this._getType(e)!==p.object){const d=this._getOrReturnCtx(e);return f(d,{code:u.invalid_type,expected:p.object,received:d.parsedType}),v}const{status:r,ctx:n}=this._processInputParams(e),{shape:a,keys:o}=this._getCached(),c=[];if(!(this._def.catchall instanceof W&&this._def.unknownKeys==="strip"))for(const d in n.data)o.includes(d)||c.push(d);const l=[];for(const d of o){const m=a[d],_=n.data[d];l.push({key:{status:"valid",value:d},value:m._parse(new F(n,_,n.path,d)),alwaysSet:d in n.data})}if(this._def.catchall instanceof W){const d=this._def.unknownKeys;if(d==="passthrough")for(const m of c)l.push({key:{status:"valid",value:m},value:{status:"valid",value:n.data[m]}});else if(d==="strict")c.length>0&&(f(n,{code:u.unrecognized_keys,keys:c}),r.dirty());else if(d!=="strip")throw new Error("Internal ZodObject error: invalid unknownKeys value.")}else{const d=this._def.catchall;for(const m of c){const _=n.data[m];l.push({key:{status:"valid",value:m},value:d._parse(new F(n,_,n.path,m)),alwaysSet:m in n.data})}}return n.common.async?Promise.resolve().then(async()=>{const d=[];for(const m of l){const _=await m.key,w=await m.value;d.push({key:_,value:w,alwaysSet:m.alwaysSet})}return d}).then(d=>L.mergeObjectSync(r,d)):L.mergeObjectSync(r,l)}get shape(){return this._def.shape()}strict(e){return h.errToObj,new I({...this._def,unknownKeys:"strict",...e!==void 0?{errorMap:(s,r)=>{var a,o;const n=((o=(a=this._def).errorMap)==null?void 0:o.call(a,s,r).message)??r.defaultError;return s.code==="unrecognized_keys"?{message:h.errToObj(e).message??n}:{message:n}}}:{}})}strip(){return new I({...this._def,unknownKeys:"strip"})}passthrough(){return new I({...this._def,unknownKeys:"passthrough"})}extend(e){return new I({...this._def,shape:()=>({...this._def.shape(),...e})})}merge(e){return new I({unknownKeys:e._def.unknownKeys,catchall:e._def.catchall,shape:()=>({...this._def.shape(),...e._def.shape()}),typeName:y.ZodObject})}setKey(e,s){return this.augment({[e]:s})}catchall(e){return new I({...this._def,catchall:e})}pick(e){const s={};for(const r of A.objectKeys(e))e[r]&&this.shape[r]&&(s[r]=this.shape[r]);return new I({...this._def,shape:()=>s})}omit(e){const s={};for(const r of A.objectKeys(this.shape))e[r]||(s[r]=this.shape[r]);return new I({...this._def,shape:()=>s})}deepPartial(){return Q(this)}partial(e){const s={};for(const r of A.objectKeys(this.shape)){const n=this.shape[r];e&&!e[r]?s[r]=n:s[r]=n.optional()}return new I({...this._def,shape:()=>s})}required(e){const s={};for(const r of A.objectKeys(this.shape))if(e&&!e[r])s[r]=this.shape[r];else{let a=this.shape[r];for(;a instanceof U;)a=a._def.innerType;s[r]=a}return new I({...this._def,shape:()=>s})}keyof(){return kt(A.objectKeys(this.shape))}}I.create=(t,e)=>new I({shape:()=>t,unknownKeys:"strip",catchall:W.create(),typeName:y.ZodObject,...k(e)});I.strictCreate=(t,e)=>new I({shape:()=>t,unknownKeys:"strict",catchall:W.create(),typeName:y.ZodObject,...k(e)});I.lazycreate=(t,e)=>new I({shape:t,unknownKeys:"strip",catchall:W.create(),typeName:y.ZodObject,...k(e)});class Ne extends N{_parse(e){const{ctx:s}=this._processInputParams(e),r=this._def.options;function n(a){for(const c of a)if(c.result.status==="valid")return c.result;for(const c of a)if(c.result.status==="dirty")return s.common.issues.push(...c.ctx.common.issues),c.result;const o=a.map(c=>new D(c.ctx.common.issues));return f(s,{code:u.invalid_union,unionErrors:o}),v}if(s.common.async)return Promise.all(r.map(async a=>{const o={...s,common:{...s.common,issues:[]},parent:null};return{result:await a._parseAsync({data:s.data,path:s.path,parent:o}),ctx:o}})).then(n);{let a;const o=[];for(const l of r){const d={...s,common:{...s.common,issues:[]},parent:null},m=l._parseSync({data:s.data,path:s.path,parent:d});if(m.status==="valid")return m;m.status==="dirty"&&!a&&(a={result:m,ctx:d}),d.common.issues.length&&o.push(d.common.issues)}if(a)return s.common.issues.push(...a.ctx.common.issues),a.result;const c=o.map(l=>new D(l));return f(s,{code:u.invalid_union,unionErrors:c}),v}}get options(){return this._def.options}}Ne.create=(t,e)=>new Ne({options:t,typeName:y.ZodUnion,...k(e)});function Ee(t,e){const s=P(t),r=P(e);if(t===e)return{valid:!0,data:t};if(s===p.object&&r===p.object){const n=A.objectKeys(e),a=A.objectKeys(t).filter(c=>n.indexOf(c)!==-1),o={...t,...e};for(const c of a){const l=Ee(t[c],e[c]);if(!l.valid)return{valid:!1};o[c]=l.data}return{valid:!0,data:o}}else if(s===p.array&&r===p.array){if(t.length!==e.length)return{valid:!1};const n=[];for(let a=0;a<t.length;a++){const o=t[a],c=e[a],l=Ee(o,c);if(!l.valid)return{valid:!1};n.push(l.data)}return{valid:!0,data:n}}else return s===p.date&&r===p.date&&+t==+e?{valid:!0,data:t}:{valid:!1}}class je extends N{_parse(e){const{status:s,ctx:r}=this._processInputParams(e),n=(a,o)=>{if(Je(a)||Je(o))return v;const c=Ee(a.value,o.value);return c.valid?((Xe(a)||Xe(o))&&s.dirty(),{status:s.value,value:c.data}):(f(r,{code:u.invalid_intersection_types}),v)};return r.common.async?Promise.all([this._def.left._parseAsync({data:r.data,path:r.path,parent:r}),this._def.right._parseAsync({data:r.data,path:r.path,parent:r})]).then(([a,o])=>n(a,o)):n(this._def.left._parseSync({data:r.data,path:r.path,parent:r}),this._def.right._parseSync({data:r.data,path:r.path,parent:r}))}}je.create=(t,e,s)=>new je({left:t,right:e,typeName:y.ZodIntersection,...k(s)});class J extends N{_parse(e){const{status:s,ctx:r}=this._processInputParams(e);if(r.parsedType!==p.array)return f(r,{code:u.invalid_type,expected:p.array,received:r.parsedType}),v;if(r.data.length<this._def.items.length)return f(r,{code:u.too_small,minimum:this._def.items.length,inclusive:!0,exact:!1,type:"array"}),v;!this._def.rest&&r.data.length>this._def.items.length&&(f(r,{code:u.too_big,maximum:this._def.items.length,inclusive:!0,exact:!1,type:"array"}),s.dirty());const a=[...r.data].map((o,c)=>{const l=this._def.items[c]||this._def.rest;return l?l._parse(new F(r,o,r.path,c)):null}).filter(o=>!!o);return r.common.async?Promise.all(a).then(o=>L.mergeArray(s,o)):L.mergeArray(s,a)}get items(){return this._def.items}rest(e){return new J({...this._def,rest:e})}}J.create=(t,e)=>{if(!Array.isArray(t))throw new Error("You must pass an array of schemas to z.tuple([ ... ])");return new J({items:t,typeName:y.ZodTuple,rest:null,...k(e)})};class it extends N{get keySchema(){return this._def.keyType}get valueSchema(){return this._def.valueType}_parse(e){const{status:s,ctx:r}=this._processInputParams(e);if(r.parsedType!==p.map)return f(r,{code:u.invalid_type,expected:p.map,received:r.parsedType}),v;const n=this._def.keyType,a=this._def.valueType,o=[...r.data.entries()].map(([c,l],d)=>({key:n._parse(new F(r,c,r.path,[d,"key"])),value:a._parse(new F(r,l,r.path,[d,"value"]))}));if(r.common.async){const c=new Map;return Promise.resolve().then(async()=>{for(const l of o){const d=await l.key,m=await l.value;if(d.status==="aborted"||m.status==="aborted")return v;(d.status==="dirty"||m.status==="dirty")&&s.dirty(),c.set(d.value,m.value)}return{status:s.value,value:c}})}else{const c=new Map;for(const l of o){const d=l.key,m=l.value;if(d.status==="aborted"||m.status==="aborted")return v;(d.status==="dirty"||m.status==="dirty")&&s.dirty(),c.set(d.value,m.value)}return{status:s.value,value:c}}}}it.create=(t,e,s)=>new it({valueType:e,keyType:t,typeName:y.ZodMap,...k(s)});class ue extends N{_parse(e){const{status:s,ctx:r}=this._processInputParams(e);if(r.parsedType!==p.set)return f(r,{code:u.invalid_type,expected:p.set,received:r.parsedType}),v;const n=this._def;n.minSize!==null&&r.data.size<n.minSize.value&&(f(r,{code:u.too_small,minimum:n.minSize.value,type:"set",inclusive:!0,exact:!1,message:n.minSize.message}),s.dirty()),n.maxSize!==null&&r.data.size>n.maxSize.value&&(f(r,{code:u.too_big,maximum:n.maxSize.value,type:"set",inclusive:!0,exact:!1,message:n.maxSize.message}),s.dirty());const a=this._def.valueType;function o(l){const d=new Set;for(const m of l){if(m.status==="aborted")return v;m.status==="dirty"&&s.dirty(),d.add(m.value)}return{status:s.value,value:d}}const c=[...r.data.values()].map((l,d)=>a._parse(new F(r,l,r.path,d)));return r.common.async?Promise.all(c).then(l=>o(l)):o(c)}min(e,s){return new ue({...this._def,minSize:{value:e,message:h.toString(s)}})}max(e,s){return new ue({...this._def,maxSize:{value:e,message:h.toString(s)}})}size(e,s){return this.min(e,s).max(e,s)}nonempty(e){return this.min(1,e)}}ue.create=(t,e)=>new ue({valueType:t,minSize:null,maxSize:null,typeName:y.ZodSet,...k(e)});class ot extends N{get schema(){return this._def.getter()}_parse(e){const{ctx:s}=this._processInputParams(e);return this._def.getter()._parse({data:s.data,path:s.path,parent:s})}}ot.create=(t,e)=>new ot({getter:t,typeName:y.ZodLazy,...k(e)});class ct extends N{_parse(e){if(e.data!==this._def.value){const s=this._getOrReturnCtx(e);return f(s,{received:s.data,code:u.invalid_literal,expected:this._def.value}),v}return{status:"valid",value:e.data}}get value(){return this._def.value}}ct.create=(t,e)=>new ct({value:t,typeName:y.ZodLiteral,...k(e)});function kt(t,e){return new ee({values:t,typeName:y.ZodEnum,...k(e)})}class ee extends N{_parse(e){if(typeof e.data!="string"){const s=this._getOrReturnCtx(e),r=this._def.values;return f(s,{expected:A.joinValues(r),received:s.parsedType,code:u.invalid_type}),v}if(this._cache||(this._cache=new Set(this._def.values)),!this._cache.has(e.data)){const s=this._getOrReturnCtx(e),r=this._def.values;return f(s,{received:s.data,code:u.invalid_enum_value,options:r}),v}return z(e.data)}get options(){return this._def.values}get enum(){const e={};for(const s of this._def.values)e[s]=s;return e}get Values(){const e={};for(const s of this._def.values)e[s]=s;return e}get Enum(){const e={};for(const s of this._def.values)e[s]=s;return e}extract(e,s=this._def){return ee.create(e,{...this._def,...s})}exclude(e,s=this._def){return ee.create(this.options.filter(r=>!e.includes(r)),{...this._def,...s})}}ee.create=kt;class lt extends N{_parse(e){const s=A.getValidEnumValues(this._def.values),r=this._getOrReturnCtx(e);if(r.parsedType!==p.string&&r.parsedType!==p.number){const n=A.objectValues(s);return f(r,{expected:A.joinValues(n),received:r.parsedType,code:u.invalid_type}),v}if(this._cache||(this._cache=new Set(A.getValidEnumValues(this._def.values))),!this._cache.has(e.data)){const n=A.objectValues(s);return f(r,{received:r.data,code:u.invalid_enum_value,options:n}),v}return z(e.data)}get enum(){return this._def.values}}lt.create=(t,e)=>new lt({values:t,typeName:y.ZodNativeEnum,...k(e)});class Ae extends N{unwrap(){return this._def.type}_parse(e){const{ctx:s}=this._processInputParams(e);if(s.parsedType!==p.promise&&s.common.async===!1)return f(s,{code:u.invalid_type,expected:p.promise,received:s.parsedType}),v;const r=s.parsedType===p.promise?s.data:Promise.resolve(s.data);return z(r.then(n=>this._def.type.parseAsync(n,{path:s.path,errorMap:s.common.contextualErrorMap})))}}Ae.create=(t,e)=>new Ae({type:t,typeName:y.ZodPromise,...k(e)});class te extends N{innerType(){return this._def.schema}sourceType(){return this._def.schema._def.typeName===y.ZodEffects?this._def.schema.sourceType():this._def.schema}_parse(e){const{status:s,ctx:r}=this._processInputParams(e),n=this._def.effect||null,a={addIssue:o=>{f(r,o),o.fatal?s.abort():s.dirty()},get path(){return r.path}};if(a.addIssue=a.addIssue.bind(a),n.type==="preprocess"){const o=n.transform(r.data,a);if(r.common.async)return Promise.resolve(o).then(async c=>{if(s.value==="aborted")return v;const l=await this._def.schema._parseAsync({data:c,path:r.path,parent:r});return l.status==="aborted"?v:l.status==="dirty"||s.value==="dirty"?oe(l.value):l});{if(s.value==="aborted")return v;const c=this._def.schema._parseSync({data:o,path:r.path,parent:r});return c.status==="aborted"?v:c.status==="dirty"||s.value==="dirty"?oe(c.value):c}}if(n.type==="refinement"){const o=c=>{const l=n.refinement(c,a);if(r.common.async)return Promise.resolve(l);if(l instanceof Promise)throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");return c};if(r.common.async===!1){const c=this._def.schema._parseSync({data:r.data,path:r.path,parent:r});return c.status==="aborted"?v:(c.status==="dirty"&&s.dirty(),o(c.value),{status:s.value,value:c.value})}else return this._def.schema._parseAsync({data:r.data,path:r.path,parent:r}).then(c=>c.status==="aborted"?v:(c.status==="dirty"&&s.dirty(),o(c.value).then(()=>({status:s.value,value:c.value}))))}if(n.type==="transform")if(r.common.async===!1){const o=this._def.schema._parseSync({data:r.data,path:r.path,parent:r});if(!q(o))return v;const c=n.transform(o.value,a);if(c instanceof Promise)throw new Error("Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.");return{status:s.value,value:c}}else return this._def.schema._parseAsync({data:r.data,path:r.path,parent:r}).then(o=>q(o)?Promise.resolve(n.transform(o.value,a)).then(c=>({status:s.value,value:c})):v);A.assertNever(n)}}te.create=(t,e,s)=>new te({schema:t,typeName:y.ZodEffects,effect:e,...k(s)});te.createWithPreprocess=(t,e,s)=>new te({schema:e,effect:{type:"preprocess",transform:t},typeName:y.ZodEffects,...k(s)});class U extends N{_parse(e){return this._getType(e)===p.undefined?z(void 0):this._def.innerType._parse(e)}unwrap(){return this._def.innerType}}U.create=(t,e)=>new U({innerType:t,typeName:y.ZodOptional,...k(e)});class se extends N{_parse(e){return this._getType(e)===p.null?z(null):this._def.innerType._parse(e)}unwrap(){return this._def.innerType}}se.create=(t,e)=>new se({innerType:t,typeName:y.ZodNullable,...k(e)});class Ie extends N{_parse(e){const{ctx:s}=this._processInputParams(e);let r=s.data;return s.parsedType===p.undefined&&(r=this._def.defaultValue()),this._def.innerType._parse({data:r,path:s.path,parent:s})}removeDefault(){return this._def.innerType}}Ie.create=(t,e)=>new Ie({innerType:t,typeName:y.ZodDefault,defaultValue:typeof e.default=="function"?e.default:()=>e.default,...k(e)});class Re extends N{_parse(e){const{ctx:s}=this._processInputParams(e),r={...s,common:{...s.common,issues:[]}},n=this._def.innerType._parse({data:r.data,path:r.path,parent:{...r}});return ke(n)?n.then(a=>({status:"valid",value:a.status==="valid"?a.value:this._def.catchValue({get error(){return new D(r.common.issues)},input:r.data})})):{status:"valid",value:n.status==="valid"?n.value:this._def.catchValue({get error(){return new D(r.common.issues)},input:r.data})}}removeCatch(){return this._def.innerType}}Re.create=(t,e)=>new Re({innerType:t,typeName:y.ZodCatch,catchValue:typeof e.catch=="function"?e.catch:()=>e.catch,...k(e)});class dt extends N{_parse(e){if(this._getType(e)!==p.nan){const r=this._getOrReturnCtx(e);return f(r,{code:u.invalid_type,expected:p.nan,received:r.parsedType}),v}return{status:"valid",value:e.data}}}dt.create=t=>new dt({typeName:y.ZodNaN,...k(t)});class Ns extends N{_parse(e){const{ctx:s}=this._processInputParams(e),r=s.data;return this._def.type._parse({data:r,path:s.path,parent:s})}unwrap(){return this._def.type}}class ze extends N{_parse(e){const{status:s,ctx:r}=this._processInputParams(e);if(r.common.async)return(async()=>{const a=await this._def.in._parseAsync({data:r.data,path:r.path,parent:r});return a.status==="aborted"?v:a.status==="dirty"?(s.dirty(),oe(a.value)):this._def.out._parseAsync({data:a.value,path:r.path,parent:r})})();{const n=this._def.in._parseSync({data:r.data,path:r.path,parent:r});return n.status==="aborted"?v:n.status==="dirty"?(s.dirty(),{status:"dirty",value:n.value}):this._def.out._parseSync({data:n.value,path:r.path,parent:r})}}static create(e,s){return new ze({in:e,out:s,typeName:y.ZodPipeline})}}class Oe extends N{_parse(e){const s=this._def.innerType._parse(e),r=n=>(q(n)&&(n.value=Object.freeze(n.value)),n);return ke(s)?s.then(n=>r(n)):r(s)}unwrap(){return this._def.innerType}}Oe.create=(t,e)=>new Oe({innerType:t,typeName:y.ZodReadonly,...k(e)});var y;(function(t){t.ZodString="ZodString",t.ZodNumber="ZodNumber",t.ZodNaN="ZodNaN",t.ZodBigInt="ZodBigInt",t.ZodBoolean="ZodBoolean",t.ZodDate="ZodDate",t.ZodSymbol="ZodSymbol",t.ZodUndefined="ZodUndefined",t.ZodNull="ZodNull",t.ZodAny="ZodAny",t.ZodUnknown="ZodUnknown",t.ZodNever="ZodNever",t.ZodVoid="ZodVoid",t.ZodArray="ZodArray",t.ZodObject="ZodObject",t.ZodUnion="ZodUnion",t.ZodDiscriminatedUnion="ZodDiscriminatedUnion",t.ZodIntersection="ZodIntersection",t.ZodTuple="ZodTuple",t.ZodRecord="ZodRecord",t.ZodMap="ZodMap",t.ZodSet="ZodSet",t.ZodFunction="ZodFunction",t.ZodLazy="ZodLazy",t.ZodLiteral="ZodLiteral",t.ZodEnum="ZodEnum",t.ZodEffects="ZodEffects",t.ZodNativeEnum="ZodNativeEnum",t.ZodOptional="ZodOptional",t.ZodNullable="ZodNullable",t.ZodDefault="ZodDefault",t.ZodCatch="ZodCatch",t.ZodPromise="ZodPromise",t.ZodBranded="ZodBranded",t.ZodPipeline="ZodPipeline",t.ZodReadonly="ZodReadonly"})(y||(y={}));const Y=B.create;W.create;const ce=V.create,wt=I.create;Ne.create;je.create;J.create;const Nt=ee.create;Ae.create;U.create;se.create;class Z extends Error{constructor(s,r){super(s);ne(this,"status");ne(this,"provider");this.name="LLMError",this.status=r.status,this.provider=r.provider}}const jt=(t,e)=>{const s=(t==null?void 0:t.trim())??"";if(!s)throw new Z(`${e.label} API key is required`,{provider:e.id});if(!/^[\x20-\x7e]+$/.test(s))throw new Z(`${e.label} API key contains non-ASCII characters — check for pasted smart quotes or hidden whitespace`,{provider:e.id});return s},At=(t,e)=>{if(!t||t.length===0)throw new Z("messages must not be empty",{provider:e.id})},St=async(t,e,s)=>{var a;let r;try{r=await fetch(t,e)}catch(o){throw new Z(`${s.label} request failed: ${o instanceof Error?o.message:String(o)}`,{provider:s.id})}let n=null;try{n=await r.json()}catch{}if(!r.ok){const o=((a=n==null?void 0:n.error)==null?void 0:a.message)??r.statusText;throw new Z(`${s.label} ${r.status}: ${o}`,{status:r.status,provider:s.id})}if(n===null)throw new Z(`${s.label} returned a non-JSON response`,{status:r.status,provider:s.id});return n},ve={id:"openai",label:"OpenAI"},js="https://api.openai.com/v1",As="gpt-4o-mini";var fe,pe,he;class Ss{constructor(e){ne(this,"provider",ve.id);K(this,fe);K(this,pe);K(this,he);H(this,fe,jt(e.apiKey,ve)),H(this,pe,(e.baseUrl??js).replace(/\/+$/,"")),H(this,he,e.defaultModel??As)}async complete(e){var c,l;At(e.messages,ve);const s=e.model??G(this,he),r={model:s,messages:e.messages.map(d=>({role:d.role,content:d.content}))};e.temperature!==void 0&&(r.temperature=e.temperature),e.maxTokens!==void 0&&(r.max_tokens=e.maxTokens),e.responseFormat==="json_object"&&(r.response_format={type:"json_object"});const n=await St(`${G(this,pe)}/chat/completions`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${G(this,fe)}`},body:JSON.stringify(r),signal:e.signal},ve),a=(c=n.choices)==null?void 0:c[0];return{content:((l=a==null?void 0:a.message)==null?void 0:l.content)??"",model:n.model??s,usage:n.usage?{promptTokens:n.usage.prompt_tokens,completionTokens:n.usage.completion_tokens,totalTokens:n.usage.total_tokens}:void 0}}}fe=new WeakMap,pe=new WeakMap,he=new WeakMap;const ae={id:"gemini",label:"Gemini"},Ts="https://generativelanguage.googleapis.com/v1beta",Cs="gemini-2.5-flash-lite",Es=t=>{const e=[],s=[];for(const r of t){if(r.role==="system"){e.push(r.content);continue}const n=r.role==="assistant"?"model":"user",a=s[s.length-1];a&&a.role===n?a.parts.push({text:r.content}):s.push({role:n,parts:[{text:r.content}]})}return{contents:s,systemInstruction:e.length>0?{parts:[{text:e.join(`

`)}]}:void 0}};var me,ge,xe;class Is{constructor(e){ne(this,"provider",ae.id);K(this,me);K(this,ge);K(this,xe);H(this,me,jt(e.apiKey,ae)),H(this,ge,(e.baseUrl??Ts).replace(/\/+$/,"")),H(this,xe,e.defaultModel??Cs)}async complete(e){var T,x;At(e.messages,ae);const s=e.model??G(this,xe),{contents:r,systemInstruction:n}=Es(e.messages),a={thinkingConfig:{thinkingBudget:0}};e.temperature!==void 0&&(a.temperature=e.temperature),e.maxTokens!==void 0&&(a.maxOutputTokens=e.maxTokens),e.responseFormat==="json_object"&&(a.responseMimeType="application/json");const o={contents:r};n&&(o.systemInstruction=n),Object.keys(a).length>0&&(o.generationConfig=a);const c=`${G(this,ge)}/models/${encodeURIComponent(s)}:generateContent`,l=await St(c,{method:"POST",headers:{"Content-Type":"application/json","x-goog-api-key":G(this,me)},body:JSON.stringify(o),signal:e.signal},ae),d=(T=l.candidates)==null?void 0:T[0],_=(((x=d==null?void 0:d.content)==null?void 0:x.parts)??[]).map(C=>C.text??"").join("");if((d==null?void 0:d.finishReason)==="MAX_TOKENS")throw new Z("Gemini response truncated (MAX_TOKENS). Try increasing maxTokens.",{provider:ae.id});const w=l.usageMetadata;return{content:_,model:l.modelVersion??s,usage:w?{promptTokens:w.promptTokenCount??0,completionTokens:w.candidatesTokenCount??0,totalTokens:w.totalTokenCount??(w.promptTokenCount??0)+(w.candidatesTokenCount??0)}:void 0}}}me=new WeakMap,ge=new WeakMap,xe=new WeakMap;const Rs=t=>{switch(t.provider){case"openai":return new Ss({apiKey:t.apiKey,baseUrl:t.baseUrl,defaultModel:t.defaultModel});case"gemini":return new Is({apiKey:t.apiKey,baseUrl:t.baseUrl,defaultModel:t.defaultModel});default:{const e=t.provider;throw new Error(`unsupported LLM provider: ${String(e)}`)}}},Tt=Nt(["low","medium","high","critical"]),Os=Nt(["BUY","NEGOTIATE","AVOID","UNKNOWN"]),Ms=wt({title:Y().min(1),severity:Tt,detail:Y().min(1),evidenceRuleIds:ce(Y()).default([])}),$s=wt({verdict:Os,overallRisk:Tt,summary:Y().min(1),strengths:ce(Y()).default([]),concerns:ce(Ms).default([]),negotiationPoints:ce(Y()).default([]),dataQualityWarnings:ce(Y()).default([])}),Ls=1024,zs=2048,Zs=(t,e)=>{let s;try{s=JSON.parse(t)}catch(n){const a=t.length>200?`${t.slice(0,200)}…`:t;throw new Z(`LLM evaluation response was not valid JSON: ${n instanceof Error?n.message:String(n)} — content preview: ${a}`,{provider:e})}const r=$s.safeParse(s);if(!r.success)throw new Z(`LLM evaluation response did not match schema: ${r.error.message}`,{provider:e});return r.data},Vs=async t=>{var _,w,T;const{system:e,user:s}=Qt(t.input),r=[{role:"system",content:e},{role:"user",content:s}],n=((_=t.llm)==null?void 0:_.model)??t.model,a=((w=t.llm)==null?void 0:w.temperature)??t.temperature,o=((T=t.llm)==null?void 0:T.maxTokens)??t.maxTokens,c=o??Ls,l=x=>t.client.complete({messages:r,responseFormat:"json_object",temperature:a??.2,maxTokens:x,model:n,signal:t.signal});let d;try{d=await l(c)}catch(x){if(o===void 0&&x instanceof Z&&/MAX_TOKENS/i.test(x.message))d=await l(zs);else throw x}return{schemaVersion:1,...Zs(d.content,t.client.provider),model:d.model,generatedAt:Date.now()}},Ds=async t=>{var r;const e=(r=t.apiKey)==null?void 0:r.trim();if(!e)return null;const s=Rs({provider:t.provider,apiKey:e,defaultModel:t.model});return Vs({client:s,input:t.input,model:t.model,signal:t.signal,temperature:t.temperature,maxTokens:t.maxTokens})},Me=t=>typeof t=="string"&&t.trim().length>0,Ps={openai:{main:"◼ OPENAI",sub:"GPT-4O-MINI"},gemini:{main:"◇ GEMINI",sub:"2.5 FLASH-LITE"}};function Bs({provider:t,apiKey:e,showKey:s,loading:r,hasEvaluation:n,onProviderChange:a,onApiKeyChange:o,onToggleShowKey:c,onRun:l,onCancel:d}){const m=Me(e)&&!r;return i.jsxs("div",{className:"ai-section",children:[i.jsx("div",{className:"ai-provider",children:["openai","gemini"].map(_=>{const w=Ps[_],T=t===_;return i.jsxs("button",{type:"button",onClick:()=>a(_),disabled:r,className:`ai-provider-btn${T?" ai-provider-btn--active":""}`,children:[w.main,i.jsx("span",{className:"ai-provider-sub",children:w.sub})]},_)})}),i.jsxs("div",{className:"ai-key-row",children:[i.jsx("input",{type:s?"text":"password",value:e,onChange:_=>o(_.target.value),placeholder:t==="openai"?"sk-...":"AIza...",disabled:r,autoComplete:"off",spellCheck:!1,className:"ai-key-input"}),i.jsx("button",{type:"button",onClick:c,disabled:r,title:s?"숨기기":"보이기",className:"ai-key-toggle",children:s?"HIDE":"SHOW"})]}),i.jsxs("div",{className:"ai-run-row",children:[i.jsx("button",{type:"button",onClick:l,disabled:!m,className:"ai-run-btn",children:r?"▣ ANALYZING...":n?"↻ RE-EVALUATE":"▶ RUN AI EVALUATION"}),r&&i.jsx("button",{type:"button",onClick:d,className:"ai-cancel-btn",children:"CANCEL"})]}),!Me(e)&&i.jsx("div",{className:"ai-hint",children:t==="openai"?"// OpenAI API key를 입력하면 수집된 매물 데이터를 기반으로 AI가 종합 평가합니다.":"// Google AI Studio API key를 입력하면 수집된 매물 데이터를 기반으로 AI가 종합 평가합니다."})]})}const Us={low:"낮음",medium:"보통",high:"높음",critical:"매우 높음"};function Fs({finding:t}){return i.jsxs("div",{className:`ai-concern ai-concern--${t.severity}`,children:[i.jsxs("div",{className:"ai-concern-head",children:[i.jsx("span",{className:"ai-concern-title",children:t.title}),i.jsx("span",{className:`ai-concern-sev ai-concern-sev--${t.severity}`,children:Us[t.severity]}),t.evidenceRuleIds.length>0&&i.jsx("span",{className:"ai-concern-rules",children:t.evidenceRuleIds.join(" · ")})]}),i.jsx("div",{className:"ai-concern-detail",children:t.detail})]})}const Ws={BUY:{cls:"ai-verdict--buy",label:"GO FOR IT."},NEGOTIATE:{cls:"ai-verdict--negotiate",label:"NEGOTIATE."},AVOID:{cls:"ai-verdict--avoid",label:"DO NOT BUY."},UNKNOWN:{cls:"ai-verdict--unknown",label:"NOT SURE."}},Gs={low:"낮음",medium:"보통",high:"높음",critical:"매우 높음"};function Ks({evaluation:t}){const e=Ws[t.verdict];return i.jsxs("div",{children:[i.jsxs("div",{className:`ai-verdict ${e.cls}`,children:[i.jsx("div",{className:"ai-verdict-tag",children:"◆ AI VERDICT"}),i.jsx("div",{className:"ai-verdict-label",children:e.label}),i.jsxs("div",{className:"ai-verdict-risk",children:["OVERALL RISK · ",Gs[t.overallRisk].toUpperCase()]})]}),i.jsx("div",{className:"ai-summary",children:t.summary}),t.strengths.length>0&&i.jsxs(i.Fragment,{children:[i.jsxs("div",{className:"ai-section-head",children:[i.jsx("span",{children:"◼ STRENGTHS / 장점"}),i.jsx("span",{className:"ai-section-count",children:String(t.strengths.length).padStart(2,"0")})]}),i.jsx("ul",{className:"ai-list",children:t.strengths.map((s,r)=>i.jsxs("li",{className:"ai-list-item ai-list-item--strength",children:[i.jsx("span",{className:"ai-list-mark",children:"+"}),i.jsx("span",{children:s})]},r))})]}),t.concerns.length>0&&i.jsxs(i.Fragment,{children:[i.jsxs("div",{className:"ai-section-head",children:[i.jsx("span",{children:"◼ CONCERNS / 우려"}),i.jsx("span",{className:"ai-section-count",children:String(t.concerns.length).padStart(2,"0")})]}),i.jsx("div",{children:t.concerns.map((s,r)=>i.jsx(Fs,{finding:s},r))})]}),t.negotiationPoints.length>0&&i.jsxs(i.Fragment,{children:[i.jsxs("div",{className:"ai-section-head",children:[i.jsx("span",{children:"◼ NEGOTIATION / 협상 포인트"}),i.jsx("span",{className:"ai-section-count",children:String(t.negotiationPoints.length).padStart(2,"0")})]}),i.jsx("ul",{className:"ai-list",children:t.negotiationPoints.map((s,r)=>i.jsxs("li",{className:"ai-list-item ai-list-item--neg",children:[i.jsx("span",{className:"ai-list-mark",children:"→"}),i.jsx("span",{children:s})]},r))})]}),t.dataQualityWarnings.length>0&&i.jsxs(i.Fragment,{children:[i.jsxs("div",{className:"ai-section-head",children:[i.jsx("span",{children:"◼ DATA GAPS / 데이터 부족"}),i.jsx("span",{className:"ai-section-count",children:String(t.dataQualityWarnings.length).padStart(2,"0")})]}),i.jsx("ul",{className:"ai-list",children:t.dataQualityWarnings.map((s,r)=>i.jsxs("li",{className:"ai-list-item ai-list-item--data",children:[i.jsx("span",{className:"ai-list-mark",children:"?"}),i.jsx("span",{children:s})]},r))})]}),i.jsxs("div",{className:"ai-footer",children:["MODEL · ",t.model," ·"," ",new Date(t.generatedAt).toLocaleTimeString()]})]})}const Hs=`
.ai-root {
  background: #fff;
  color: #000;
  border-bottom: 4px solid #000;
  animation: autoverdict-fade 260ms ease-out both;
}

.ai-header {
  display: flex;
  align-items: center;
  gap: 10px;
  background: #000;
  color: #fff;
  padding: 10px 14px;
  border-bottom: 4px solid #000;
}
.ai-header-title {
  font-family: 'Archivo Black', sans-serif;
  font-size: 14px;
  letter-spacing: -0.2px;
  text-transform: uppercase;
}
.ai-header-note {
  margin-left: auto;
  font-family: 'Space Mono', monospace;
  font-size: 8px;
  letter-spacing: 2px;
  text-transform: uppercase;
  opacity: 0.7;
}

.ai-section {
  padding: 12px 14px;
  border-bottom: 2px solid #000;
}

.ai-provider {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 0;
  border: 2px solid #000;
}
.ai-provider-btn {
  background: #fff;
  color: #000;
  border: none;
  border-right: 2px solid #000;
  padding: 10px 8px;
  cursor: pointer;
  font-family: 'Archivo Black', sans-serif;
  font-size: 11px;
  letter-spacing: 0.3px;
  text-transform: uppercase;
  text-align: left;
}
.ai-provider-btn:last-child { border-right: none; }
.ai-provider-btn--active {
  background: #000;
  color: #fff;
}
.ai-provider-btn:disabled { cursor: not-allowed; opacity: 0.5; }
.ai-provider-sub {
  display: block;
  font-family: 'Space Mono', monospace;
  font-size: 8px;
  letter-spacing: 1px;
  margin-top: 3px;
  opacity: 0.65;
}

.ai-key-row {
  display: flex;
  gap: 0;
  margin-top: 10px;
  border: 2px solid #000;
}
.ai-key-input {
  flex: 1;
  background: #fff;
  color: #000;
  border: none;
  padding: 10px 12px;
  font-family: 'Space Mono', monospace;
  font-size: 12px;
  outline: none;
}
.ai-key-input::placeholder {
  color: #000;
  opacity: 0.35;
}
.ai-key-input:disabled { background: #fafafa; cursor: not-allowed; }
.ai-key-toggle {
  background: #fff;
  color: #000;
  border: none;
  border-left: 2px solid #000;
  padding: 0 14px;
  cursor: pointer;
  font-family: 'Archivo Black', sans-serif;
  font-size: 10px;
  letter-spacing: 1px;
  text-transform: uppercase;
}
.ai-key-toggle:disabled { cursor: not-allowed; opacity: 0.5; }

.ai-run-row { display: flex; gap: 8px; margin-top: 10px; }
.ai-run-btn {
  flex: 1;
  background: #e4ff00;
  color: #000;
  border: 2px solid #000;
  padding: 12px 14px;
  cursor: pointer;
  font-family: 'Archivo Black', sans-serif;
  font-size: 14px;
  letter-spacing: -0.2px;
  text-transform: uppercase;
  transition: transform 120ms ease-out;
}
.ai-run-btn:hover:not(:disabled) { transform: translate(-1px, -1px); box-shadow: 3px 3px 0 #000; }
.ai-run-btn:disabled {
  background: #f0f0f0;
  color: #000;
  cursor: not-allowed;
  opacity: 0.5;
}
.ai-cancel-btn {
  background: #fff;
  color: #000;
  border: 2px solid #000;
  padding: 12px 14px;
  cursor: pointer;
  font-family: 'Archivo Black', sans-serif;
  font-size: 11px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
}

.ai-hint {
  font-family: 'Space Mono', monospace;
  font-size: 10px;
  line-height: 1.6;
  margin-top: 10px;
  opacity: 0.7;
}

.ai-error {
  background: #ff2d4b;
  color: #fff;
  border-bottom: 4px solid #000;
  padding: 12px 14px;
  display: flex;
  gap: 10px;
  align-items: flex-start;
}
.ai-error-mark {
  font-family: 'Archivo Black', sans-serif;
  font-size: 22px;
  line-height: 1;
}
.ai-error-text {
  font-family: 'Inter Tight', sans-serif;
  font-size: 12px;
  line-height: 1.5;
  font-weight: 600;
}

.ai-loading {
  padding: 28px 14px;
  text-align: center;
  border-bottom: 4px solid #000;
  background: #e4ff00;
}
.ai-loading-text {
  font-family: 'Archivo Black', sans-serif;
  font-size: 36px;
  letter-spacing: -1px;
  line-height: 0.9;
}
.ai-loading-sub {
  font-family: 'Space Mono', monospace;
  font-size: 9px;
  letter-spacing: 2px;
  text-transform: uppercase;
  margin-top: 8px;
  opacity: 0.7;
}

.ai-verdict {
  padding: 14px;
  border-bottom: 4px solid #000;
}
.ai-verdict--buy       { background: #7cff6b; }
.ai-verdict--negotiate { background: #e4ff00; }
.ai-verdict--avoid     { background: #ff2d4b; color: #fff; }
.ai-verdict--unknown   { background: #d4d4d4; }
.ai-verdict-tag {
  font-family: 'Space Mono', monospace;
  font-size: 8px;
  letter-spacing: 2px;
  text-transform: uppercase;
}
.ai-verdict-label {
  font-family: 'Archivo Black', sans-serif;
  font-size: 32px;
  line-height: 0.95;
  letter-spacing: -1px;
  text-transform: uppercase;
  margin-top: 6px;
}
.ai-verdict-risk {
  font-family: 'Space Mono', monospace;
  font-size: 10px;
  letter-spacing: 0.5px;
  margin-top: 8px;
  border-top: 2px solid currentColor;
  padding-top: 6px;
}

.ai-summary {
  padding: 14px;
  border-bottom: 2px solid #000;
  font-family: 'Inter Tight', sans-serif;
  font-size: 13px;
  line-height: 1.6;
  font-weight: 500;
}

.ai-section-head {
  background: #000;
  color: #fff;
  padding: 6px 14px;
  font-family: 'Archivo Black', sans-serif;
  font-size: 10px;
  letter-spacing: 1.5px;
  text-transform: uppercase;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.ai-section-count {
  font-family: 'Space Mono', monospace;
  font-size: 9px;
  opacity: 0.7;
}

.ai-list {
  list-style: none;
  margin: 0;
  padding: 0;
}
.ai-list-item {
  display: grid;
  grid-template-columns: 22px 1fr;
  gap: 8px;
  padding: 10px 14px;
  border-bottom: 1px solid #000;
  font-family: 'Inter Tight', sans-serif;
  font-size: 12px;
  line-height: 1.5;
}
.ai-list-mark {
  font-family: 'Archivo Black', sans-serif;
  font-size: 14px;
}
.ai-list-item--strength { background: #fff; }
.ai-list-item--neg { background: #fafafa; }
.ai-list-item--data { background: #f0f0f0; }

.ai-concern {
  padding: 10px 14px;
  border-bottom: 1px solid #000;
  border-left: 8px solid #000;
}
.ai-concern--low      { border-left-color: #7cff6b; }
.ai-concern--medium   { border-left-color: #e4ff00; }
.ai-concern--high     { border-left-color: #ff8f1f; background: #fff8ec; }
.ai-concern--critical { border-left-color: #ff2d4b; background: #fff0f2; }
.ai-concern-head {
  display: flex;
  gap: 6px;
  align-items: center;
  flex-wrap: wrap;
}
.ai-concern-title {
  font-family: 'Archivo Black', sans-serif;
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: -0.1px;
}
.ai-concern-sev {
  font-family: 'Space Mono', monospace;
  font-size: 8px;
  letter-spacing: 1px;
  padding: 2px 6px;
  border: 1px solid #000;
  text-transform: uppercase;
}
.ai-concern-sev--low      { background: #7cff6b; }
.ai-concern-sev--medium   { background: #e4ff00; }
.ai-concern-sev--high     { background: #ff8f1f; color: #000; }
.ai-concern-sev--critical { background: #ff2d4b; color: #fff; }
.ai-concern-rules {
  margin-left: auto;
  font-family: 'Space Mono', monospace;
  font-size: 8px;
  letter-spacing: 0.5px;
  opacity: 0.6;
}
.ai-concern-detail {
  font-family: 'Inter Tight', sans-serif;
  font-size: 11px;
  line-height: 1.5;
  margin-top: 5px;
}

.ai-footer {
  padding: 8px 14px;
  background: #fafafa;
  font-family: 'Space Mono', monospace;
  font-size: 8px;
  letter-spacing: 1px;
  text-transform: uppercase;
  text-align: right;
  opacity: 0.6;
}
`,Ys=Hs;function Js({parsed:t,facts:e,report:s}){const[r,n]=g.useState("openai"),[a,o]=g.useState(""),[c,l]=g.useState(!1),[d,m]=g.useState(!1),[_,w]=g.useState(null),[T,x]=g.useState(null),C=g.useRef(null),b=g.useCallback(async()=>{var S;if(!Me(a))return;(S=C.current)==null||S.abort();const M=new AbortController;C.current=M,m(!0),w(null),x(null);try{const j=await Ds({provider:r,apiKey:a,input:{parsed:t,facts:e,report:s},signal:M.signal});if(!j){w("API key가 필요합니다.");return}x(j)}catch(j){if(j instanceof DOMException&&j.name==="AbortError")return;j instanceof Z?w(j.status?`LLM 오류 (${j.provider} ${j.status}): ${j.message}`:`LLM 오류 (${j.provider}): ${j.message}`):j instanceof Error?w(j.message):w(String(j))}finally{m(!1)}},[a,r,t,e,s]),E=g.useCallback(()=>{var M;(M=C.current)==null||M.abort(),m(!1)},[]);return i.jsxs("section",{className:"ai-root",children:[i.jsxs("header",{className:"ai-header",children:[i.jsx("div",{className:"ai-header-title",children:"◼ AI EVALUATION"}),i.jsx("div",{className:"ai-header-note",children:"KEY NOT STORED"})]}),i.jsx(Bs,{provider:r,apiKey:a,showKey:c,loading:d,hasEvaluation:T!==null,onProviderChange:n,onApiKeyChange:o,onToggleShowKey:()=>l(M=>!M),onRun:b,onCancel:E}),_&&i.jsxs("div",{className:"ai-error",children:[i.jsx("div",{className:"ai-error-mark",children:"✕"}),i.jsx("div",{className:"ai-error-text",children:_})]}),d&&!T&&i.jsxs("div",{className:"ai-loading",children:[i.jsx("div",{className:"ai-loading-text",children:"ANALYZING"}),i.jsx("div",{className:"ai-loading-sub",children:"// LLM REASONING IN PROGRESS"})]}),T&&!d&&i.jsx(Ks,{evaluation:T})]})}const ut=async()=>{const e=(await chrome.tabs.query({active:!0,currentWindow:!0}))[0];return!e||!e.id||!e.url?null:{tabId:e.id,url:e.url,carId:Ut(e.url)}},ft=async(t,e,s)=>{try{await chrome.runtime.sendMessage({type:"COLLECT_FOR_TAB",carId:e,url:s,tabId:t})}catch{}};function Xs(){const[t,e]=g.useState(null),[s,r]=g.useState(null),[n,a]=g.useState(!0),[o,c]=g.useState(null),[l,d]=g.useState(null),m=g.useRef(null);m.current=t;const _=g.useRef(null),w=g.useCallback(()=>{const b=_.current;b&&(clearTimeout(b.timeout),chrome.runtime.onMessage.removeListener(b.listener),_.current=null)},[]),T=g.useCallback(async()=>{const b=await ut();if(e(b),!(b!=null&&b.carId)){r(null),a(!1);return}try{const E=await chrome.runtime.sendMessage({type:"GET_LAST",carId:b.carId});if(r(E??null),E){c(null),d(null),a(!1);return}c("start"),ft(b.tabId,b.carId,b.url)}catch{r(null)}a(!1)},[]);g.useEffect(()=>{T();const b=S=>{if(Ue(S))c(S.stage),d(null);else if(Fe(S)){c(null),d(null);const j=m.current;if(j&&j.carId===S.carId){const X=Date.now();r({carId:S.carId,url:j.url,parsed:S.parsed,facts:S.facts,report:S.report,cachedAt:X,expiresAt:X+24*60*60*1e3}),a(!1)}else T()}else if(We(S)){c(null);const j=m.current;j&&j.carId===S.carId&&d(S.reason)}};chrome.runtime.onMessage.addListener(b);const E=()=>{a(!0),c(null),T()};chrome.tabs.onActivated.addListener(E);const M=(S,j,X)=>{X.active&&(j.url?(r(null),c("start"),a(!0),T()):j.status==="complete"&&T())};return chrome.tabs.onUpdated.addListener(M),()=>{chrome.runtime.onMessage.removeListener(b),chrome.tabs.onActivated.removeListener(E),chrome.tabs.onUpdated.removeListener(M),w()}},[T,w]);const x=g.useCallback(async()=>{w();const b=await ut();if(e(b),!(b!=null&&b.carId)){a(!1);return}d(null),c("start"),r(null),a(!0),await chrome.runtime.sendMessage({type:"REFRESH",carId:b.carId}).catch(()=>{}),ft(b.tabId,b.carId,b.url);const E=setTimeout(()=>{d("watchdog_timeout"),c(null);const S=_.current;S&&S.timeout===E&&(chrome.runtime.onMessage.removeListener(S.listener),_.current=null)},22e3),M=S=>{if(Fe(S)||We(S)||Ue(S)){const j=_.current;j&&j.timeout===E&&(clearTimeout(j.timeout),chrome.runtime.onMessage.removeListener(j.listener),_.current=null)}};chrome.runtime.onMessage.addListener(M),_.current={timeout:E,listener:M}},[w]),C=g.useCallback(b=>{if(!confirm("정말 무시하시겠습니까? 7일 동안 이 체크는 비활성화됩니다."))return;const E=m.current;E!=null&&E.carId&&chrome.runtime.sendMessage({type:"ACK_RULE",carId:E.carId,ruleId:b}).then(()=>void T()).catch(()=>{})},[T]);return{active:t,row:s,loading:n,progressStage:o,loadError:l,refresh:x,ack:C}}function Qs(t,e=600){const[s,r]=g.useState(t);return g.useEffect(()=>{if(typeof window>"u"){r(t);return}if(window.matchMedia("(prefers-reduced-motion: reduce)").matches){r(t);return}r(0);let n,a=null;const o=c=>{a===null&&(a=c);const l=c-a,d=Math.min(l/e,1),m=1-Math.pow(1-d,3);r(Math.round(m*t)),d<1&&(n=requestAnimationFrame(o))};return n=requestAnimationFrame(o),()=>{cancelAnimationFrame(n)}},[t,e]),Math.round(s)}function qs(t){switch(t){case"NEVER":return`DO NOT
BUY.`;case"CAUTION":return`CAUTION.
READ ME.`;case"OK":return"GOOD.";case"UNKNOWN":return`CHECK
THIS.`}}function er(t,e){const s=[...t,...e].slice(0,3);return s.length===0?"특이사항 없음":s.map(r=>{var n;return((n=Se[r.ruleId])==null?void 0:n.shortTitle)??r.title}).join(" · ")}const tr=`
.hero {
  display: flex;
  border-bottom: 4px solid #000;
}
.hero-score {
  padding: 8px 8px 6px 14px;
  display: flex;
  flex-direction: column;
  justify-content: center;
}
.hero-score-label {
  font-family: 'Space Mono', monospace;
  font-size: 8px;
  letter-spacing: 2px;
  text-transform: uppercase;
  color: #000;
}
.hero-score-number {
  font-family: 'Archivo Black', sans-serif;
  font-size: 86px;
  line-height: 0.85;
  letter-spacing: -3px;
  color: #000;
}
.hero-score-sub {
  font-family: 'Space Mono', monospace;
  font-size: 10px;
  opacity: 0.6;
  margin-top: -2px;
}
.hero-verdict {
  flex: 1;
  border-left: 4px solid #000;
  background: #e4ff00;
  padding: 10px 12px 8px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  position: relative;
  transition: background 180ms ease-out;
}
.hero-verdict--never   { background: #ff2d4b; }
.hero-verdict--caution { background: #e4ff00; }
.hero-verdict--ok      { background: #7cff6b; }
.hero-verdict--unknown { background: #d4d4d4; }
.hero-verdict-dot {
  position: absolute;
  top: 6px;
  right: 6px;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: #000;
  box-shadow: 0 0 0 2px #fff;
}
.hero-verdict--never .hero-verdict-dot {
  background: #fff;
  box-shadow: 0 0 0 2px #000;
}
.hero-verdict-tag {
  font-family: 'Space Mono', monospace;
  font-size: 8px;
  letter-spacing: 2px;
  text-transform: uppercase;
  color: #000;
}
.hero-verdict-label {
  font-family: 'Archivo Black', sans-serif;
  font-size: 20px;
  line-height: 0.9;
  letter-spacing: -0.5px;
  margin-top: 5px;
  color: #000;
}
.hero-verdict-summary {
  font-family: 'Space Mono', monospace;
  font-size: 9px;
  letter-spacing: 0.3px;
  line-height: 1.4;
  margin-top: 8px;
  border-top: 2px solid #000;
  padding-top: 5px;
  color: #000;
}
`,sr={NEVER:"hero-verdict hero-verdict--never",CAUTION:"hero-verdict hero-verdict--caution",OK:"hero-verdict hero-verdict--ok",UNKNOWN:"hero-verdict hero-verdict--unknown"},rr=({score:t,verdict:e,killers:s,warns:r})=>{const n=Qs(t,600),a=qs(e),o=er(s,r);return i.jsxs("div",{className:"hero",children:[i.jsxs("div",{className:"hero-score",children:[i.jsx("div",{className:"hero-score-label",children:"SCORE"}),i.jsx("div",{className:"hero-score-number",children:n}),i.jsx("div",{className:"hero-score-sub",children:"OUT OF 100"})]}),i.jsxs("div",{className:sr[e],children:[s.length>0&&i.jsx("div",{className:"hero-verdict-dot"}),i.jsxs("div",{children:[i.jsx("div",{className:"hero-verdict-tag",children:"◆ VERDICT"}),i.jsx("div",{className:"hero-verdict-label",children:a.split(`
`).map((c,l)=>i.jsxs(zt.Fragment,{children:[l>0&&i.jsx("br",{}),c]},l))})]}),i.jsx("div",{className:"hero-verdict-summary",children:o})]})]})},nr=t=>{if(t!==void 0)return`${t.toLocaleString()}km`},ar=t=>{if(!(t===void 0||t===0)){if(t>=1e4){const e=Math.floor(t/1e4),s=t%1e4;return s>0?`${e}억 ${s.toLocaleString()}만원`:`${e}억원`}return`${t.toLocaleString()}만원`}},ir=`
.car-strip {
  padding: 11px 14px;
  border-bottom: 4px double #000;
  display: flex;
  flex-direction: column;
  gap: 3px;
  background: #fff;
}
.car-strip-make {
  font-family: 'Archivo Black', sans-serif;
  font-size: 14px;
  text-transform: uppercase;
  letter-spacing: 0;
  color: #000;
}
.car-strip-spec {
  font-family: 'Space Mono', monospace;
  font-size: 10px;
  opacity: 0.75;
  color: #000;
}
.car-strip-price {
  font-family: 'Archivo Black', sans-serif;
  font-size: 18px;
  margin-top: 4px;
  color: #000;
}
`,or=({parsed:t,carId:e})=>{const s=t.raw.base;if(s.kind!=="value")return i.jsxs("div",{className:"car-strip",children:[i.jsx("div",{className:"car-strip-make",children:"— NO CAR DATA —"}),i.jsx("div",{className:"car-strip-spec",children:`#${e}`}),i.jsx("div",{className:"car-strip-price",children:"가격 미공개"})]});const r=s.value,n=[r.category.manufacturerName,r.category.modelName].filter(Boolean).join(" "),a=r.category.gradeName??r.category.gradeDetailName,o=yt(r.category.yearMonth),c=nr(r.spec.mileage),l=ar(r.advertisement.price),d=n+(a?` · ${a}`:""),m=[o,c,`#${e}`].filter(_=>_!=null);return i.jsxs("div",{className:"car-strip",children:[i.jsx("div",{className:"car-strip-make",children:d}),i.jsx("div",{className:"car-strip-spec",children:m.join(" · ")}),i.jsx("div",{className:"car-strip-price",children:l??"가격 미공개"})]})},cr=[{id:"checklist",label:"CHECKLIST",sub:"◼ 11 RULES"},{id:"ai",label:"AI REVIEW",sub:"◇ GEMINI / GPT"},{id:"mylist",label:"MY LIST",sub:"★ SAVED CARS"}],lr=`
.tab-bar {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  border-bottom: 4px solid #000;
}
.tab-bar-btn {
  padding: 14px 8px 12px;
  border: none;
  border-right: 4px solid #000;
  cursor: pointer;
  text-align: center;
  font-family: 'Archivo Black', sans-serif;
  font-size: 15px;
  text-transform: uppercase;
  letter-spacing: -0.3px;
}
.tab-bar-btn:last-child {
  border-right: none;
}
.tab-bar-btn--active {
  background: #000;
  color: #fff;
}
.tab-bar-btn--inactive {
  background: #fff;
  color: #000;
}
.tab-bar-sub {
  font-family: 'Space Mono', monospace;
  font-size: 8px;
  letter-spacing: 1.5px;
  display: block;
  margin-top: 4px;
  font-weight: 700;
}
.tab-bar-btn--active .tab-bar-sub {
  opacity: 0.75;
}
.tab-bar-btn--inactive .tab-bar-sub {
  opacity: 0.6;
}
.tab-bar-btn--disabled {
  background: #e0e0e0;
  color: #999;
  cursor: not-allowed;
}
.tab-bar-btn--disabled .tab-bar-sub {
  opacity: 0.4;
}
`,dr=({tab:t,onChange:e,disabledTabs:s=[]})=>i.jsx("div",{className:"tab-bar",children:cr.map(r=>{const n=t===r.id,a=s.includes(r.id),o=a?"tab-bar-btn tab-bar-btn--disabled":`tab-bar-btn ${n?"tab-bar-btn--active":"tab-bar-btn--inactive"}`;return i.jsxs("button",{className:o,disabled:a,onClick:()=>!a&&e(r.id),children:[r.label,i.jsx("span",{className:"tab-bar-sub",children:r.sub})]},r.id)})}),Ct=(t,e)=>e<=0?0:Math.round(t/e*100),ur=t=>t>=80?"good":t>=50?"warn":"bad";function fr(t){return vt.map(e=>{const s=t.filter(o=>{var l;return(((l=Se[o.ruleId])==null?void 0:l.category)??"투명성")===e}),r=s.length,n=s.filter(o=>o.severity==="pass").length,a=Ct(n,r);return{category:e,pass:n,total:r,pct:a}})}const pr=`
  .autoverdict-radar-container {
    padding: 4px 14px 12px;
    border-bottom: 4px solid #000;
  }
  .autoverdict-radar-header {
    display: flex;
    justify-content: flex-end;
    margin-bottom: 2px;
  }
  .autoverdict-radar-header-text {
    text-align: right;
    font-family: 'Space Mono', monospace;
    font-size: 9px;
    text-transform: uppercase;
    letter-spacing: 2px;
    line-height: 1.4;
  }
  .autoverdict-radar-header-title {
    opacity: 1;
  }
  .autoverdict-radar-header-index {
    opacity: 0.5;
  }
  .autoverdict-radar-svg {
    width: 100%;
    max-width: 340px;
    height: auto;
    display: block;
    margin: 0 auto;
  }
  .autoverdict-radar-poly {
    animation: autoverdict-radar-draw 500ms ease-out both;
    stroke-dasharray: 2000;
  }
`,Et=180,It=160,ye=110,hr=[110,82,55,28],mr=135,$e=5;function be(t){return-Math.PI/2+t*(2*Math.PI/$e)}function _e(t,e){return[Et+t*Math.cos(e),It+t*Math.sin(e)]}function pt(t){return t.map(([e,s])=>`${e.toFixed(2)},${s.toFixed(2)}`).join(" ")}function gr(t){return t===4?"end":t===1?"start":"middle"}const xr=({results:t})=>{const e=fr(t),s=hr.map(a=>{const o=Array.from({length:$e},(c,l)=>_e(a,be(l)));return{r:a,pts:o}}),r=Array.from({length:$e},(a,o)=>{const[c,l]=_e(ye,be(o));return{x:c,y:l}}),n=e.map((a,o)=>{const c=a.pct/100*ye;return _e(c,be(o))});return i.jsxs("div",{className:"autoverdict-radar-container",children:[i.jsx("div",{className:"autoverdict-radar-header",children:i.jsxs("div",{className:"autoverdict-radar-header-text",children:[i.jsx("div",{className:"autoverdict-radar-header-title",children:"◇ HEALTH RADAR"}),i.jsx("div",{className:"autoverdict-radar-header-index",children:"01 / 02"})]})}),i.jsxs("svg",{viewBox:"-30 -10 420 330",className:"autoverdict-radar-svg","aria-label":"Health radar chart",children:[i.jsx("defs",{children:i.jsxs("pattern",{id:"autoverdict-hatch",patternUnits:"userSpaceOnUse",width:6,height:6,patternTransform:"rotate(45)",children:[i.jsx("rect",{width:6,height:6,fill:"#e4ff00"}),i.jsx("line",{x1:0,y1:0,x2:0,y2:6,stroke:"#000",strokeWidth:2})]})}),s.map(({r:a,pts:o})=>i.jsx("polygon",{points:pt(o),fill:"none",stroke:"#000",strokeWidth:a===ye?1.5:.75,opacity:a===ye?1:.25},a)),r.map(({x:a,y:o},c)=>i.jsx("line",{x1:Et,y1:It,x2:a,y2:o,stroke:"#000",strokeWidth:1,strokeDasharray:"2 3",opacity:.4},c)),i.jsx("polygon",{points:pt(n),fill:"url(#autoverdict-hatch)",stroke:"#000",strokeWidth:3,className:"autoverdict-radar-poly"}),n.map(([a,o],c)=>i.jsx("circle",{cx:a,cy:o,r:5,fill:"#000"},c)),e.map((a,o)=>{const[c,l]=_e(mr,be(o)),d=gr(o),m=a.pct<50?"#ff2d4b":"#000",_=a.pct<50?"#ff2d4b":"#000",w=a.pct>=50?.6:1;return i.jsxs("g",{children:[i.jsx("text",{x:c,y:l+4,textAnchor:d,fontFamily:"'Archivo Black', sans-serif",fontSize:11,fill:m,fontWeight:900,children:a.category}),i.jsxs("text",{x:c,y:l+4+12,textAnchor:d,fontFamily:"'Space Mono', monospace",fontSize:9,fill:_,opacity:w,children:[a.pass,"/",a.total," · ",a.pct,"%"]})]},o)})]})]})},vr=`
  .autoverdict-filter-tabs {
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    border-bottom: 4px solid #000;
  }
  .v-tab {
    padding: 12px 2px 10px;
    border-right: 2px solid #000;
    border-top: none;
    border-left: none;
    border-bottom: none;
    text-align: center;
    cursor: pointer;
    position: relative;
    font-family: inherit;
    background: #fff;
    color: #000;
  }
  .v-tab:last-child {
    border-right: none;
  }
  .v-tab::before {
    content: '';
    position: absolute;
    top: -2px;
    left: 0;
    right: 0;
    height: 5px;
    background: transparent;
  }
  .v-tab.is-active::before {
    background: #000;
  }
  .v-tab-all {
    background: #000;
    color: #fff;
  }
  .v-tab-all.is-active::before {
    background: #e4ff00;
  }
  .v-tab-fatal {
    background: #ff2d4b;
    color: #fff;
  }
  .v-tab-warn {
    background: #e4ff00;
    color: #000;
  }
  .v-tab-pass {
    background: #fff;
    color: #000;
  }
  .v-tab-na {
    background: #f0f0f0;
    color: #000;
  }
  .v-tab-count {
    display: block;
    font-family: 'Archivo Black', sans-serif;
    font-size: 28px;
    line-height: 1;
    letter-spacing: -1px;
  }
  .v-tab-label {
    display: block;
    font-family: 'Space Mono', monospace;
    font-size: 8px;
    letter-spacing: 1.2px;
    text-transform: uppercase;
    margin-top: 5px;
    opacity: 0.75;
  }
`,yr=({counts:t,active:e,onChange:s})=>{const r=[{id:"all",count:t.total,label:"All"},{id:"fatal",count:t.killers,label:"Fatal"},{id:"warn",count:t.warns,label:"Warn"},{id:"pass",count:t.passes,label:"Pass"},{id:"na",count:t.unknowns,label:"N/A"}];return i.jsx("div",{className:"autoverdict-filter-tabs",children:r.map(({id:n,count:a,label:o})=>i.jsxs("button",{className:`v-tab v-tab-${n}${e===n?" is-active":""}`,onClick:()=>s(n),type:"button",children:[i.jsx("span",{className:"v-tab-count",children:a}),i.jsx("span",{className:"v-tab-label",children:o})]},n))})};function br(t){const e=t.match(/\d+/);return e?String(Number(e[0])).padStart(2,"0"):"??"}const _r=`
@keyframes autoverdict-stagger-in {
  from { opacity: 0; transform: translateY(6px); }
  to   { opacity: 1; transform: translateY(0); }
}

.rc-stagger {
  animation: autoverdict-stagger-in 300ms ease-out both;
}

.rc-root {
  display: grid;
  grid-template-columns: 28px 1fr auto;
  gap: 10px;
  padding: 11px 14px;
  border-bottom: 1px solid #000;
  align-items: start;
}

.rc-root--killer,
.rc-root--fail {
  background: #ff2d4b;
  color: #fff;
}

.rc-root--warn {
  background: #e4ff00;
  color: #000;
}

.rc-root--pass {
  background: #fff;
  color: #000;
}

.rc-root--unknown {
  background: #fafafa;
  color: #000;
}

.rc-number {
  font-family: 'Archivo Black', sans-serif;
  font-size: 16px;
  line-height: 1.1;
}

.rc-title {
  font-family: 'Archivo Black', sans-serif;
  font-size: 14px;
  letter-spacing: -0.2px;
  line-height: 1.1;
  text-transform: uppercase;
}

.rc-message {
  font-family: 'Inter Tight', sans-serif;
  font-size: 11px;
  line-height: 1.5;
  font-weight: 400;
  margin-top: 4px;
}

.rc-tags {
  display: flex;
  gap: 4px;
  margin-top: 6px;
}

.rc-tag {
  font-family: 'Space Mono', monospace;
  font-size: 8px;
  padding: 2px 5px;
  border: 1px solid currentColor;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.rc-ack {
  font-family: 'Space Mono', monospace;
  font-size: 8px;
  background: transparent;
  color: #fff;
  border: 1px solid #fff;
  padding: 4px 10px;
  cursor: pointer;
  margin-top: 6px;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.rc-mark {
  font-family: 'Archivo Black', sans-serif;
  font-size: 22px;
  line-height: 1;
  padding-top: 2px;
}
`,kr={killer:["KILLER","DO NOT BUY"],warn:["WARN"],unknown:["N/A"]},wr={killer:"✕",fail:"✕",warn:"▲",pass:"✓",unknown:"?"},Nr=({result:t,index:e,onAck:s})=>{var c;const r=kr[t.severity]??[],n=wr[t.severity],a=((c=Se[t.ruleId])==null?void 0:c.shortTitle)??t.title,o=br(t.ruleId);return i.jsxs("div",{className:`rc-root rc-root--${t.severity} rc-stagger`,style:{animationDelay:`${e*50}ms`},children:[i.jsx("div",{className:"rc-number",children:o}),i.jsxs("div",{children:[i.jsx("div",{className:"rc-title",children:a}),i.jsx("div",{className:"rc-message",children:t.message}),r.length>0&&i.jsx("div",{className:"rc-tags",children:r.map(l=>i.jsx("span",{className:"rc-tag",children:l},l))}),s&&t.acknowledgeable&&t.severity==="killer"&&i.jsx("button",{className:"rc-ack",onClick:()=>s(t.ruleId),children:"IGNORE 7D"})]}),i.jsx("div",{className:"rc-mark",children:n})]})},jr={"차량 상태":"Condition",이력:"History",사고:"Accident",가격:"Price",투명성:"Disclosure"},Ar=`
.rg-root {
  border-bottom: 3px solid #000;
}

.rg-header {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  padding: 9px 14px 7px;
  background: #000;
  color: #fff;
  font-family: 'Space Mono', monospace;
  font-size: 9px;
  letter-spacing: 2px;
  text-transform: uppercase;
  font-weight: 700;
}

.rg-count {
  font-family: 'Archivo Black', sans-serif;
  font-size: 12px;
  letter-spacing: 0;
  text-transform: none;
}

.rg-count--danger { color: #ff2d4b; }
.rg-count--good   { color: #e4ff00; }
.rg-count--normal { color: #fff; }
`,Sr=({category:t,rules:e,startIndex:s,onAck:r})=>{const n=e.length,a=e.filter(d=>d.severity==="pass").length,o=Ct(a,n),c=ur(o),l=c==="bad"?"rg-count rg-count--danger":c==="good"?"rg-count rg-count--good":"rg-count rg-count--normal";return i.jsxs("div",{className:"rg-root",children:[i.jsxs("div",{className:"rg-header",children:[i.jsxs("span",{children:["◼ ",t," / ",jr[t]]}),i.jsxs("span",{className:l,children:[a," / ",n]})]}),i.jsx("div",{children:e.map((d,m)=>i.jsx(Nr,{result:d,index:s+m,onAck:r},d.ruleId))})]})},Tr=`
.ab-root {
  display: grid;
  grid-template-columns: 1fr 1fr;
  border-top: 4px double #000;
}

.ab-btn {
  padding: 14px;
  font-family: 'Archivo Black', sans-serif;
  font-size: 13px;
  letter-spacing: -0.2px;
  text-align: center;
  text-transform: uppercase;
  cursor: pointer;
  border: none;
}

.ab-btn--refresh {
  background: #fff;
  color: #000;
  border-right: 2px solid #000;
}

.ab-btn--ai {
  background: #000;
  color: #fff;
}
`,Cr=({onRefresh:t,onGoToAi:e})=>i.jsxs("div",{className:"ab-root",children:[i.jsx("button",{className:"ab-btn ab-btn--refresh",onClick:t,children:"↻ 재평가"}),i.jsx("button",{className:"ab-btn ab-btn--ai",onClick:e,children:"AI 평가 →"})]}),Er=`
.save-bar {
  display: flex;
  justify-content: center;
  border-bottom: 4px solid #000;
}
.save-bar-btn {
  width: 100%;
  padding: 12px;
  font-family: 'Archivo Black', sans-serif;
  font-size: 13px;
  letter-spacing: 0.5px;
  text-align: center;
  text-transform: uppercase;
  cursor: pointer;
  border: none;
  transition: background 0.15s;
}
.save-bar-btn--unsaved {
  background: #fff;
  color: #000;
}
.save-bar-btn--unsaved:hover {
  background: #f0f0f0;
}
.save-bar-btn--saved {
  background: #CCFF00;
  color: #000;
}
`,Ir=({saved:t,onToggle:e})=>i.jsx("div",{className:"save-bar",children:i.jsx("button",{className:`save-bar-btn ${t?"save-bar-btn--saved":"save-bar-btn--unsaved"}`,onClick:e,children:t?"★ SAVED":"☆ SAVE"})}),ht={start:"평가를 시작합니다...",fetching_reports:"이력·진단·사고 리포트 수집 중..."},Rr=`
.lv-container {
  ${Le}
}
.lv-title {
  font-family: 'Archivo Black', sans-serif;
  font-size: 64px;
  line-height: 0.85;
  letter-spacing: -2px;
  color: #000;
}
.lv-stage {
  font-family: 'Space Mono', monospace;
  font-size: 9px;
  letter-spacing: 1.5px;
  text-transform: uppercase;
  opacity: 0.7;
  color: #000;
}
.lv-carid {
  font-family: 'Space Mono', monospace;
  font-size: 9px;
  opacity: 0.4;
  color: #000;
}
.lv-btn {
  font-family: 'Archivo Black', sans-serif;
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: -0.3px;
  color: #000;
  border: 4px solid #000;
  padding: 10px 20px;
  cursor: pointer;
}
`,mt=({stage:t,carId:e,onRefresh:s})=>{const[r,n]=g.useState(!1);g.useEffect(()=>{n(!1);const o=setTimeout(()=>n(!0),25e3);return()=>clearTimeout(o)},[t,e]);const a=r?"응답이 늦어요. 엔카 로딩이 느리거나 페이지가 아직 준비 중일 수 있어요.":t&&t in ht?ht[t]:t?t.toUpperCase():"FETCHING REPORT";return i.jsxs("div",{className:"lv-container",children:[i.jsx("div",{className:"lv-title",children:r?"STUCK?":"LOADING"}),i.jsx("div",{className:"lv-stage",children:a}),e&&i.jsxs("div",{className:"lv-carid",children:["CARID · ",e]}),i.jsx("button",{className:"lv-btn",style:{background:r?"#e4ff00":"#fff"},onClick:s,children:"MANUAL REFETCH"})]})},Or=`
.es-container {
  ${Le}
}
.es-title {
  font-family: 'Archivo Black', sans-serif;
  font-size: 64px;
  line-height: 0.85;
  letter-spacing: -2px;
  color: #000;
}
.es-primary {
  font-family: 'Inter Tight', sans-serif;
  font-size: 13px;
  line-height: 1.6;
  color: #000;
}
.es-secondary {
  font-family: 'Space Mono', monospace;
  font-size: 9px;
  opacity: 0.6;
  color: #000;
}
`,Mr=()=>i.jsxs("div",{className:"es-container",children:[i.jsx("div",{className:"es-title",children:"NOT A CAR"}),i.jsx("div",{className:"es-primary",children:"엔카 매물 페이지(fem.encar.com/cars/detail/...)를 열면 자동으로 평가가 시작됩니다."}),i.jsx("div",{className:"es-secondary",children:"* 보험이력·소유자 변경 정보는 엔카 로그인이 필요합니다"})]}),$r=`
.ev-container {
  position: relative;
  ${Le}
}
.ev-dot {
  position: absolute;
  top: 12px;
  right: 12px;
  width: 16px;
  height: 16px;
  background: #ff2d4b;
  border: 3px solid #000;
}
.ev-title {
  font-family: 'Archivo Black', sans-serif;
  font-size: 64px;
  line-height: 0.85;
  letter-spacing: -2px;
  color: #000;
}
.ev-reason {
  font-family: 'Inter Tight', sans-serif;
  font-size: 13px;
  line-height: 1.5;
  color: #000;
}
.ev-btn {
  font-family: 'Archivo Black', sans-serif;
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: -0.3px;
  background: #e4ff00;
  color: #000;
  border: 4px solid #000;
  padding: 10px 20px;
  cursor: pointer;
}
`,Lr=({reason:t,onRetry:e})=>{const s=t==="watchdog_timeout"?"엔카 응답이 22초 내에 오지 않았어요. 잠시 후 다시 시도해 주세요.":t;return i.jsxs("div",{className:"ev-container",children:[i.jsx("div",{className:"ev-dot"}),i.jsx("div",{className:"ev-title",children:"ERROR"}),i.jsx("div",{className:"ev-reason",children:s}),i.jsx("button",{className:"ev-btn",onClick:e,children:"↻ RETRY"})]})},zr=`
.sc-root {
  border: 3px solid #000;
  border-bottom: none;
  padding: 12px 14px;
  cursor: pointer;
  position: relative;
  transition: background 0.1s;
}
.sc-root:last-child {
  border-bottom: 3px solid #000;
}
.sc-root:hover {
  background: #f5f5f5;
}
.sc-root[data-selected='true'] {
  background: #CCFF00;
}
.sc-top {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  margin-bottom: 4px;
}
.sc-verdict {
  font-family: 'Archivo Black', sans-serif;
  font-size: 14px;
}
.sc-specs {
  font-family: 'Space Mono', monospace;
  font-size: 9px;
  letter-spacing: 1px;
  text-transform: uppercase;
}
.sc-title {
  font-family: 'Inter Tight', sans-serif;
  font-size: 13px;
  font-weight: 600;
  margin-bottom: 2px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.sc-price {
  font-family: 'Archivo Black', sans-serif;
  font-size: 15px;
  margin-bottom: 6px;
}
.sc-bar-row {
  display: flex;
  align-items: center;
  gap: 8px;
  font-family: 'Space Mono', monospace;
  font-size: 9px;
  letter-spacing: 0.5px;
}
.sc-bar {
  flex: 1;
  height: 6px;
  background: #e0e0e0;
  position: relative;
}
.sc-bar-fill {
  height: 100%;
  background: #000;
}
.sc-actions {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  margin-top: 8px;
}
.sc-action-btn {
  font-family: 'Space Mono', monospace;
  font-size: 9px;
  letter-spacing: 1px;
  text-transform: uppercase;
  padding: 4px 8px;
  border: 2px solid #000;
  background: #fff;
  color: #000;
  cursor: pointer;
  text-decoration: none;
}
.sc-action-btn:hover {
  background: #000;
  color: #fff;
}
.sc-checkbox {
  position: absolute;
  top: 12px;
  left: 14px;
  width: 16px;
  height: 16px;
  accent-color: #000;
}
`,Zr=({data:t,selected:e,onSelect:s,onView:r,onDelete:n})=>{const a=o=>{const c=o.target;c.tagName==="INPUT"||c.tagName==="BUTTON"||r(t.carId)};return i.jsxs("div",{className:"sc-root","data-selected":e,onClick:a,children:[i.jsx("input",{type:"checkbox",className:"sc-checkbox",checked:e,onChange:()=>s(t.carId)}),i.jsxs("div",{className:"sc-top",style:{paddingLeft:24},children:[i.jsxs("span",{className:"sc-verdict",style:{color:Zt[t.verdict]},children:["[",t.score,"] ",t.verdict]}),i.jsxs("span",{className:"sc-specs",children:[t.year??"—"," · ",Vt(t.mileageKm)]})]}),i.jsxs("div",{className:"sc-title",style:{paddingLeft:24},children:[t.title||"—",t.fuelType?` ${t.fuelType}`:""]}),i.jsx("div",{className:"sc-price",style:{paddingLeft:24},children:Dt(t.priceWon)}),i.jsxs("div",{className:"sc-bar-row",style:{paddingLeft:24},children:[i.jsx("div",{className:"sc-bar",children:i.jsx("div",{className:"sc-bar-fill",style:{width:`${Math.min(t.score,100)}%`}})}),i.jsxs("span",{children:["K:",t.killerCount," W:",t.warnCount]})]}),i.jsxs("div",{className:"sc-actions",children:[i.jsx("a",{className:"sc-action-btn",href:t.url,target:"_blank",rel:"noopener noreferrer",onClick:o=>o.stopPropagation(),children:"엔카 →"}),i.jsx("button",{className:"sc-action-btn",onClick:o=>{o.stopPropagation(),n(t.carId)},children:"삭제"})]})]})},Vr=4,gt=10,Dr=`
${zr}
.sl-root {
  padding: 0;
}
.sl-empty {
  padding: 32px 16px;
  text-align: center;
  font-family: 'Space Mono', monospace;
  font-size: 10px;
  letter-spacing: 1.5px;
  text-transform: uppercase;
  color: #666;
}
.sl-compare-float {
  position: sticky;
  bottom: 0;
  padding: 12px;
  background: #000;
  text-align: center;
}
.sl-compare-btn {
  font-family: 'Archivo Black', sans-serif;
  font-size: 14px;
  text-transform: uppercase;
  color: #000;
  background: #CCFF00;
  border: none;
  padding: 12px 32px;
  cursor: pointer;
  letter-spacing: 0.5px;
}
.sl-compare-btn:disabled {
  opacity: 0.4;
  cursor: not-allowed;
}
.sl-count {
  padding: 8px 12px;
  font-family: 'Space Mono', monospace;
  font-size: 9px;
  letter-spacing: 1.5px;
  text-transform: uppercase;
  color: #666;
  text-align: right;
}
.sl-count--full {
  color: #FF3B30;
}
`,Pr=({onViewCar:t,refreshKey:e})=>{const[s,r]=g.useState([]),[n,a]=g.useState(!0),[o,c]=g.useState(new Set),l=g.useCallback(async()=>{try{const x=await chrome.runtime.sendMessage({type:"GET_SAVED_LIST"});r(x??[])}catch{r([])}a(!1)},[]);g.useEffect(()=>{l()},[l,e]);const d=g.useCallback(async x=>{await chrome.runtime.sendMessage({type:"UNSAVE_CAR",carId:x}).catch(()=>{}),r(C=>C.filter(b=>b.carId!==x)),c(C=>{const b=new Set(C);return b.delete(x),b})},[]),m=g.useCallback(x=>{c(C=>{const b=new Set(C);return b.has(x)?b.delete(x):b.size<Vr&&b.add(x),b})},[]),_=g.useCallback(()=>{if(o.size<2)return;const x=Array.from(o).join(","),C=chrome.runtime.getURL(`src/compare/compare.html?ids=${x}`);chrome.tabs.create({url:C})},[o]);if(n)return i.jsx("div",{className:"sl-empty",children:"LOADING..."});if(s.length===0)return i.jsxs("div",{className:"sl-empty",children:["저장된 매물이 없습니다.",i.jsx("br",{}),"차량 페이지에서 SAVE 버튼을 눌러 추가하세요."]});const w=s.map(x=>({carId:x.carId,url:x.url,title:x.title,year:x.year,mileageKm:x.mileageKm,priceWon:x.priceWon,fuelType:x.fuelType,score:x.report.score,verdict:x.report.verdict,killerCount:x.report.killers.length,warnCount:x.report.warns.length})),T=s.length>=gt;return i.jsxs("div",{className:"sl-root",children:[i.jsxs("div",{className:`sl-count${T?" sl-count--full":""}`,children:[s.length," / ",gt]}),w.map(x=>i.jsx(Zr,{data:x,selected:o.has(x.carId),onSelect:m,onView:t,onDelete:d},x.carId)),o.size>=2&&i.jsx("div",{className:"sl-compare-float",children:i.jsxs("button",{className:"sl-compare-btn",onClick:_,children:["COMPARE ",o.size]})})]})},Br=Pt+tr+ir+Er+lr+pr+vr+Ar+_r+Tr+Rr+Or+$r+Ys+Dr,Ur=t=>({total:t.length,killers:t.filter(e=>e.severity==="killer").length,warns:t.filter(e=>e.severity==="warn").length,passes:t.filter(e=>e.severity==="pass").length,unknowns:t.filter(e=>e.severity==="unknown").length}),Fr=(t,e)=>e==="all"?t:e==="fatal"?t.filter(s=>s.severity==="killer"||s.severity==="fail"):e==="warn"?t.filter(s=>s.severity==="warn"):e==="pass"?t.filter(s=>s.severity==="pass"):t.filter(s=>s.severity==="unknown"),Wr=t=>{var s;const e=new Map;for(const r of t){const n=((s=Se[r.ruleId])==null?void 0:s.category)??"투명성",a=e.get(n)??[];a.push(r),e.set(n,a)}return vt.filter(r=>e.has(r)).map(r=>[r,e.get(r)])},ie=({children:t})=>i.jsxs("div",{style:{minHeight:"100vh",background:"#ffffff",color:"#000000",fontFamily:"'Inter Tight', sans-serif"},children:[i.jsx("style",{children:Br}),t]}),Gr=()=>{const{active:t,row:e,loading:s,progressStage:r,loadError:n,refresh:a,ack:o}=Xs(),[c,l]=g.useState("checklist"),[d,m]=g.useState("all"),[_,w]=g.useState(!1),[T,x]=g.useState(0),[C,b]=g.useState(null),[E,M]=g.useState(null),S=C??(e==null?void 0:e.carId)??null;g.useEffect(()=>{S&&chrome.runtime.sendMessage({type:"IS_SAVED",carId:S}).then(O=>w((O==null?void 0:O.saved)??!1)).catch(()=>w(!1))},[S]);const j=g.useCallback(async()=>{const O=C?E:e;if(O)if(_)await chrome.runtime.sendMessage({type:"UNSAVE_CAR",carId:O.carId}).catch(()=>{}),w(!1),x(R=>R+1);else{const R=await chrome.runtime.sendMessage({type:"SAVE_CAR",carId:O.carId,url:O.url,parsed:O.parsed}).catch(()=>({ok:!1}));if((R==null?void 0:R.reason)==="limit")return;w(!0),x(re=>re+1)}},[C,E,e,_]),X=g.useCallback(async O=>{if(e&&e.carId===O){b(null),M(null),l("checklist");return}const R=await chrome.runtime.sendMessage({type:"GET_SAVED_ONE",carId:O});R&&(M({carId:R.carId,url:R.url,parsed:R.parsed,facts:R.facts,report:R.report,cachedAt:R.updatedAt,expiresAt:R.expiresAt}),b(O),l("checklist"))},[e]),$=C?E:e,Rt=g.useMemo(()=>$?Ur($.report.results):{total:0,killers:0,warns:0,passes:0,unknowns:0},[$]),Ze=g.useMemo(()=>$?Fr($.report.results,d):[],[$,d]),Ot=g.useMemo(()=>Wr(Ze),[Ze]);if(!t||!Ft(t.url))return i.jsx(ie,{children:i.jsx(Mr,{})});const Mt=!!(e&&t.carId&&t.carId!==e.carId);if(n)return i.jsx(ie,{children:i.jsx(Lr,{reason:n,onRetry:a})});if(s||r!==null||!e||Mt)return i.jsx(ie,{children:i.jsx(mt,{stage:r,carId:t.carId??void 0,onRefresh:a})});if(!$)return i.jsx(ie,{children:i.jsx(mt,{stage:null,carId:C??void 0,onRefresh:a})});let Ve=0;const De=Ot.map(([O,R])=>{const re=Ve;return Ve+=R.length,{cat:O,rules:R,startIndex:re}});return i.jsxs(ie,{children:[C&&i.jsx("button",{style:{width:"100%",padding:"10px",fontFamily:"'Space Mono', monospace",fontSize:"10px",letterSpacing:"1.5px",textTransform:"uppercase",background:"#CCFF00",border:"none",borderBottom:"3px solid #000",cursor:"pointer"},onClick:()=>{b(null),M(null)},children:"← BACK TO LIVE TAB"}),i.jsx(rr,{score:$.report.score,verdict:$.report.verdict,killers:$.report.killers,warns:$.report.warns}),i.jsx(or,{parsed:$.parsed,carId:$.carId}),i.jsx(Ir,{saved:_,onToggle:j}),i.jsx(dr,{tab:c,onChange:l,disabledTabs:C?["ai"]:[]}),c==="checklist"&&i.jsxs(i.Fragment,{children:[i.jsx(xr,{results:$.report.results}),i.jsx(yr,{counts:Rt,active:d,onChange:m}),De.length===0?i.jsx("div",{style:{padding:24,textAlign:"center",fontFamily:"'Space Mono', monospace",fontSize:10,letterSpacing:2,textTransform:"uppercase",borderBottom:"3px solid #000"},children:"NOTHING MATCHES FILTER"}):De.map(({cat:O,rules:R,startIndex:re})=>i.jsx(Sr,{category:O,rules:R,startIndex:re,onAck:o},O)),i.jsx(Cr,{onRefresh:a,onGoToAi:()=>l("ai")})]}),c==="ai"&&i.jsx(Js,{parsed:e.parsed,facts:e.facts,report:e.report}),c==="mylist"&&i.jsx(Pr,{onViewCar:X,refreshKey:T})]})},xt=document.getElementById("app");xt&&Bt(xt).render(i.jsx(Gr,{}));
