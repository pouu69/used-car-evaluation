var Rt=Object.defineProperty;var Ve=t=>{throw TypeError(t)};var Mt=(t,e,s)=>e in t?Rt(t,e,{enumerable:!0,configurable:!0,writable:!0,value:s}):t[e]=s;var te=(t,e,s)=>Mt(t,typeof e!="symbol"?e+"":e,s),Ze=(t,e,s)=>e.has(t)||Ve("Cannot "+s);var W=(t,e,s)=>(Ze(t,e,"read from private field"),s?s.call(t):e.get(t)),G=(t,e,s)=>e.has(t)?Ve("Cannot add the same private member more than once"):e instanceof WeakSet?e.add(t):e.set(t,s),K=(t,e,s,r)=>(Ze(t,e,"write to private field"),r?r.call(t,s):e.set(t,s),s);import{j as i,r as x,R as je,a as $t,C as mt,S as gt,V as Lt,f as zt,b as Vt,g as Zt,c as Dt}from"./format-DQu_chz1.js";import{f as xt}from"./text-DLWN4rSv.js";import{i as De,a as Pe,b as Be}from"./protocol-CaJwkXUL.js";import{e as Pt,i as Bt}from"./url-bXCR0w-S.js";import"./_commonjsHelpers-Cpj98o6Y.js";const Ut=`당신은 엔카 중고차 베테랑 컨설턴트다. 룰 엔진 결과를 반영해 실전 조치를 짧게 쓴다.

원칙:
- killers/warns 는 희석 금지. unknown/hidden 추측 금지 → dataQualityWarnings.
- 원본에 없는 수치는 지어내지 않는다.

길이 규칙 (엄수):
- summary: **1~2문장, 120자 이내**. 결론 + 핵심 이유만.
- strengths: 최대 3개, 각 20자 이내, 명사구.
- concerns: 2~3개. title 15자 이내, detail 1문장 60자 이내.
- negotiationPoints: 3~4개, 각 40~70자. 실행 가능한 문장만. "확인하세요" 금지. 다음 중에서 섞어쓴다:
  · 문서 요구 (예: "카히스토리 출력본 요구")
  · 현장 점검 (예: "하체 리프트 후 프레임 용접 확인")
  · 가격 협상 (예: "누적 수리 180만 근거로 100만 인하 요구")
  · 계약 특약 (예: "인수 후 14일 내 중대결함 환불 특약")
- dataQualityWarnings: 최대 3개, 15자 이내. "OO 미공개" 형식.
- 모든 리스트 중요도 내림차순. 중복 통합.
- 금지어: "것으로 보입니다", "할 수 있습니다", "전반적으로", "편입니다".

출력:
- JSON 객체 하나만. 코드블록/설명/주석 금지.
- 한국어. 수치는 원문 단위(만원/km/회).
- severity: low | medium | high | critical
- verdict: BUY | NEGOTIATE | AVOID | UNKNOWN
- overallRisk: low | medium | high | critical

스키마:
{"verdict":"...","overallRisk":"...","summary":"...","strengths":[],"concerns":[{"title":"...","severity":"...","detail":"...","evidenceRuleIds":[]}],"negotiationPoints":[],"dataQualityWarnings":[]}`,Ft=t=>t&&t.kind==="value"?t.value:null,Ue=t=>typeof t=="number"&&Number.isFinite(t)?Math.round(t/1e4):null,Fe=t=>{if(t===null)return null;if(t>=1e4){const e=Math.floor(t/1e4),s=t%1e4;return s>0?`${e}억${s}만`:`${e}억`}return`${t}만`},Wt=t=>{if(!t)return"알 수 없음";const e=[],s=[t.category.manufacturerName,t.category.modelName].filter(Boolean).join(" ");s&&e.push(s);const r=t.category.gradeDetailName??t.category.gradeName;r&&e.push(r);const a=xt(t.category.yearMonth);a&&e.push(a),t.spec.mileage!==void 0&&e.push(`${t.spec.mileage.toLocaleString()}km`),t.spec.fuelName&&e.push(t.spec.fuelName),t.spec.transmissionName&&e.push(t.spec.transmissionName);const n=Ue(t.advertisement.price),o=Ue(t.category.newPrice),c=Fe(n),l=Fe(o);return c&&e.push(l?`${c}(신차 ${l})`:c),e.join("·")},Gt=t=>{switch(t.kind){case"value":return{status:"known",value:t.value};case"hidden_by_dealer":return{status:"hidden"};case"parse_failed":return{status:"failed",reason:t.reason};case"loading":case"timeout":return{status:"pending"}}},Kt=t=>{const e={},s=[],r=[],a=[["insuranceHistoryDisclosed",t.insuranceHistoryDisclosed],["inspectionReportDisclosed",t.inspectionReportDisclosed],["hasEncarDiagnosis",t.hasEncarDiagnosis],["frameDamage",t.frameDamage],["usageHistory",t.usageHistory],["totalLossHistory",t.totalLossHistory],["ownerChangeCount",t.ownerChangeCount],["insuranceGap",t.insuranceGap],["unconfirmedAccident",t.unconfirmedAccident],["minorAccidents",t.minorAccidents],["priceVsMarket",t.priceVsMarket]];for(const[n,o]of a){const c=Gt(o);c.status==="known"?e[n]=c.value:c.status==="hidden"?r.push(n):s.push(n)}return{known:e,unknown:s,hidden:r}},We=t=>({id:t.ruleId,msg:t.message}),Ht=t=>{const e=Ft(t.parsed.raw.base),s=Kt(t.facts),r={car:Wt(e),preVerified:(e==null?void 0:e.advertisement.preVerified)??null,verdict:t.report.verdict,killers:t.report.killers.map(We),warns:t.report.warns.map(We),facts:s.known,unknown:s.unknown};return s.hidden.length>0&&(r.hidden=s.hidden),t.facts.bridgeWarnings.length>0&&(r.bridgeWarnings=t.facts.bridgeWarnings),r},Yt=t=>{const e=Ht(t);return["엔카 매물을 평가. 시스템 프롬프트의 길이 규칙 준수. JSON 객체 하나만.","",`[차량] ${e.car}`,`[preVerified] ${e.preVerified??"unknown"}`,`[룰엔진 verdict] ${e.verdict}`,`[killers] ${JSON.stringify(e.killers)}`,`[warns] ${JSON.stringify(e.warns)}`,`[known facts] ${JSON.stringify(e.facts)}`,`[unknown fields] ${e.unknown.join(", ")||"(없음)"}`,e.hidden?`[hidden by dealer] ${e.hidden.join(", ")}`:"",e.bridgeWarnings?`[bridge warnings] ${e.bridgeWarnings.join("; ")}`:"","","판정:","- killers≥1 → AVOID","- warns만 → NEGOTIATE","- 깨끗하고 known 충분 → BUY","- known<50% → UNKNOWN","",'특히 negotiationPoints는 딜러와 실제로 말할 수 있는 구체적 문장으로. 단순 "확인하세요" 금지.'].filter(s=>s!=="").join(`
`)},Jt=t=>({system:Ut,user:Yt(t)});var C;(function(t){t.assertEqual=a=>{};function e(a){}t.assertIs=e;function s(a){throw new Error}t.assertNever=s,t.arrayToEnum=a=>{const n={};for(const o of a)n[o]=o;return n},t.getValidEnumValues=a=>{const n=t.objectKeys(a).filter(c=>typeof a[a[c]]!="number"),o={};for(const c of n)o[c]=a[c];return t.objectValues(o)},t.objectValues=a=>t.objectKeys(a).map(function(n){return a[n]}),t.objectKeys=typeof Object.keys=="function"?a=>Object.keys(a):a=>{const n=[];for(const o in a)Object.prototype.hasOwnProperty.call(a,o)&&n.push(o);return n},t.find=(a,n)=>{for(const o of a)if(n(o))return o},t.isInteger=typeof Number.isInteger=="function"?a=>Number.isInteger(a):a=>typeof a=="number"&&Number.isFinite(a)&&Math.floor(a)===a;function r(a,n=" | "){return a.map(o=>typeof o=="string"?`'${o}'`:o).join(n)}t.joinValues=r,t.jsonStringifyReplacer=(a,n)=>typeof n=="bigint"?n.toString():n})(C||(C={}));var Ge;(function(t){t.mergeShapes=(e,s)=>({...e,...s})})(Ge||(Ge={}));const p=C.arrayToEnum(["string","nan","number","integer","float","boolean","date","bigint","symbol","function","undefined","null","array","object","unknown","promise","void","never","map","set"]),V=t=>{switch(typeof t){case"undefined":return p.undefined;case"string":return p.string;case"number":return Number.isNaN(t)?p.nan:p.number;case"boolean":return p.boolean;case"function":return p.function;case"bigint":return p.bigint;case"symbol":return p.symbol;case"object":return Array.isArray(t)?p.array:t===null?p.null:t.then&&typeof t.then=="function"&&t.catch&&typeof t.catch=="function"?p.promise:typeof Map<"u"&&t instanceof Map?p.map:typeof Set<"u"&&t instanceof Set?p.set:typeof Date<"u"&&t instanceof Date?p.date:p.object;default:return p.unknown}},u=C.arrayToEnum(["invalid_type","invalid_literal","custom","invalid_union","invalid_union_discriminator","invalid_enum_value","unrecognized_keys","invalid_arguments","invalid_return_type","invalid_date","invalid_string","too_small","too_big","invalid_intersection_types","not_multiple_of","not_finite"]);class z extends Error{get errors(){return this.issues}constructor(e){super(),this.issues=[],this.addIssue=r=>{this.issues=[...this.issues,r]},this.addIssues=(r=[])=>{this.issues=[...this.issues,...r]};const s=new.target.prototype;Object.setPrototypeOf?Object.setPrototypeOf(this,s):this.__proto__=s,this.name="ZodError",this.issues=e}format(e){const s=e||function(n){return n.message},r={_errors:[]},a=n=>{for(const o of n.issues)if(o.code==="invalid_union")o.unionErrors.map(a);else if(o.code==="invalid_return_type")a(o.returnTypeError);else if(o.code==="invalid_arguments")a(o.argumentsError);else if(o.path.length===0)r._errors.push(s(o));else{let c=r,l=0;for(;l<o.path.length;){const d=o.path[l];l===o.path.length-1?(c[d]=c[d]||{_errors:[]},c[d]._errors.push(s(o))):c[d]=c[d]||{_errors:[]},c=c[d],l++}}};return a(this),r}static assert(e){if(!(e instanceof z))throw new Error(`Not a ZodError: ${e}`)}toString(){return this.message}get message(){return JSON.stringify(this.issues,C.jsonStringifyReplacer,2)}get isEmpty(){return this.issues.length===0}flatten(e=s=>s.message){const s={},r=[];for(const a of this.issues)if(a.path.length>0){const n=a.path[0];s[n]=s[n]||[],s[n].push(e(a))}else r.push(e(a));return{formErrors:r,fieldErrors:s}}get formErrors(){return this.flatten()}}z.create=t=>new z(t);const Ce=(t,e)=>{let s;switch(t.code){case u.invalid_type:t.received===p.undefined?s="Required":s=`Expected ${t.expected}, received ${t.received}`;break;case u.invalid_literal:s=`Invalid literal value, expected ${JSON.stringify(t.expected,C.jsonStringifyReplacer)}`;break;case u.unrecognized_keys:s=`Unrecognized key(s) in object: ${C.joinValues(t.keys,", ")}`;break;case u.invalid_union:s="Invalid input";break;case u.invalid_union_discriminator:s=`Invalid discriminator value. Expected ${C.joinValues(t.options)}`;break;case u.invalid_enum_value:s=`Invalid enum value. Expected ${C.joinValues(t.options)}, received '${t.received}'`;break;case u.invalid_arguments:s="Invalid function arguments";break;case u.invalid_return_type:s="Invalid function return type";break;case u.invalid_date:s="Invalid date";break;case u.invalid_string:typeof t.validation=="object"?"includes"in t.validation?(s=`Invalid input: must include "${t.validation.includes}"`,typeof t.validation.position=="number"&&(s=`${s} at one or more positions greater than or equal to ${t.validation.position}`)):"startsWith"in t.validation?s=`Invalid input: must start with "${t.validation.startsWith}"`:"endsWith"in t.validation?s=`Invalid input: must end with "${t.validation.endsWith}"`:C.assertNever(t.validation):t.validation!=="regex"?s=`Invalid ${t.validation}`:s="Invalid";break;case u.too_small:t.type==="array"?s=`Array must contain ${t.exact?"exactly":t.inclusive?"at least":"more than"} ${t.minimum} element(s)`:t.type==="string"?s=`String must contain ${t.exact?"exactly":t.inclusive?"at least":"over"} ${t.minimum} character(s)`:t.type==="number"?s=`Number must be ${t.exact?"exactly equal to ":t.inclusive?"greater than or equal to ":"greater than "}${t.minimum}`:t.type==="bigint"?s=`Number must be ${t.exact?"exactly equal to ":t.inclusive?"greater than or equal to ":"greater than "}${t.minimum}`:t.type==="date"?s=`Date must be ${t.exact?"exactly equal to ":t.inclusive?"greater than or equal to ":"greater than "}${new Date(Number(t.minimum))}`:s="Invalid input";break;case u.too_big:t.type==="array"?s=`Array must contain ${t.exact?"exactly":t.inclusive?"at most":"less than"} ${t.maximum} element(s)`:t.type==="string"?s=`String must contain ${t.exact?"exactly":t.inclusive?"at most":"under"} ${t.maximum} character(s)`:t.type==="number"?s=`Number must be ${t.exact?"exactly":t.inclusive?"less than or equal to":"less than"} ${t.maximum}`:t.type==="bigint"?s=`BigInt must be ${t.exact?"exactly":t.inclusive?"less than or equal to":"less than"} ${t.maximum}`:t.type==="date"?s=`Date must be ${t.exact?"exactly":t.inclusive?"smaller than or equal to":"smaller than"} ${new Date(Number(t.maximum))}`:s="Invalid input";break;case u.custom:s="Invalid input";break;case u.invalid_intersection_types:s="Intersection results could not be merged";break;case u.not_multiple_of:s=`Number must be a multiple of ${t.multipleOf}`;break;case u.not_finite:s="Number must be finite";break;default:s=e.defaultError,C.assertNever(t)}return{message:s}};let Xt=Ce;function Qt(){return Xt}const qt=t=>{const{data:e,path:s,errorMaps:r,issueData:a}=t,n=[...s,...a.path||[]],o={...a,path:n};if(a.message!==void 0)return{...a,path:n,message:a.message};let c="";const l=r.filter(d=>!!d).slice().reverse();for(const d of l)c=d(o,{data:e,defaultError:c}).message;return{...a,path:n,message:c}};function f(t,e){const s=Qt(),r=qt({issueData:e,data:t.data,path:t.path,errorMaps:[t.common.contextualErrorMap,t.schemaErrorMap,s,s===Ce?void 0:Ce].filter(a=>!!a)});t.common.issues.push(r)}class R{constructor(){this.value="valid"}dirty(){this.value==="valid"&&(this.value="dirty")}abort(){this.value!=="aborted"&&(this.value="aborted")}static mergeArray(e,s){const r=[];for(const a of s){if(a.status==="aborted")return v;a.status==="dirty"&&e.dirty(),r.push(a.value)}return{status:e.value,value:r}}static async mergeObjectAsync(e,s){const r=[];for(const a of s){const n=await a.key,o=await a.value;r.push({key:n,value:o})}return R.mergeObjectSync(e,r)}static mergeObjectSync(e,s){const r={};for(const a of s){const{key:n,value:o}=a;if(n.status==="aborted"||o.status==="aborted")return v;n.status==="dirty"&&e.dirty(),o.status==="dirty"&&e.dirty(),n.value!=="__proto__"&&(typeof o.value<"u"||a.alwaysSet)&&(r[n.value]=o.value)}return{status:e.value,value:r}}}const v=Object.freeze({status:"aborted"}),ae=t=>({status:"dirty",value:t}),M=t=>({status:"valid",value:t}),Ke=t=>t.status==="aborted",He=t=>t.status==="dirty",X=t=>t.status==="valid",be=t=>typeof Promise<"u"&&t instanceof Promise;var h;(function(t){t.errToObj=e=>typeof e=="string"?{message:e}:e||{},t.toString=e=>typeof e=="string"?e:e==null?void 0:e.message})(h||(h={}));class P{constructor(e,s,r,a){this._cachedPath=[],this.parent=e,this.data=s,this._path=r,this._key=a}get path(){return this._cachedPath.length||(Array.isArray(this._key)?this._cachedPath.push(...this._path,...this._key):this._cachedPath.push(...this._path,this._key)),this._cachedPath}}const Ye=(t,e)=>{if(X(e))return{success:!0,data:e.value};if(!t.common.issues.length)throw new Error("Validation failed but no issues detected.");return{success:!1,get error(){if(this._error)return this._error;const s=new z(t.common.issues);return this._error=s,this._error}}};function N(t){if(!t)return{};const{errorMap:e,invalid_type_error:s,required_error:r,description:a}=t;if(e&&(s||r))throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);return e?{errorMap:e,description:a}:{errorMap:(o,c)=>{const{message:l}=t;return o.code==="invalid_enum_value"?{message:l??c.defaultError}:typeof c.data>"u"?{message:l??r??c.defaultError}:o.code!=="invalid_type"?{message:c.defaultError}:{message:l??s??c.defaultError}},description:a}}class S{get description(){return this._def.description}_getType(e){return V(e.data)}_getOrReturnCtx(e,s){return s||{common:e.parent.common,data:e.data,parsedType:V(e.data),schemaErrorMap:this._def.errorMap,path:e.path,parent:e.parent}}_processInputParams(e){return{status:new R,ctx:{common:e.parent.common,data:e.data,parsedType:V(e.data),schemaErrorMap:this._def.errorMap,path:e.path,parent:e.parent}}}_parseSync(e){const s=this._parse(e);if(be(s))throw new Error("Synchronous parse encountered promise.");return s}_parseAsync(e){const s=this._parse(e);return Promise.resolve(s)}parse(e,s){const r=this.safeParse(e,s);if(r.success)return r.data;throw r.error}safeParse(e,s){const r={common:{issues:[],async:(s==null?void 0:s.async)??!1,contextualErrorMap:s==null?void 0:s.errorMap},path:(s==null?void 0:s.path)||[],schemaErrorMap:this._def.errorMap,parent:null,data:e,parsedType:V(e)},a=this._parseSync({data:e,path:r.path,parent:r});return Ye(r,a)}"~validate"(e){var r,a;const s={common:{issues:[],async:!!this["~standard"].async},path:[],schemaErrorMap:this._def.errorMap,parent:null,data:e,parsedType:V(e)};if(!this["~standard"].async)try{const n=this._parseSync({data:e,path:[],parent:s});return X(n)?{value:n.value}:{issues:s.common.issues}}catch(n){(a=(r=n==null?void 0:n.message)==null?void 0:r.toLowerCase())!=null&&a.includes("encountered")&&(this["~standard"].async=!0),s.common={issues:[],async:!0}}return this._parseAsync({data:e,path:[],parent:s}).then(n=>X(n)?{value:n.value}:{issues:s.common.issues})}async parseAsync(e,s){const r=await this.safeParseAsync(e,s);if(r.success)return r.data;throw r.error}async safeParseAsync(e,s){const r={common:{issues:[],contextualErrorMap:s==null?void 0:s.errorMap,async:!0},path:(s==null?void 0:s.path)||[],schemaErrorMap:this._def.errorMap,parent:null,data:e,parsedType:V(e)},a=this._parse({data:e,path:r.path,parent:r}),n=await(be(a)?a:Promise.resolve(a));return Ye(r,n)}refine(e,s){const r=a=>typeof s=="string"||typeof s>"u"?{message:s}:typeof s=="function"?s(a):s;return this._refinement((a,n)=>{const o=e(a),c=()=>n.addIssue({code:u.custom,...r(a)});return typeof Promise<"u"&&o instanceof Promise?o.then(l=>l?!0:(c(),!1)):o?!0:(c(),!1)})}refinement(e,s){return this._refinement((r,a)=>e(r)?!0:(a.addIssue(typeof s=="function"?s(r,a):s),!1))}_refinement(e){return new q({schema:this,typeName:y.ZodEffects,effect:{type:"refinement",refinement:e}})}superRefine(e){return this._refinement(e)}constructor(e){this.spa=this.safeParseAsync,this._def=e,this.parse=this.parse.bind(this),this.safeParse=this.safeParse.bind(this),this.parseAsync=this.parseAsync.bind(this),this.safeParseAsync=this.safeParseAsync.bind(this),this.spa=this.spa.bind(this),this.refine=this.refine.bind(this),this.refinement=this.refinement.bind(this),this.superRefine=this.superRefine.bind(this),this.optional=this.optional.bind(this),this.nullable=this.nullable.bind(this),this.nullish=this.nullish.bind(this),this.array=this.array.bind(this),this.promise=this.promise.bind(this),this.or=this.or.bind(this),this.and=this.and.bind(this),this.transform=this.transform.bind(this),this.brand=this.brand.bind(this),this.default=this.default.bind(this),this.catch=this.catch.bind(this),this.describe=this.describe.bind(this),this.pipe=this.pipe.bind(this),this.readonly=this.readonly.bind(this),this.isNullable=this.isNullable.bind(this),this.isOptional=this.isOptional.bind(this),this["~standard"]={version:1,vendor:"zod",validate:s=>this["~validate"](s)}}optional(){return D.create(this,this._def)}nullable(){return ee.create(this,this._def)}nullish(){return this.nullable().optional()}array(){return L.create(this)}promise(){return Ne.create(this,this._def)}or(e){return ke.create([this,e],this._def)}and(e){return we.create(this,e,this._def)}transform(e){return new q({...N(this._def),schema:this,typeName:y.ZodEffects,effect:{type:"transform",transform:e}})}default(e){const s=typeof e=="function"?e:()=>e;return new Ee({...N(this._def),innerType:this,defaultValue:s,typeName:y.ZodDefault})}brand(){return new ks({typeName:y.ZodBranded,type:this,...N(this._def)})}catch(e){const s=typeof e=="function"?e:()=>e;return new Ie({...N(this._def),innerType:this,catchValue:s,typeName:y.ZodCatch})}describe(e){const s=this.constructor;return new s({...this._def,description:e})}pipe(e){return $e.create(this,e)}readonly(){return Oe.create(this)}isOptional(){return this.safeParse(void 0).success}isNullable(){return this.safeParse(null).success}}const es=/^c[^\s-]{8,}$/i,ts=/^[0-9a-z]+$/,ss=/^[0-9A-HJKMNP-TV-Z]{26}$/i,rs=/^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i,as=/^[a-z0-9_-]{21}$/i,ns=/^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/,is=/^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/,os=/^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i,cs="^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$";let Ae;const ls=/^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/,ds=/^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/,us=/^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/,fs=/^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/,ps=/^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/,hs=/^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/,vt="((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))",ms=new RegExp(`^${vt}$`);function yt(t){let e="[0-5]\\d";t.precision?e=`${e}\\.\\d{${t.precision}}`:t.precision==null&&(e=`${e}(\\.\\d+)?`);const s=t.precision?"+":"?";return`([01]\\d|2[0-3]):[0-5]\\d(:${e})${s}`}function gs(t){return new RegExp(`^${yt(t)}$`)}function xs(t){let e=`${vt}T${yt(t)}`;const s=[];return s.push(t.local?"Z?":"Z"),t.offset&&s.push("([+-]\\d{2}:?\\d{2})"),e=`${e}(${s.join("|")})`,new RegExp(`^${e}$`)}function vs(t,e){return!!((e==="v4"||!e)&&ls.test(t)||(e==="v6"||!e)&&us.test(t))}function ys(t,e){if(!ns.test(t))return!1;try{const[s]=t.split(".");if(!s)return!1;const r=s.replace(/-/g,"+").replace(/_/g,"/").padEnd(s.length+(4-s.length%4)%4,"="),a=JSON.parse(atob(r));return!(typeof a!="object"||a===null||"typ"in a&&(a==null?void 0:a.typ)!=="JWT"||!a.alg||e&&a.alg!==e)}catch{return!1}}function bs(t,e){return!!((e==="v4"||!e)&&ds.test(t)||(e==="v6"||!e)&&fs.test(t))}class Z extends S{_parse(e){if(this._def.coerce&&(e.data=String(e.data)),this._getType(e)!==p.string){const n=this._getOrReturnCtx(e);return f(n,{code:u.invalid_type,expected:p.string,received:n.parsedType}),v}const r=new R;let a;for(const n of this._def.checks)if(n.kind==="min")e.data.length<n.value&&(a=this._getOrReturnCtx(e,a),f(a,{code:u.too_small,minimum:n.value,type:"string",inclusive:!0,exact:!1,message:n.message}),r.dirty());else if(n.kind==="max")e.data.length>n.value&&(a=this._getOrReturnCtx(e,a),f(a,{code:u.too_big,maximum:n.value,type:"string",inclusive:!0,exact:!1,message:n.message}),r.dirty());else if(n.kind==="length"){const o=e.data.length>n.value,c=e.data.length<n.value;(o||c)&&(a=this._getOrReturnCtx(e,a),o?f(a,{code:u.too_big,maximum:n.value,type:"string",inclusive:!0,exact:!0,message:n.message}):c&&f(a,{code:u.too_small,minimum:n.value,type:"string",inclusive:!0,exact:!0,message:n.message}),r.dirty())}else if(n.kind==="email")os.test(e.data)||(a=this._getOrReturnCtx(e,a),f(a,{validation:"email",code:u.invalid_string,message:n.message}),r.dirty());else if(n.kind==="emoji")Ae||(Ae=new RegExp(cs,"u")),Ae.test(e.data)||(a=this._getOrReturnCtx(e,a),f(a,{validation:"emoji",code:u.invalid_string,message:n.message}),r.dirty());else if(n.kind==="uuid")rs.test(e.data)||(a=this._getOrReturnCtx(e,a),f(a,{validation:"uuid",code:u.invalid_string,message:n.message}),r.dirty());else if(n.kind==="nanoid")as.test(e.data)||(a=this._getOrReturnCtx(e,a),f(a,{validation:"nanoid",code:u.invalid_string,message:n.message}),r.dirty());else if(n.kind==="cuid")es.test(e.data)||(a=this._getOrReturnCtx(e,a),f(a,{validation:"cuid",code:u.invalid_string,message:n.message}),r.dirty());else if(n.kind==="cuid2")ts.test(e.data)||(a=this._getOrReturnCtx(e,a),f(a,{validation:"cuid2",code:u.invalid_string,message:n.message}),r.dirty());else if(n.kind==="ulid")ss.test(e.data)||(a=this._getOrReturnCtx(e,a),f(a,{validation:"ulid",code:u.invalid_string,message:n.message}),r.dirty());else if(n.kind==="url")try{new URL(e.data)}catch{a=this._getOrReturnCtx(e,a),f(a,{validation:"url",code:u.invalid_string,message:n.message}),r.dirty()}else n.kind==="regex"?(n.regex.lastIndex=0,n.regex.test(e.data)||(a=this._getOrReturnCtx(e,a),f(a,{validation:"regex",code:u.invalid_string,message:n.message}),r.dirty())):n.kind==="trim"?e.data=e.data.trim():n.kind==="includes"?e.data.includes(n.value,n.position)||(a=this._getOrReturnCtx(e,a),f(a,{code:u.invalid_string,validation:{includes:n.value,position:n.position},message:n.message}),r.dirty()):n.kind==="toLowerCase"?e.data=e.data.toLowerCase():n.kind==="toUpperCase"?e.data=e.data.toUpperCase():n.kind==="startsWith"?e.data.startsWith(n.value)||(a=this._getOrReturnCtx(e,a),f(a,{code:u.invalid_string,validation:{startsWith:n.value},message:n.message}),r.dirty()):n.kind==="endsWith"?e.data.endsWith(n.value)||(a=this._getOrReturnCtx(e,a),f(a,{code:u.invalid_string,validation:{endsWith:n.value},message:n.message}),r.dirty()):n.kind==="datetime"?xs(n).test(e.data)||(a=this._getOrReturnCtx(e,a),f(a,{code:u.invalid_string,validation:"datetime",message:n.message}),r.dirty()):n.kind==="date"?ms.test(e.data)||(a=this._getOrReturnCtx(e,a),f(a,{code:u.invalid_string,validation:"date",message:n.message}),r.dirty()):n.kind==="time"?gs(n).test(e.data)||(a=this._getOrReturnCtx(e,a),f(a,{code:u.invalid_string,validation:"time",message:n.message}),r.dirty()):n.kind==="duration"?is.test(e.data)||(a=this._getOrReturnCtx(e,a),f(a,{validation:"duration",code:u.invalid_string,message:n.message}),r.dirty()):n.kind==="ip"?vs(e.data,n.version)||(a=this._getOrReturnCtx(e,a),f(a,{validation:"ip",code:u.invalid_string,message:n.message}),r.dirty()):n.kind==="jwt"?ys(e.data,n.alg)||(a=this._getOrReturnCtx(e,a),f(a,{validation:"jwt",code:u.invalid_string,message:n.message}),r.dirty()):n.kind==="cidr"?bs(e.data,n.version)||(a=this._getOrReturnCtx(e,a),f(a,{validation:"cidr",code:u.invalid_string,message:n.message}),r.dirty()):n.kind==="base64"?ps.test(e.data)||(a=this._getOrReturnCtx(e,a),f(a,{validation:"base64",code:u.invalid_string,message:n.message}),r.dirty()):n.kind==="base64url"?hs.test(e.data)||(a=this._getOrReturnCtx(e,a),f(a,{validation:"base64url",code:u.invalid_string,message:n.message}),r.dirty()):C.assertNever(n);return{status:r.value,value:e.data}}_regex(e,s,r){return this.refinement(a=>e.test(a),{validation:s,code:u.invalid_string,...h.errToObj(r)})}_addCheck(e){return new Z({...this._def,checks:[...this._def.checks,e]})}email(e){return this._addCheck({kind:"email",...h.errToObj(e)})}url(e){return this._addCheck({kind:"url",...h.errToObj(e)})}emoji(e){return this._addCheck({kind:"emoji",...h.errToObj(e)})}uuid(e){return this._addCheck({kind:"uuid",...h.errToObj(e)})}nanoid(e){return this._addCheck({kind:"nanoid",...h.errToObj(e)})}cuid(e){return this._addCheck({kind:"cuid",...h.errToObj(e)})}cuid2(e){return this._addCheck({kind:"cuid2",...h.errToObj(e)})}ulid(e){return this._addCheck({kind:"ulid",...h.errToObj(e)})}base64(e){return this._addCheck({kind:"base64",...h.errToObj(e)})}base64url(e){return this._addCheck({kind:"base64url",...h.errToObj(e)})}jwt(e){return this._addCheck({kind:"jwt",...h.errToObj(e)})}ip(e){return this._addCheck({kind:"ip",...h.errToObj(e)})}cidr(e){return this._addCheck({kind:"cidr",...h.errToObj(e)})}datetime(e){return typeof e=="string"?this._addCheck({kind:"datetime",precision:null,offset:!1,local:!1,message:e}):this._addCheck({kind:"datetime",precision:typeof(e==null?void 0:e.precision)>"u"?null:e==null?void 0:e.precision,offset:(e==null?void 0:e.offset)??!1,local:(e==null?void 0:e.local)??!1,...h.errToObj(e==null?void 0:e.message)})}date(e){return this._addCheck({kind:"date",message:e})}time(e){return typeof e=="string"?this._addCheck({kind:"time",precision:null,message:e}):this._addCheck({kind:"time",precision:typeof(e==null?void 0:e.precision)>"u"?null:e==null?void 0:e.precision,...h.errToObj(e==null?void 0:e.message)})}duration(e){return this._addCheck({kind:"duration",...h.errToObj(e)})}regex(e,s){return this._addCheck({kind:"regex",regex:e,...h.errToObj(s)})}includes(e,s){return this._addCheck({kind:"includes",value:e,position:s==null?void 0:s.position,...h.errToObj(s==null?void 0:s.message)})}startsWith(e,s){return this._addCheck({kind:"startsWith",value:e,...h.errToObj(s)})}endsWith(e,s){return this._addCheck({kind:"endsWith",value:e,...h.errToObj(s)})}min(e,s){return this._addCheck({kind:"min",value:e,...h.errToObj(s)})}max(e,s){return this._addCheck({kind:"max",value:e,...h.errToObj(s)})}length(e,s){return this._addCheck({kind:"length",value:e,...h.errToObj(s)})}nonempty(e){return this.min(1,h.errToObj(e))}trim(){return new Z({...this._def,checks:[...this._def.checks,{kind:"trim"}]})}toLowerCase(){return new Z({...this._def,checks:[...this._def.checks,{kind:"toLowerCase"}]})}toUpperCase(){return new Z({...this._def,checks:[...this._def.checks,{kind:"toUpperCase"}]})}get isDatetime(){return!!this._def.checks.find(e=>e.kind==="datetime")}get isDate(){return!!this._def.checks.find(e=>e.kind==="date")}get isTime(){return!!this._def.checks.find(e=>e.kind==="time")}get isDuration(){return!!this._def.checks.find(e=>e.kind==="duration")}get isEmail(){return!!this._def.checks.find(e=>e.kind==="email")}get isURL(){return!!this._def.checks.find(e=>e.kind==="url")}get isEmoji(){return!!this._def.checks.find(e=>e.kind==="emoji")}get isUUID(){return!!this._def.checks.find(e=>e.kind==="uuid")}get isNANOID(){return!!this._def.checks.find(e=>e.kind==="nanoid")}get isCUID(){return!!this._def.checks.find(e=>e.kind==="cuid")}get isCUID2(){return!!this._def.checks.find(e=>e.kind==="cuid2")}get isULID(){return!!this._def.checks.find(e=>e.kind==="ulid")}get isIP(){return!!this._def.checks.find(e=>e.kind==="ip")}get isCIDR(){return!!this._def.checks.find(e=>e.kind==="cidr")}get isBase64(){return!!this._def.checks.find(e=>e.kind==="base64")}get isBase64url(){return!!this._def.checks.find(e=>e.kind==="base64url")}get minLength(){let e=null;for(const s of this._def.checks)s.kind==="min"&&(e===null||s.value>e)&&(e=s.value);return e}get maxLength(){let e=null;for(const s of this._def.checks)s.kind==="max"&&(e===null||s.value<e)&&(e=s.value);return e}}Z.create=t=>new Z({checks:[],typeName:y.ZodString,coerce:(t==null?void 0:t.coerce)??!1,...N(t)});function _s(t,e){const s=(t.toString().split(".")[1]||"").length,r=(e.toString().split(".")[1]||"").length,a=s>r?s:r,n=Number.parseInt(t.toFixed(a).replace(".","")),o=Number.parseInt(e.toFixed(a).replace(".",""));return n%o/10**a}class ie extends S{constructor(){super(...arguments),this.min=this.gte,this.max=this.lte,this.step=this.multipleOf}_parse(e){if(this._def.coerce&&(e.data=Number(e.data)),this._getType(e)!==p.number){const n=this._getOrReturnCtx(e);return f(n,{code:u.invalid_type,expected:p.number,received:n.parsedType}),v}let r;const a=new R;for(const n of this._def.checks)n.kind==="int"?C.isInteger(e.data)||(r=this._getOrReturnCtx(e,r),f(r,{code:u.invalid_type,expected:"integer",received:"float",message:n.message}),a.dirty()):n.kind==="min"?(n.inclusive?e.data<n.value:e.data<=n.value)&&(r=this._getOrReturnCtx(e,r),f(r,{code:u.too_small,minimum:n.value,type:"number",inclusive:n.inclusive,exact:!1,message:n.message}),a.dirty()):n.kind==="max"?(n.inclusive?e.data>n.value:e.data>=n.value)&&(r=this._getOrReturnCtx(e,r),f(r,{code:u.too_big,maximum:n.value,type:"number",inclusive:n.inclusive,exact:!1,message:n.message}),a.dirty()):n.kind==="multipleOf"?_s(e.data,n.value)!==0&&(r=this._getOrReturnCtx(e,r),f(r,{code:u.not_multiple_of,multipleOf:n.value,message:n.message}),a.dirty()):n.kind==="finite"?Number.isFinite(e.data)||(r=this._getOrReturnCtx(e,r),f(r,{code:u.not_finite,message:n.message}),a.dirty()):C.assertNever(n);return{status:a.value,value:e.data}}gte(e,s){return this.setLimit("min",e,!0,h.toString(s))}gt(e,s){return this.setLimit("min",e,!1,h.toString(s))}lte(e,s){return this.setLimit("max",e,!0,h.toString(s))}lt(e,s){return this.setLimit("max",e,!1,h.toString(s))}setLimit(e,s,r,a){return new ie({...this._def,checks:[...this._def.checks,{kind:e,value:s,inclusive:r,message:h.toString(a)}]})}_addCheck(e){return new ie({...this._def,checks:[...this._def.checks,e]})}int(e){return this._addCheck({kind:"int",message:h.toString(e)})}positive(e){return this._addCheck({kind:"min",value:0,inclusive:!1,message:h.toString(e)})}negative(e){return this._addCheck({kind:"max",value:0,inclusive:!1,message:h.toString(e)})}nonpositive(e){return this._addCheck({kind:"max",value:0,inclusive:!0,message:h.toString(e)})}nonnegative(e){return this._addCheck({kind:"min",value:0,inclusive:!0,message:h.toString(e)})}multipleOf(e,s){return this._addCheck({kind:"multipleOf",value:e,message:h.toString(s)})}finite(e){return this._addCheck({kind:"finite",message:h.toString(e)})}safe(e){return this._addCheck({kind:"min",inclusive:!0,value:Number.MIN_SAFE_INTEGER,message:h.toString(e)})._addCheck({kind:"max",inclusive:!0,value:Number.MAX_SAFE_INTEGER,message:h.toString(e)})}get minValue(){let e=null;for(const s of this._def.checks)s.kind==="min"&&(e===null||s.value>e)&&(e=s.value);return e}get maxValue(){let e=null;for(const s of this._def.checks)s.kind==="max"&&(e===null||s.value<e)&&(e=s.value);return e}get isInt(){return!!this._def.checks.find(e=>e.kind==="int"||e.kind==="multipleOf"&&C.isInteger(e.value))}get isFinite(){let e=null,s=null;for(const r of this._def.checks){if(r.kind==="finite"||r.kind==="int"||r.kind==="multipleOf")return!0;r.kind==="min"?(s===null||r.value>s)&&(s=r.value):r.kind==="max"&&(e===null||r.value<e)&&(e=r.value)}return Number.isFinite(s)&&Number.isFinite(e)}}ie.create=t=>new ie({checks:[],typeName:y.ZodNumber,coerce:(t==null?void 0:t.coerce)||!1,...N(t)});class oe extends S{constructor(){super(...arguments),this.min=this.gte,this.max=this.lte}_parse(e){if(this._def.coerce)try{e.data=BigInt(e.data)}catch{return this._getInvalidInput(e)}if(this._getType(e)!==p.bigint)return this._getInvalidInput(e);let r;const a=new R;for(const n of this._def.checks)n.kind==="min"?(n.inclusive?e.data<n.value:e.data<=n.value)&&(r=this._getOrReturnCtx(e,r),f(r,{code:u.too_small,type:"bigint",minimum:n.value,inclusive:n.inclusive,message:n.message}),a.dirty()):n.kind==="max"?(n.inclusive?e.data>n.value:e.data>=n.value)&&(r=this._getOrReturnCtx(e,r),f(r,{code:u.too_big,type:"bigint",maximum:n.value,inclusive:n.inclusive,message:n.message}),a.dirty()):n.kind==="multipleOf"?e.data%n.value!==BigInt(0)&&(r=this._getOrReturnCtx(e,r),f(r,{code:u.not_multiple_of,multipleOf:n.value,message:n.message}),a.dirty()):C.assertNever(n);return{status:a.value,value:e.data}}_getInvalidInput(e){const s=this._getOrReturnCtx(e);return f(s,{code:u.invalid_type,expected:p.bigint,received:s.parsedType}),v}gte(e,s){return this.setLimit("min",e,!0,h.toString(s))}gt(e,s){return this.setLimit("min",e,!1,h.toString(s))}lte(e,s){return this.setLimit("max",e,!0,h.toString(s))}lt(e,s){return this.setLimit("max",e,!1,h.toString(s))}setLimit(e,s,r,a){return new oe({...this._def,checks:[...this._def.checks,{kind:e,value:s,inclusive:r,message:h.toString(a)}]})}_addCheck(e){return new oe({...this._def,checks:[...this._def.checks,e]})}positive(e){return this._addCheck({kind:"min",value:BigInt(0),inclusive:!1,message:h.toString(e)})}negative(e){return this._addCheck({kind:"max",value:BigInt(0),inclusive:!1,message:h.toString(e)})}nonpositive(e){return this._addCheck({kind:"max",value:BigInt(0),inclusive:!0,message:h.toString(e)})}nonnegative(e){return this._addCheck({kind:"min",value:BigInt(0),inclusive:!0,message:h.toString(e)})}multipleOf(e,s){return this._addCheck({kind:"multipleOf",value:e,message:h.toString(s)})}get minValue(){let e=null;for(const s of this._def.checks)s.kind==="min"&&(e===null||s.value>e)&&(e=s.value);return e}get maxValue(){let e=null;for(const s of this._def.checks)s.kind==="max"&&(e===null||s.value<e)&&(e=s.value);return e}}oe.create=t=>new oe({checks:[],typeName:y.ZodBigInt,coerce:(t==null?void 0:t.coerce)??!1,...N(t)});class Je extends S{_parse(e){if(this._def.coerce&&(e.data=!!e.data),this._getType(e)!==p.boolean){const r=this._getOrReturnCtx(e);return f(r,{code:u.invalid_type,expected:p.boolean,received:r.parsedType}),v}return M(e.data)}}Je.create=t=>new Je({typeName:y.ZodBoolean,coerce:(t==null?void 0:t.coerce)||!1,...N(t)});class _e extends S{_parse(e){if(this._def.coerce&&(e.data=new Date(e.data)),this._getType(e)!==p.date){const n=this._getOrReturnCtx(e);return f(n,{code:u.invalid_type,expected:p.date,received:n.parsedType}),v}if(Number.isNaN(e.data.getTime())){const n=this._getOrReturnCtx(e);return f(n,{code:u.invalid_date}),v}const r=new R;let a;for(const n of this._def.checks)n.kind==="min"?e.data.getTime()<n.value&&(a=this._getOrReturnCtx(e,a),f(a,{code:u.too_small,message:n.message,inclusive:!0,exact:!1,minimum:n.value,type:"date"}),r.dirty()):n.kind==="max"?e.data.getTime()>n.value&&(a=this._getOrReturnCtx(e,a),f(a,{code:u.too_big,message:n.message,inclusive:!0,exact:!1,maximum:n.value,type:"date"}),r.dirty()):C.assertNever(n);return{status:r.value,value:new Date(e.data.getTime())}}_addCheck(e){return new _e({...this._def,checks:[...this._def.checks,e]})}min(e,s){return this._addCheck({kind:"min",value:e.getTime(),message:h.toString(s)})}max(e,s){return this._addCheck({kind:"max",value:e.getTime(),message:h.toString(s)})}get minDate(){let e=null;for(const s of this._def.checks)s.kind==="min"&&(e===null||s.value>e)&&(e=s.value);return e!=null?new Date(e):null}get maxDate(){let e=null;for(const s of this._def.checks)s.kind==="max"&&(e===null||s.value<e)&&(e=s.value);return e!=null?new Date(e):null}}_e.create=t=>new _e({checks:[],coerce:(t==null?void 0:t.coerce)||!1,typeName:y.ZodDate,...N(t)});class Xe extends S{_parse(e){if(this._getType(e)!==p.symbol){const r=this._getOrReturnCtx(e);return f(r,{code:u.invalid_type,expected:p.symbol,received:r.parsedType}),v}return M(e.data)}}Xe.create=t=>new Xe({typeName:y.ZodSymbol,...N(t)});class Qe extends S{_parse(e){if(this._getType(e)!==p.undefined){const r=this._getOrReturnCtx(e);return f(r,{code:u.invalid_type,expected:p.undefined,received:r.parsedType}),v}return M(e.data)}}Qe.create=t=>new Qe({typeName:y.ZodUndefined,...N(t)});class qe extends S{_parse(e){if(this._getType(e)!==p.null){const r=this._getOrReturnCtx(e);return f(r,{code:u.invalid_type,expected:p.null,received:r.parsedType}),v}return M(e.data)}}qe.create=t=>new qe({typeName:y.ZodNull,...N(t)});class et extends S{constructor(){super(...arguments),this._any=!0}_parse(e){return M(e.data)}}et.create=t=>new et({typeName:y.ZodAny,...N(t)});class tt extends S{constructor(){super(...arguments),this._unknown=!0}_parse(e){return M(e.data)}}tt.create=t=>new tt({typeName:y.ZodUnknown,...N(t)});class B extends S{_parse(e){const s=this._getOrReturnCtx(e);return f(s,{code:u.invalid_type,expected:p.never,received:s.parsedType}),v}}B.create=t=>new B({typeName:y.ZodNever,...N(t)});class st extends S{_parse(e){if(this._getType(e)!==p.undefined){const r=this._getOrReturnCtx(e);return f(r,{code:u.invalid_type,expected:p.void,received:r.parsedType}),v}return M(e.data)}}st.create=t=>new st({typeName:y.ZodVoid,...N(t)});class L extends S{_parse(e){const{ctx:s,status:r}=this._processInputParams(e),a=this._def;if(s.parsedType!==p.array)return f(s,{code:u.invalid_type,expected:p.array,received:s.parsedType}),v;if(a.exactLength!==null){const o=s.data.length>a.exactLength.value,c=s.data.length<a.exactLength.value;(o||c)&&(f(s,{code:o?u.too_big:u.too_small,minimum:c?a.exactLength.value:void 0,maximum:o?a.exactLength.value:void 0,type:"array",inclusive:!0,exact:!0,message:a.exactLength.message}),r.dirty())}if(a.minLength!==null&&s.data.length<a.minLength.value&&(f(s,{code:u.too_small,minimum:a.minLength.value,type:"array",inclusive:!0,exact:!1,message:a.minLength.message}),r.dirty()),a.maxLength!==null&&s.data.length>a.maxLength.value&&(f(s,{code:u.too_big,maximum:a.maxLength.value,type:"array",inclusive:!0,exact:!1,message:a.maxLength.message}),r.dirty()),s.common.async)return Promise.all([...s.data].map((o,c)=>a.type._parseAsync(new P(s,o,s.path,c)))).then(o=>R.mergeArray(r,o));const n=[...s.data].map((o,c)=>a.type._parseSync(new P(s,o,s.path,c)));return R.mergeArray(r,n)}get element(){return this._def.type}min(e,s){return new L({...this._def,minLength:{value:e,message:h.toString(s)}})}max(e,s){return new L({...this._def,maxLength:{value:e,message:h.toString(s)}})}length(e,s){return new L({...this._def,exactLength:{value:e,message:h.toString(s)}})}nonempty(e){return this.min(1,e)}}L.create=(t,e)=>new L({type:t,minLength:null,maxLength:null,exactLength:null,typeName:y.ZodArray,...N(e)});function J(t){if(t instanceof T){const e={};for(const s in t.shape){const r=t.shape[s];e[s]=D.create(J(r))}return new T({...t._def,shape:()=>e})}else return t instanceof L?new L({...t._def,type:J(t.element)}):t instanceof D?D.create(J(t.unwrap())):t instanceof ee?ee.create(J(t.unwrap())):t instanceof Y?Y.create(t.items.map(e=>J(e))):t}class T extends S{constructor(){super(...arguments),this._cached=null,this.nonstrict=this.passthrough,this.augment=this.extend}_getCached(){if(this._cached!==null)return this._cached;const e=this._def.shape(),s=C.objectKeys(e);return this._cached={shape:e,keys:s},this._cached}_parse(e){if(this._getType(e)!==p.object){const d=this._getOrReturnCtx(e);return f(d,{code:u.invalid_type,expected:p.object,received:d.parsedType}),v}const{status:r,ctx:a}=this._processInputParams(e),{shape:n,keys:o}=this._getCached(),c=[];if(!(this._def.catchall instanceof B&&this._def.unknownKeys==="strip"))for(const d in a.data)o.includes(d)||c.push(d);const l=[];for(const d of o){const m=n[d],k=a.data[d];l.push({key:{status:"valid",value:d},value:m._parse(new P(a,k,a.path,d)),alwaysSet:d in a.data})}if(this._def.catchall instanceof B){const d=this._def.unknownKeys;if(d==="passthrough")for(const m of c)l.push({key:{status:"valid",value:m},value:{status:"valid",value:a.data[m]}});else if(d==="strict")c.length>0&&(f(a,{code:u.unrecognized_keys,keys:c}),r.dirty());else if(d!=="strip")throw new Error("Internal ZodObject error: invalid unknownKeys value.")}else{const d=this._def.catchall;for(const m of c){const k=a.data[m];l.push({key:{status:"valid",value:m},value:d._parse(new P(a,k,a.path,m)),alwaysSet:m in a.data})}}return a.common.async?Promise.resolve().then(async()=>{const d=[];for(const m of l){const k=await m.key,j=await m.value;d.push({key:k,value:j,alwaysSet:m.alwaysSet})}return d}).then(d=>R.mergeObjectSync(r,d)):R.mergeObjectSync(r,l)}get shape(){return this._def.shape()}strict(e){return h.errToObj,new T({...this._def,unknownKeys:"strict",...e!==void 0?{errorMap:(s,r)=>{var n,o;const a=((o=(n=this._def).errorMap)==null?void 0:o.call(n,s,r).message)??r.defaultError;return s.code==="unrecognized_keys"?{message:h.errToObj(e).message??a}:{message:a}}}:{}})}strip(){return new T({...this._def,unknownKeys:"strip"})}passthrough(){return new T({...this._def,unknownKeys:"passthrough"})}extend(e){return new T({...this._def,shape:()=>({...this._def.shape(),...e})})}merge(e){return new T({unknownKeys:e._def.unknownKeys,catchall:e._def.catchall,shape:()=>({...this._def.shape(),...e._def.shape()}),typeName:y.ZodObject})}setKey(e,s){return this.augment({[e]:s})}catchall(e){return new T({...this._def,catchall:e})}pick(e){const s={};for(const r of C.objectKeys(e))e[r]&&this.shape[r]&&(s[r]=this.shape[r]);return new T({...this._def,shape:()=>s})}omit(e){const s={};for(const r of C.objectKeys(this.shape))e[r]||(s[r]=this.shape[r]);return new T({...this._def,shape:()=>s})}deepPartial(){return J(this)}partial(e){const s={};for(const r of C.objectKeys(this.shape)){const a=this.shape[r];e&&!e[r]?s[r]=a:s[r]=a.optional()}return new T({...this._def,shape:()=>s})}required(e){const s={};for(const r of C.objectKeys(this.shape))if(e&&!e[r])s[r]=this.shape[r];else{let n=this.shape[r];for(;n instanceof D;)n=n._def.innerType;s[r]=n}return new T({...this._def,shape:()=>s})}keyof(){return bt(C.objectKeys(this.shape))}}T.create=(t,e)=>new T({shape:()=>t,unknownKeys:"strip",catchall:B.create(),typeName:y.ZodObject,...N(e)});T.strictCreate=(t,e)=>new T({shape:()=>t,unknownKeys:"strict",catchall:B.create(),typeName:y.ZodObject,...N(e)});T.lazycreate=(t,e)=>new T({shape:t,unknownKeys:"strip",catchall:B.create(),typeName:y.ZodObject,...N(e)});class ke extends S{_parse(e){const{ctx:s}=this._processInputParams(e),r=this._def.options;function a(n){for(const c of n)if(c.result.status==="valid")return c.result;for(const c of n)if(c.result.status==="dirty")return s.common.issues.push(...c.ctx.common.issues),c.result;const o=n.map(c=>new z(c.ctx.common.issues));return f(s,{code:u.invalid_union,unionErrors:o}),v}if(s.common.async)return Promise.all(r.map(async n=>{const o={...s,common:{...s.common,issues:[]},parent:null};return{result:await n._parseAsync({data:s.data,path:s.path,parent:o}),ctx:o}})).then(a);{let n;const o=[];for(const l of r){const d={...s,common:{...s.common,issues:[]},parent:null},m=l._parseSync({data:s.data,path:s.path,parent:d});if(m.status==="valid")return m;m.status==="dirty"&&!n&&(n={result:m,ctx:d}),d.common.issues.length&&o.push(d.common.issues)}if(n)return s.common.issues.push(...n.ctx.common.issues),n.result;const c=o.map(l=>new z(l));return f(s,{code:u.invalid_union,unionErrors:c}),v}}get options(){return this._def.options}}ke.create=(t,e)=>new ke({options:t,typeName:y.ZodUnion,...N(e)});function Te(t,e){const s=V(t),r=V(e);if(t===e)return{valid:!0,data:t};if(s===p.object&&r===p.object){const a=C.objectKeys(e),n=C.objectKeys(t).filter(c=>a.indexOf(c)!==-1),o={...t,...e};for(const c of n){const l=Te(t[c],e[c]);if(!l.valid)return{valid:!1};o[c]=l.data}return{valid:!0,data:o}}else if(s===p.array&&r===p.array){if(t.length!==e.length)return{valid:!1};const a=[];for(let n=0;n<t.length;n++){const o=t[n],c=e[n],l=Te(o,c);if(!l.valid)return{valid:!1};a.push(l.data)}return{valid:!0,data:a}}else return s===p.date&&r===p.date&&+t==+e?{valid:!0,data:t}:{valid:!1}}class we extends S{_parse(e){const{status:s,ctx:r}=this._processInputParams(e),a=(n,o)=>{if(Ke(n)||Ke(o))return v;const c=Te(n.value,o.value);return c.valid?((He(n)||He(o))&&s.dirty(),{status:s.value,value:c.data}):(f(r,{code:u.invalid_intersection_types}),v)};return r.common.async?Promise.all([this._def.left._parseAsync({data:r.data,path:r.path,parent:r}),this._def.right._parseAsync({data:r.data,path:r.path,parent:r})]).then(([n,o])=>a(n,o)):a(this._def.left._parseSync({data:r.data,path:r.path,parent:r}),this._def.right._parseSync({data:r.data,path:r.path,parent:r}))}}we.create=(t,e,s)=>new we({left:t,right:e,typeName:y.ZodIntersection,...N(s)});class Y extends S{_parse(e){const{status:s,ctx:r}=this._processInputParams(e);if(r.parsedType!==p.array)return f(r,{code:u.invalid_type,expected:p.array,received:r.parsedType}),v;if(r.data.length<this._def.items.length)return f(r,{code:u.too_small,minimum:this._def.items.length,inclusive:!0,exact:!1,type:"array"}),v;!this._def.rest&&r.data.length>this._def.items.length&&(f(r,{code:u.too_big,maximum:this._def.items.length,inclusive:!0,exact:!1,type:"array"}),s.dirty());const n=[...r.data].map((o,c)=>{const l=this._def.items[c]||this._def.rest;return l?l._parse(new P(r,o,r.path,c)):null}).filter(o=>!!o);return r.common.async?Promise.all(n).then(o=>R.mergeArray(s,o)):R.mergeArray(s,n)}get items(){return this._def.items}rest(e){return new Y({...this._def,rest:e})}}Y.create=(t,e)=>{if(!Array.isArray(t))throw new Error("You must pass an array of schemas to z.tuple([ ... ])");return new Y({items:t,typeName:y.ZodTuple,rest:null,...N(e)})};class rt extends S{get keySchema(){return this._def.keyType}get valueSchema(){return this._def.valueType}_parse(e){const{status:s,ctx:r}=this._processInputParams(e);if(r.parsedType!==p.map)return f(r,{code:u.invalid_type,expected:p.map,received:r.parsedType}),v;const a=this._def.keyType,n=this._def.valueType,o=[...r.data.entries()].map(([c,l],d)=>({key:a._parse(new P(r,c,r.path,[d,"key"])),value:n._parse(new P(r,l,r.path,[d,"value"]))}));if(r.common.async){const c=new Map;return Promise.resolve().then(async()=>{for(const l of o){const d=await l.key,m=await l.value;if(d.status==="aborted"||m.status==="aborted")return v;(d.status==="dirty"||m.status==="dirty")&&s.dirty(),c.set(d.value,m.value)}return{status:s.value,value:c}})}else{const c=new Map;for(const l of o){const d=l.key,m=l.value;if(d.status==="aborted"||m.status==="aborted")return v;(d.status==="dirty"||m.status==="dirty")&&s.dirty(),c.set(d.value,m.value)}return{status:s.value,value:c}}}}rt.create=(t,e,s)=>new rt({valueType:e,keyType:t,typeName:y.ZodMap,...N(s)});class ce extends S{_parse(e){const{status:s,ctx:r}=this._processInputParams(e);if(r.parsedType!==p.set)return f(r,{code:u.invalid_type,expected:p.set,received:r.parsedType}),v;const a=this._def;a.minSize!==null&&r.data.size<a.minSize.value&&(f(r,{code:u.too_small,minimum:a.minSize.value,type:"set",inclusive:!0,exact:!1,message:a.minSize.message}),s.dirty()),a.maxSize!==null&&r.data.size>a.maxSize.value&&(f(r,{code:u.too_big,maximum:a.maxSize.value,type:"set",inclusive:!0,exact:!1,message:a.maxSize.message}),s.dirty());const n=this._def.valueType;function o(l){const d=new Set;for(const m of l){if(m.status==="aborted")return v;m.status==="dirty"&&s.dirty(),d.add(m.value)}return{status:s.value,value:d}}const c=[...r.data.values()].map((l,d)=>n._parse(new P(r,l,r.path,d)));return r.common.async?Promise.all(c).then(l=>o(l)):o(c)}min(e,s){return new ce({...this._def,minSize:{value:e,message:h.toString(s)}})}max(e,s){return new ce({...this._def,maxSize:{value:e,message:h.toString(s)}})}size(e,s){return this.min(e,s).max(e,s)}nonempty(e){return this.min(1,e)}}ce.create=(t,e)=>new ce({valueType:t,minSize:null,maxSize:null,typeName:y.ZodSet,...N(e)});class at extends S{get schema(){return this._def.getter()}_parse(e){const{ctx:s}=this._processInputParams(e);return this._def.getter()._parse({data:s.data,path:s.path,parent:s})}}at.create=(t,e)=>new at({getter:t,typeName:y.ZodLazy,...N(e)});class nt extends S{_parse(e){if(e.data!==this._def.value){const s=this._getOrReturnCtx(e);return f(s,{received:s.data,code:u.invalid_literal,expected:this._def.value}),v}return{status:"valid",value:e.data}}get value(){return this._def.value}}nt.create=(t,e)=>new nt({value:t,typeName:y.ZodLiteral,...N(e)});function bt(t,e){return new Q({values:t,typeName:y.ZodEnum,...N(e)})}class Q extends S{_parse(e){if(typeof e.data!="string"){const s=this._getOrReturnCtx(e),r=this._def.values;return f(s,{expected:C.joinValues(r),received:s.parsedType,code:u.invalid_type}),v}if(this._cache||(this._cache=new Set(this._def.values)),!this._cache.has(e.data)){const s=this._getOrReturnCtx(e),r=this._def.values;return f(s,{received:s.data,code:u.invalid_enum_value,options:r}),v}return M(e.data)}get options(){return this._def.values}get enum(){const e={};for(const s of this._def.values)e[s]=s;return e}get Values(){const e={};for(const s of this._def.values)e[s]=s;return e}get Enum(){const e={};for(const s of this._def.values)e[s]=s;return e}extract(e,s=this._def){return Q.create(e,{...this._def,...s})}exclude(e,s=this._def){return Q.create(this.options.filter(r=>!e.includes(r)),{...this._def,...s})}}Q.create=bt;class it extends S{_parse(e){const s=C.getValidEnumValues(this._def.values),r=this._getOrReturnCtx(e);if(r.parsedType!==p.string&&r.parsedType!==p.number){const a=C.objectValues(s);return f(r,{expected:C.joinValues(a),received:r.parsedType,code:u.invalid_type}),v}if(this._cache||(this._cache=new Set(C.getValidEnumValues(this._def.values))),!this._cache.has(e.data)){const a=C.objectValues(s);return f(r,{received:r.data,code:u.invalid_enum_value,options:a}),v}return M(e.data)}get enum(){return this._def.values}}it.create=(t,e)=>new it({values:t,typeName:y.ZodNativeEnum,...N(e)});class Ne extends S{unwrap(){return this._def.type}_parse(e){const{ctx:s}=this._processInputParams(e);if(s.parsedType!==p.promise&&s.common.async===!1)return f(s,{code:u.invalid_type,expected:p.promise,received:s.parsedType}),v;const r=s.parsedType===p.promise?s.data:Promise.resolve(s.data);return M(r.then(a=>this._def.type.parseAsync(a,{path:s.path,errorMap:s.common.contextualErrorMap})))}}Ne.create=(t,e)=>new Ne({type:t,typeName:y.ZodPromise,...N(e)});class q extends S{innerType(){return this._def.schema}sourceType(){return this._def.schema._def.typeName===y.ZodEffects?this._def.schema.sourceType():this._def.schema}_parse(e){const{status:s,ctx:r}=this._processInputParams(e),a=this._def.effect||null,n={addIssue:o=>{f(r,o),o.fatal?s.abort():s.dirty()},get path(){return r.path}};if(n.addIssue=n.addIssue.bind(n),a.type==="preprocess"){const o=a.transform(r.data,n);if(r.common.async)return Promise.resolve(o).then(async c=>{if(s.value==="aborted")return v;const l=await this._def.schema._parseAsync({data:c,path:r.path,parent:r});return l.status==="aborted"?v:l.status==="dirty"||s.value==="dirty"?ae(l.value):l});{if(s.value==="aborted")return v;const c=this._def.schema._parseSync({data:o,path:r.path,parent:r});return c.status==="aborted"?v:c.status==="dirty"||s.value==="dirty"?ae(c.value):c}}if(a.type==="refinement"){const o=c=>{const l=a.refinement(c,n);if(r.common.async)return Promise.resolve(l);if(l instanceof Promise)throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");return c};if(r.common.async===!1){const c=this._def.schema._parseSync({data:r.data,path:r.path,parent:r});return c.status==="aborted"?v:(c.status==="dirty"&&s.dirty(),o(c.value),{status:s.value,value:c.value})}else return this._def.schema._parseAsync({data:r.data,path:r.path,parent:r}).then(c=>c.status==="aborted"?v:(c.status==="dirty"&&s.dirty(),o(c.value).then(()=>({status:s.value,value:c.value}))))}if(a.type==="transform")if(r.common.async===!1){const o=this._def.schema._parseSync({data:r.data,path:r.path,parent:r});if(!X(o))return v;const c=a.transform(o.value,n);if(c instanceof Promise)throw new Error("Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.");return{status:s.value,value:c}}else return this._def.schema._parseAsync({data:r.data,path:r.path,parent:r}).then(o=>X(o)?Promise.resolve(a.transform(o.value,n)).then(c=>({status:s.value,value:c})):v);C.assertNever(a)}}q.create=(t,e,s)=>new q({schema:t,typeName:y.ZodEffects,effect:e,...N(s)});q.createWithPreprocess=(t,e,s)=>new q({schema:e,effect:{type:"preprocess",transform:t},typeName:y.ZodEffects,...N(s)});class D extends S{_parse(e){return this._getType(e)===p.undefined?M(void 0):this._def.innerType._parse(e)}unwrap(){return this._def.innerType}}D.create=(t,e)=>new D({innerType:t,typeName:y.ZodOptional,...N(e)});class ee extends S{_parse(e){return this._getType(e)===p.null?M(null):this._def.innerType._parse(e)}unwrap(){return this._def.innerType}}ee.create=(t,e)=>new ee({innerType:t,typeName:y.ZodNullable,...N(e)});class Ee extends S{_parse(e){const{ctx:s}=this._processInputParams(e);let r=s.data;return s.parsedType===p.undefined&&(r=this._def.defaultValue()),this._def.innerType._parse({data:r,path:s.path,parent:s})}removeDefault(){return this._def.innerType}}Ee.create=(t,e)=>new Ee({innerType:t,typeName:y.ZodDefault,defaultValue:typeof e.default=="function"?e.default:()=>e.default,...N(e)});class Ie extends S{_parse(e){const{ctx:s}=this._processInputParams(e),r={...s,common:{...s.common,issues:[]}},a=this._def.innerType._parse({data:r.data,path:r.path,parent:{...r}});return be(a)?a.then(n=>({status:"valid",value:n.status==="valid"?n.value:this._def.catchValue({get error(){return new z(r.common.issues)},input:r.data})})):{status:"valid",value:a.status==="valid"?a.value:this._def.catchValue({get error(){return new z(r.common.issues)},input:r.data})}}removeCatch(){return this._def.innerType}}Ie.create=(t,e)=>new Ie({innerType:t,typeName:y.ZodCatch,catchValue:typeof e.catch=="function"?e.catch:()=>e.catch,...N(e)});class ot extends S{_parse(e){if(this._getType(e)!==p.nan){const r=this._getOrReturnCtx(e);return f(r,{code:u.invalid_type,expected:p.nan,received:r.parsedType}),v}return{status:"valid",value:e.data}}}ot.create=t=>new ot({typeName:y.ZodNaN,...N(t)});class ks extends S{_parse(e){const{ctx:s}=this._processInputParams(e),r=s.data;return this._def.type._parse({data:r,path:s.path,parent:s})}unwrap(){return this._def.type}}class $e extends S{_parse(e){const{status:s,ctx:r}=this._processInputParams(e);if(r.common.async)return(async()=>{const n=await this._def.in._parseAsync({data:r.data,path:r.path,parent:r});return n.status==="aborted"?v:n.status==="dirty"?(s.dirty(),ae(n.value)):this._def.out._parseAsync({data:n.value,path:r.path,parent:r})})();{const a=this._def.in._parseSync({data:r.data,path:r.path,parent:r});return a.status==="aborted"?v:a.status==="dirty"?(s.dirty(),{status:"dirty",value:a.value}):this._def.out._parseSync({data:a.value,path:r.path,parent:r})}}static create(e,s){return new $e({in:e,out:s,typeName:y.ZodPipeline})}}class Oe extends S{_parse(e){const s=this._def.innerType._parse(e),r=a=>(X(a)&&(a.value=Object.freeze(a.value)),a);return be(s)?s.then(a=>r(a)):r(s)}unwrap(){return this._def.innerType}}Oe.create=(t,e)=>new Oe({innerType:t,typeName:y.ZodReadonly,...N(e)});var y;(function(t){t.ZodString="ZodString",t.ZodNumber="ZodNumber",t.ZodNaN="ZodNaN",t.ZodBigInt="ZodBigInt",t.ZodBoolean="ZodBoolean",t.ZodDate="ZodDate",t.ZodSymbol="ZodSymbol",t.ZodUndefined="ZodUndefined",t.ZodNull="ZodNull",t.ZodAny="ZodAny",t.ZodUnknown="ZodUnknown",t.ZodNever="ZodNever",t.ZodVoid="ZodVoid",t.ZodArray="ZodArray",t.ZodObject="ZodObject",t.ZodUnion="ZodUnion",t.ZodDiscriminatedUnion="ZodDiscriminatedUnion",t.ZodIntersection="ZodIntersection",t.ZodTuple="ZodTuple",t.ZodRecord="ZodRecord",t.ZodMap="ZodMap",t.ZodSet="ZodSet",t.ZodFunction="ZodFunction",t.ZodLazy="ZodLazy",t.ZodLiteral="ZodLiteral",t.ZodEnum="ZodEnum",t.ZodEffects="ZodEffects",t.ZodNativeEnum="ZodNativeEnum",t.ZodOptional="ZodOptional",t.ZodNullable="ZodNullable",t.ZodDefault="ZodDefault",t.ZodCatch="ZodCatch",t.ZodPromise="ZodPromise",t.ZodBranded="ZodBranded",t.ZodPipeline="ZodPipeline",t.ZodReadonly="ZodReadonly"})(y||(y={}));const H=Z.create;B.create;const ne=L.create,_t=T.create;ke.create;we.create;Y.create;const kt=Q.create;Ne.create;D.create;ee.create;class $ extends Error{constructor(s,r){super(s);te(this,"status");te(this,"provider");this.name="LLMError",this.status=r.status,this.provider=r.provider}}const wt=(t,e)=>{const s=(t==null?void 0:t.trim())??"";if(!s)throw new $(`${e.label} API key is required`,{provider:e.id});if(!/^[\x20-\x7e]+$/.test(s))throw new $(`${e.label} API key contains non-ASCII characters — check for pasted smart quotes or hidden whitespace`,{provider:e.id});return s},Nt=(t,e)=>{if(!t||t.length===0)throw new $("messages must not be empty",{provider:e.id})},jt=async(t,e,s)=>{var n;let r;try{r=await fetch(t,e)}catch(o){throw new $(`${s.label} request failed: ${o instanceof Error?o.message:String(o)}`,{provider:s.id})}let a=null;try{a=await r.json()}catch{}if(!r.ok){const o=((n=a==null?void 0:a.error)==null?void 0:n.message)??r.statusText;throw new $(`${s.label} ${r.status}: ${o}`,{status:r.status,provider:s.id})}if(a===null)throw new $(`${s.label} returned a non-JSON response`,{status:r.status,provider:s.id});return a},ge={id:"openai",label:"OpenAI"},ws="https://api.openai.com/v1",Ns="gpt-4o-mini";var le,de,ue;class js{constructor(e){te(this,"provider",ge.id);G(this,le);G(this,de);G(this,ue);K(this,le,wt(e.apiKey,ge)),K(this,de,(e.baseUrl??ws).replace(/\/+$/,"")),K(this,ue,e.defaultModel??Ns)}async complete(e){var c,l;Nt(e.messages,ge);const s=e.model??W(this,ue),r={model:s,messages:e.messages.map(d=>({role:d.role,content:d.content}))};e.temperature!==void 0&&(r.temperature=e.temperature),e.maxTokens!==void 0&&(r.max_tokens=e.maxTokens),e.responseFormat==="json_object"&&(r.response_format={type:"json_object"});const a=await jt(`${W(this,de)}/chat/completions`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${W(this,le)}`},body:JSON.stringify(r),signal:e.signal},ge),n=(c=a.choices)==null?void 0:c[0];return{content:((l=n==null?void 0:n.message)==null?void 0:l.content)??"",model:a.model??s,usage:a.usage?{promptTokens:a.usage.prompt_tokens,completionTokens:a.usage.completion_tokens,totalTokens:a.usage.total_tokens}:void 0}}}le=new WeakMap,de=new WeakMap,ue=new WeakMap;const se={id:"gemini",label:"Gemini"},Ss="https://generativelanguage.googleapis.com/v1beta",As="gemini-2.5-flash-lite",Cs=t=>{const e=[],s=[];for(const r of t){if(r.role==="system"){e.push(r.content);continue}const a=r.role==="assistant"?"model":"user",n=s[s.length-1];n&&n.role===a?n.parts.push({text:r.content}):s.push({role:a,parts:[{text:r.content}]})}return{contents:s,systemInstruction:e.length>0?{parts:[{text:e.join(`

`)}]}:void 0}};var fe,pe,he;class Ts{constructor(e){te(this,"provider",se.id);G(this,fe);G(this,pe);G(this,he);K(this,fe,wt(e.apiKey,se)),K(this,pe,(e.baseUrl??Ss).replace(/\/+$/,"")),K(this,he,e.defaultModel??As)}async complete(e){var b,g;Nt(e.messages,se);const s=e.model??W(this,he),{contents:r,systemInstruction:a}=Cs(e.messages),n={thinkingConfig:{thinkingBudget:0}};e.temperature!==void 0&&(n.temperature=e.temperature),e.maxTokens!==void 0&&(n.maxOutputTokens=e.maxTokens),e.responseFormat==="json_object"&&(n.responseMimeType="application/json");const o={contents:r};a&&(o.systemInstruction=a),Object.keys(n).length>0&&(o.generationConfig=n);const c=`${W(this,pe)}/models/${encodeURIComponent(s)}:generateContent`,l=await jt(c,{method:"POST",headers:{"Content-Type":"application/json","x-goog-api-key":W(this,fe)},body:JSON.stringify(o),signal:e.signal},se),d=(b=l.candidates)==null?void 0:b[0],k=(((g=d==null?void 0:d.content)==null?void 0:g.parts)??[]).map(E=>E.text??"").join("");if((d==null?void 0:d.finishReason)==="MAX_TOKENS")throw new $("Gemini response truncated (MAX_TOKENS). Try increasing maxTokens.",{provider:se.id});const j=l.usageMetadata;return{content:k,model:l.modelVersion??s,usage:j?{promptTokens:j.promptTokenCount??0,completionTokens:j.candidatesTokenCount??0,totalTokens:j.totalTokenCount??(j.promptTokenCount??0)+(j.candidatesTokenCount??0)}:void 0}}}fe=new WeakMap,pe=new WeakMap,he=new WeakMap;const Es=t=>{switch(t.provider){case"openai":return new js({apiKey:t.apiKey,baseUrl:t.baseUrl,defaultModel:t.defaultModel});case"gemini":return new Ts({apiKey:t.apiKey,baseUrl:t.baseUrl,defaultModel:t.defaultModel});default:{const e=t.provider;throw new Error(`unsupported LLM provider: ${String(e)}`)}}},St=kt(["low","medium","high","critical"]),Is=kt(["BUY","NEGOTIATE","AVOID","UNKNOWN"]),Os=_t({title:H().min(1),severity:St,detail:H().min(1),evidenceRuleIds:ne(H()).default([])}),Rs=_t({verdict:Is,overallRisk:St,summary:H().min(1),strengths:ne(H()).default([]),concerns:ne(Os).default([]),negotiationPoints:ne(H()).default([]),dataQualityWarnings:ne(H()).default([])}),Ms=1024,$s=2048,Ls=(t,e)=>{let s;try{s=JSON.parse(t)}catch(a){const n=t.length>200?`${t.slice(0,200)}…`:t;throw new $(`LLM evaluation response was not valid JSON: ${a instanceof Error?a.message:String(a)} — content preview: ${n}`,{provider:e})}const r=Rs.safeParse(s);if(!r.success)throw new $(`LLM evaluation response did not match schema: ${r.error.message}`,{provider:e});return r.data},zs=async t=>{var k,j,b;const{system:e,user:s}=Jt(t.input),r=[{role:"system",content:e},{role:"user",content:s}],a=((k=t.llm)==null?void 0:k.model)??t.model,n=((j=t.llm)==null?void 0:j.temperature)??t.temperature,o=((b=t.llm)==null?void 0:b.maxTokens)??t.maxTokens,c=o??Ms,l=g=>t.client.complete({messages:r,responseFormat:"json_object",temperature:n??.2,maxTokens:g,model:a,signal:t.signal});let d;try{d=await l(c)}catch(g){if(o===void 0&&g instanceof $&&/MAX_TOKENS/i.test(g.message))d=await l($s);else throw g}return{schemaVersion:1,...Ls(d.content,t.client.provider),model:d.model,generatedAt:Date.now()}},Vs=async t=>{var r;const e=(r=t.apiKey)==null?void 0:r.trim();if(!e)return null;const s=Es({provider:t.provider,apiKey:e,defaultModel:t.model});return zs({client:s,input:t.input,model:t.model,signal:t.signal,temperature:t.temperature,maxTokens:t.maxTokens})},Re=t=>typeof t=="string"&&t.trim().length>0,Zs={openai:{main:"◼ OPENAI",sub:"GPT-4O-MINI"},gemini:{main:"◇ GEMINI",sub:"2.5 FLASH-LITE"}};function Ds({provider:t,apiKey:e,showKey:s,loading:r,hasEvaluation:a,onProviderChange:n,onApiKeyChange:o,onToggleShowKey:c,onRun:l,onCancel:d}){const m=Re(e)&&!r;return i.jsxs("div",{className:"ai-section",children:[i.jsx("div",{className:"ai-provider",children:["openai","gemini"].map(k=>{const j=Zs[k],b=t===k;return i.jsxs("button",{type:"button",onClick:()=>n(k),disabled:r,className:`ai-provider-btn${b?" ai-provider-btn--active":""}`,children:[j.main,i.jsx("span",{className:"ai-provider-sub",children:j.sub})]},k)})}),i.jsxs("div",{className:"ai-key-row",children:[i.jsx("input",{type:s?"text":"password",value:e,onChange:k=>o(k.target.value),placeholder:t==="openai"?"sk-...":"AIza...",disabled:r,autoComplete:"off",spellCheck:!1,className:"ai-key-input"}),i.jsx("button",{type:"button",onClick:c,disabled:r,title:s?"숨기기":"보이기",className:"ai-key-toggle",children:s?"HIDE":"SHOW"})]}),i.jsxs("div",{className:"ai-run-row",children:[i.jsx("button",{type:"button",onClick:l,disabled:!m,className:"ai-run-btn",children:r?"▣ ANALYZING...":a?"↻ RE-EVALUATE":"▶ RUN AI EVALUATION"}),r&&i.jsx("button",{type:"button",onClick:d,className:"ai-cancel-btn",children:"CANCEL"})]}),!Re(e)&&i.jsx("div",{className:"ai-hint",children:t==="openai"?"// OpenAI API key를 입력하면 수집된 매물 데이터를 기반으로 AI가 종합 평가합니다.":"// Google AI Studio API key를 입력하면 수집된 매물 데이터를 기반으로 AI가 종합 평가합니다."})]})}const Ps={low:"낮음",medium:"보통",high:"높음",critical:"매우 높음"};function Bs({finding:t}){return i.jsxs("div",{className:`ai-concern ai-concern--${t.severity}`,children:[i.jsxs("div",{className:"ai-concern-head",children:[i.jsx("span",{className:"ai-concern-title",children:t.title}),i.jsx("span",{className:`ai-concern-sev ai-concern-sev--${t.severity}`,children:Ps[t.severity]}),t.evidenceRuleIds.length>0&&i.jsx("span",{className:"ai-concern-rules",children:t.evidenceRuleIds.join(" · ")})]}),i.jsx("div",{className:"ai-concern-detail",children:t.detail})]})}const Us={BUY:{cls:"ai-verdict--buy",label:"GO FOR IT."},NEGOTIATE:{cls:"ai-verdict--negotiate",label:"NEGOTIATE."},AVOID:{cls:"ai-verdict--avoid",label:"DO NOT BUY."},UNKNOWN:{cls:"ai-verdict--unknown",label:"NOT SURE."}},Fs={low:"낮음",medium:"보통",high:"높음",critical:"매우 높음"};function Ws({evaluation:t}){const e=Us[t.verdict];return i.jsxs("div",{children:[i.jsxs("div",{className:`ai-verdict ${e.cls}`,children:[i.jsx("div",{className:"ai-verdict-tag",children:"◆ AI VERDICT"}),i.jsx("div",{className:"ai-verdict-label",children:e.label}),i.jsxs("div",{className:"ai-verdict-risk",children:["OVERALL RISK · ",Fs[t.overallRisk].toUpperCase()]})]}),i.jsx("div",{className:"ai-summary",children:t.summary}),t.strengths.length>0&&i.jsxs(i.Fragment,{children:[i.jsxs("div",{className:"ai-section-head",children:[i.jsx("span",{children:"◼ STRENGTHS / 장점"}),i.jsx("span",{className:"ai-section-count",children:String(t.strengths.length).padStart(2,"0")})]}),i.jsx("ul",{className:"ai-list",children:t.strengths.map((s,r)=>i.jsxs("li",{className:"ai-list-item ai-list-item--strength",children:[i.jsx("span",{className:"ai-list-mark",children:"+"}),i.jsx("span",{children:s})]},r))})]}),t.concerns.length>0&&i.jsxs(i.Fragment,{children:[i.jsxs("div",{className:"ai-section-head",children:[i.jsx("span",{children:"◼ CONCERNS / 우려"}),i.jsx("span",{className:"ai-section-count",children:String(t.concerns.length).padStart(2,"0")})]}),i.jsx("div",{children:t.concerns.map((s,r)=>i.jsx(Bs,{finding:s},r))})]}),t.negotiationPoints.length>0&&i.jsxs(i.Fragment,{children:[i.jsxs("div",{className:"ai-section-head",children:[i.jsx("span",{children:"◼ NEGOTIATION / 협상 포인트"}),i.jsx("span",{className:"ai-section-count",children:String(t.negotiationPoints.length).padStart(2,"0")})]}),i.jsx("ul",{className:"ai-list",children:t.negotiationPoints.map((s,r)=>i.jsxs("li",{className:"ai-list-item ai-list-item--neg",children:[i.jsx("span",{className:"ai-list-mark",children:"→"}),i.jsx("span",{children:s})]},r))})]}),t.dataQualityWarnings.length>0&&i.jsxs(i.Fragment,{children:[i.jsxs("div",{className:"ai-section-head",children:[i.jsx("span",{children:"◼ DATA GAPS / 데이터 부족"}),i.jsx("span",{className:"ai-section-count",children:String(t.dataQualityWarnings.length).padStart(2,"0")})]}),i.jsx("ul",{className:"ai-list",children:t.dataQualityWarnings.map((s,r)=>i.jsxs("li",{className:"ai-list-item ai-list-item--data",children:[i.jsx("span",{className:"ai-list-mark",children:"?"}),i.jsx("span",{children:s})]},r))})]}),i.jsxs("div",{className:"ai-footer",children:["MODEL · ",t.model," ·"," ",new Date(t.generatedAt).toLocaleTimeString()]})]})}const Gs=`
.ai-root {
  background: #fff;
  color: #000;
  border-bottom: 4px solid #000;
  animation: autoverdict-fade 260ms ease-out both;
}

.ai-header {
  display: flex;
  align-items: center;
  gap: 10px;
  background: #000;
  color: #fff;
  padding: 10px 14px;
  border-bottom: 4px solid #000;
}
.ai-header-title {
  font-family: 'Archivo Black', sans-serif;
  font-size: 14px;
  letter-spacing: -0.2px;
  text-transform: uppercase;
}
.ai-header-note {
  margin-left: auto;
  font-family: 'Space Mono', monospace;
  font-size: 8px;
  letter-spacing: 2px;
  text-transform: uppercase;
  opacity: 0.7;
}

.ai-section {
  padding: 12px 14px;
  border-bottom: 2px solid #000;
}

.ai-provider {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 0;
  border: 2px solid #000;
}
.ai-provider-btn {
  background: #fff;
  color: #000;
  border: none;
  border-right: 2px solid #000;
  padding: 10px 8px;
  cursor: pointer;
  font-family: 'Archivo Black', sans-serif;
  font-size: 11px;
  letter-spacing: 0.3px;
  text-transform: uppercase;
  text-align: left;
}
.ai-provider-btn:last-child { border-right: none; }
.ai-provider-btn--active {
  background: #000;
  color: #fff;
}
.ai-provider-btn:disabled { cursor: not-allowed; opacity: 0.5; }
.ai-provider-sub {
  display: block;
  font-family: 'Space Mono', monospace;
  font-size: 8px;
  letter-spacing: 1px;
  margin-top: 3px;
  opacity: 0.65;
}

.ai-key-row {
  display: flex;
  gap: 0;
  margin-top: 10px;
  border: 2px solid #000;
}
.ai-key-input {
  flex: 1;
  background: #fff;
  color: #000;
  border: none;
  padding: 10px 12px;
  font-family: 'Space Mono', monospace;
  font-size: 12px;
  outline: none;
}
.ai-key-input::placeholder {
  color: #000;
  opacity: 0.35;
}
.ai-key-input:disabled { background: #fafafa; cursor: not-allowed; }
.ai-key-toggle {
  background: #fff;
  color: #000;
  border: none;
  border-left: 2px solid #000;
  padding: 0 14px;
  cursor: pointer;
  font-family: 'Archivo Black', sans-serif;
  font-size: 10px;
  letter-spacing: 1px;
  text-transform: uppercase;
}
.ai-key-toggle:disabled { cursor: not-allowed; opacity: 0.5; }

.ai-run-row { display: flex; gap: 8px; margin-top: 10px; }
.ai-run-btn {
  flex: 1;
  background: #e4ff00;
  color: #000;
  border: 2px solid #000;
  padding: 12px 14px;
  cursor: pointer;
  font-family: 'Archivo Black', sans-serif;
  font-size: 14px;
  letter-spacing: -0.2px;
  text-transform: uppercase;
  transition: transform 120ms ease-out;
}
.ai-run-btn:hover:not(:disabled) { transform: translate(-1px, -1px); box-shadow: 3px 3px 0 #000; }
.ai-run-btn:disabled {
  background: #f0f0f0;
  color: #000;
  cursor: not-allowed;
  opacity: 0.5;
}
.ai-cancel-btn {
  background: #fff;
  color: #000;
  border: 2px solid #000;
  padding: 12px 14px;
  cursor: pointer;
  font-family: 'Archivo Black', sans-serif;
  font-size: 11px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
}

.ai-hint {
  font-family: 'Space Mono', monospace;
  font-size: 10px;
  line-height: 1.6;
  margin-top: 10px;
  opacity: 0.7;
}

.ai-error {
  background: #ff2d4b;
  color: #fff;
  border-bottom: 4px solid #000;
  padding: 12px 14px;
  display: flex;
  gap: 10px;
  align-items: flex-start;
}
.ai-error-mark {
  font-family: 'Archivo Black', sans-serif;
  font-size: 22px;
  line-height: 1;
}
.ai-error-text {
  font-family: 'Inter Tight', sans-serif;
  font-size: 12px;
  line-height: 1.5;
  font-weight: 600;
}

.ai-loading {
  padding: 28px 14px;
  text-align: center;
  border-bottom: 4px solid #000;
  background: #e4ff00;
}
.ai-loading-text {
  font-family: 'Archivo Black', sans-serif;
  font-size: 36px;
  letter-spacing: -1px;
  line-height: 0.9;
}
.ai-loading-sub {
  font-family: 'Space Mono', monospace;
  font-size: 9px;
  letter-spacing: 2px;
  text-transform: uppercase;
  margin-top: 8px;
  opacity: 0.7;
}

.ai-verdict {
  padding: 14px;
  border-bottom: 4px solid #000;
}
.ai-verdict--buy       { background: #7cff6b; }
.ai-verdict--negotiate { background: #e4ff00; }
.ai-verdict--avoid     { background: #ff2d4b; color: #fff; }
.ai-verdict--unknown   { background: #d4d4d4; }
.ai-verdict-tag {
  font-family: 'Space Mono', monospace;
  font-size: 8px;
  letter-spacing: 2px;
  text-transform: uppercase;
}
.ai-verdict-label {
  font-family: 'Archivo Black', sans-serif;
  font-size: 32px;
  line-height: 0.95;
  letter-spacing: -1px;
  text-transform: uppercase;
  margin-top: 6px;
}
.ai-verdict-risk {
  font-family: 'Space Mono', monospace;
  font-size: 10px;
  letter-spacing: 0.5px;
  margin-top: 8px;
  border-top: 2px solid currentColor;
  padding-top: 6px;
}

.ai-summary {
  padding: 14px;
  border-bottom: 2px solid #000;
  font-family: 'Inter Tight', sans-serif;
  font-size: 13px;
  line-height: 1.6;
  font-weight: 500;
}

.ai-section-head {
  background: #000;
  color: #fff;
  padding: 6px 14px;
  font-family: 'Archivo Black', sans-serif;
  font-size: 10px;
  letter-spacing: 1.5px;
  text-transform: uppercase;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.ai-section-count {
  font-family: 'Space Mono', monospace;
  font-size: 9px;
  opacity: 0.7;
}

.ai-list {
  list-style: none;
  margin: 0;
  padding: 0;
}
.ai-list-item {
  display: grid;
  grid-template-columns: 22px 1fr;
  gap: 8px;
  padding: 10px 14px;
  border-bottom: 1px solid #000;
  font-family: 'Inter Tight', sans-serif;
  font-size: 12px;
  line-height: 1.5;
}
.ai-list-mark {
  font-family: 'Archivo Black', sans-serif;
  font-size: 14px;
}
.ai-list-item--strength { background: #fff; }
.ai-list-item--neg { background: #fafafa; }
.ai-list-item--data { background: #f0f0f0; }

.ai-concern {
  padding: 10px 14px;
  border-bottom: 1px solid #000;
  border-left: 8px solid #000;
}
.ai-concern--low      { border-left-color: #7cff6b; }
.ai-concern--medium   { border-left-color: #e4ff00; }
.ai-concern--high     { border-left-color: #ff8f1f; background: #fff8ec; }
.ai-concern--critical { border-left-color: #ff2d4b; background: #fff0f2; }
.ai-concern-head {
  display: flex;
  gap: 6px;
  align-items: center;
  flex-wrap: wrap;
}
.ai-concern-title {
  font-family: 'Archivo Black', sans-serif;
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: -0.1px;
}
.ai-concern-sev {
  font-family: 'Space Mono', monospace;
  font-size: 8px;
  letter-spacing: 1px;
  padding: 2px 6px;
  border: 1px solid #000;
  text-transform: uppercase;
}
.ai-concern-sev--low      { background: #7cff6b; }
.ai-concern-sev--medium   { background: #e4ff00; }
.ai-concern-sev--high     { background: #ff8f1f; color: #000; }
.ai-concern-sev--critical { background: #ff2d4b; color: #fff; }
.ai-concern-rules {
  margin-left: auto;
  font-family: 'Space Mono', monospace;
  font-size: 8px;
  letter-spacing: 0.5px;
  opacity: 0.6;
}
.ai-concern-detail {
  font-family: 'Inter Tight', sans-serif;
  font-size: 11px;
  line-height: 1.5;
  margin-top: 5px;
}

.ai-footer {
  padding: 8px 14px;
  background: #fafafa;
  font-family: 'Space Mono', monospace;
  font-size: 8px;
  letter-spacing: 1px;
  text-transform: uppercase;
  text-align: right;
  opacity: 0.6;
}
`,Ks=Gs;function Hs({parsed:t,facts:e,report:s}){const[r,a]=x.useState("openai"),[n,o]=x.useState(""),[c,l]=x.useState(!1),[d,m]=x.useState(!1),[k,j]=x.useState(null),[b,g]=x.useState(null),E=x.useRef(null),_=x.useCallback(async()=>{var w;if(!Re(n))return;(w=E.current)==null||w.abort();const O=new AbortController;E.current=O,m(!0),j(null),g(null);try{const A=await Vs({provider:r,apiKey:n,input:{parsed:t,facts:e,report:s},signal:O.signal});if(!A){j("API key가 필요합니다.");return}g(A)}catch(A){if(A instanceof DOMException&&A.name==="AbortError")return;A instanceof $?j(A.status?`LLM 오류 (${A.provider} ${A.status}): ${A.message}`:`LLM 오류 (${A.provider}): ${A.message}`):A instanceof Error?j(A.message):j(String(A))}finally{m(!1)}},[n,r,t,e,s]),I=x.useCallback(()=>{var O;(O=E.current)==null||O.abort(),m(!1)},[]);return i.jsxs("section",{className:"ai-root",children:[i.jsxs("header",{className:"ai-header",children:[i.jsx("div",{className:"ai-header-title",children:"◼ AI EVALUATION"}),i.jsx("div",{className:"ai-header-note",children:"KEY NOT STORED"})]}),i.jsx(Ds,{provider:r,apiKey:n,showKey:c,loading:d,hasEvaluation:b!==null,onProviderChange:a,onApiKeyChange:o,onToggleShowKey:()=>l(O=>!O),onRun:_,onCancel:I}),k&&i.jsxs("div",{className:"ai-error",children:[i.jsx("div",{className:"ai-error-mark",children:"✕"}),i.jsx("div",{className:"ai-error-text",children:k})]}),d&&!b&&i.jsxs("div",{className:"ai-loading",children:[i.jsx("div",{className:"ai-loading-text",children:"ANALYZING"}),i.jsx("div",{className:"ai-loading-sub",children:"// LLM REASONING IN PROGRESS"})]}),b&&!d&&i.jsx(Ws,{evaluation:b})]})}const ct=async()=>{const e=(await chrome.tabs.query({active:!0,currentWindow:!0}))[0];return!e||!e.id||!e.url?null:{tabId:e.id,url:e.url,carId:Pt(e.url)}},lt=async(t,e,s)=>{try{await chrome.runtime.sendMessage({type:"COLLECT_FOR_TAB",carId:e,url:s,tabId:t})}catch{}};function Ys(){const[t,e]=x.useState(null),[s,r]=x.useState(null),[a,n]=x.useState(!0),[o,c]=x.useState(null),[l,d]=x.useState(null),m=x.useRef(null);m.current=t;const k=x.useRef(null),j=x.useCallback(()=>{const _=k.current;_&&(clearTimeout(_.timeout),chrome.runtime.onMessage.removeListener(_.listener),k.current=null)},[]),b=x.useCallback(async()=>{const _=await ct();if(e(_),!(_!=null&&_.carId)){r(null),n(!1);return}try{const I=await chrome.runtime.sendMessage({type:"GET_LAST",carId:_.carId});if(r(I??null),I){c(null),d(null),n(!1);return}c("start"),lt(_.tabId,_.carId,_.url)}catch{r(null)}n(!1)},[]);x.useEffect(()=>{b();const _=w=>{if(De(w))c(w.stage),d(null);else if(Pe(w)){c(null),d(null);const A=m.current;if(A&&A.carId===w.carId){const U=Date.now();r({carId:w.carId,url:A.url,parsed:w.parsed,facts:w.facts,report:w.report,cachedAt:U,expiresAt:U+24*60*60*1e3}),n(!1)}else b()}else if(Be(w)){c(null);const A=m.current;A&&A.carId===w.carId&&d(w.reason)}};chrome.runtime.onMessage.addListener(_);const I=()=>{n(!0),c(null),b()};chrome.tabs.onActivated.addListener(I);const O=(w,A,U)=>{U.active&&(A.url?(r(null),c("start"),n(!0),b()):A.status==="complete"&&b())};return chrome.tabs.onUpdated.addListener(O),()=>{chrome.runtime.onMessage.removeListener(_),chrome.tabs.onActivated.removeListener(I),chrome.tabs.onUpdated.removeListener(O),j()}},[b,j]);const g=x.useCallback(async()=>{j();const _=await ct();if(e(_),!(_!=null&&_.carId)){n(!1);return}d(null),c("start"),r(null),n(!0),await chrome.runtime.sendMessage({type:"REFRESH",carId:_.carId}).catch(()=>{}),lt(_.tabId,_.carId,_.url);const I=setTimeout(()=>{d("watchdog_timeout"),c(null);const w=k.current;w&&w.timeout===I&&(chrome.runtime.onMessage.removeListener(w.listener),k.current=null)},22e3),O=w=>{if(Pe(w)||Be(w)||De(w)){const A=k.current;A&&A.timeout===I&&(clearTimeout(A.timeout),chrome.runtime.onMessage.removeListener(A.listener),k.current=null)}};chrome.runtime.onMessage.addListener(O),k.current={timeout:I,listener:O}},[j]),E=x.useCallback(_=>{if(!confirm("정말 무시하시겠습니까? 7일 동안 이 체크는 비활성화됩니다."))return;const I=m.current;I!=null&&I.carId&&chrome.runtime.sendMessage({type:"ACK_RULE",carId:I.carId,ruleId:_}).then(()=>void b()).catch(()=>{})},[b]);return{active:t,row:s,loading:a,progressStage:o,loadError:l,refresh:g,ack:E}}const Js=t=>{const[e,s]=x.useState(!1),[r,a]=x.useState(0),[n,o]=x.useState(null),[c,l]=x.useState(null),d=n??(t==null?void 0:t.carId)??null;x.useEffect(()=>{d&&chrome.runtime.sendMessage({type:"IS_SAVED",carId:d}).then(b=>s((b==null?void 0:b.saved)??!1)).catch(()=>s(!1))},[d]);const m=x.useCallback(async()=>{const b=n?c:t;if(b)if(e)await chrome.runtime.sendMessage({type:"UNSAVE_CAR",carId:b.carId}).catch(()=>{}),s(!1),a(g=>g+1);else{const g=await chrome.runtime.sendMessage({type:"SAVE_CAR",carId:b.carId,url:b.url,parsed:b.parsed}).catch(()=>({ok:!1}));if((g==null?void 0:g.reason)==="limit")return;s(!0),a(E=>E+1)}},[n,c,t,e]),k=x.useCallback(async b=>{if(t&&t.carId===b){o(null),l(null);return}const g=await chrome.runtime.sendMessage({type:"GET_SAVED_ONE",carId:b});g&&(l({carId:g.carId,url:g.url,parsed:g.parsed,facts:g.facts,report:g.report,cachedAt:g.updatedAt,expiresAt:g.expiresAt}),o(b))},[t]),j=x.useCallback(()=>{o(null),l(null)},[]);return{savedState:e,savedListKey:r,viewingSavedCarId:n,savedRow:c,handleToggleSave:m,handleViewSavedCar:k,clearOverride:j}};function Xs(t,e=600){const[s,r]=x.useState(t);return x.useEffect(()=>{if(typeof window>"u"){r(t);return}if(window.matchMedia("(prefers-reduced-motion: reduce)").matches){r(t);return}r(0);let a,n=null;const o=c=>{n===null&&(n=c);const l=c-n,d=Math.min(l/e,1),m=1-Math.pow(1-d,3);r(Math.round(m*t)),d<1&&(a=requestAnimationFrame(o))};return a=requestAnimationFrame(o),()=>{cancelAnimationFrame(a)}},[t,e]),Math.round(s)}function Qs(t){switch(t){case"NEVER":return`DO NOT
BUY.`;case"CAUTION":return`CAUTION.
READ ME.`;case"OK":return"GOOD.";case"UNKNOWN":return`CHECK
THIS.`}}function qs(t,e){const s=[...t,...e].slice(0,3);return s.length===0?"특이사항 없음":s.map(r=>{var a;return((a=je[r.ruleId])==null?void 0:a.shortTitle)??r.title}).join(" · ")}const er=`
.hero {
  display: flex;
  border-bottom: 4px solid #000;
}
.hero-score {
  padding: 8px 8px 6px 14px;
  display: flex;
  flex-direction: column;
  justify-content: center;
}
.hero-score-label {
  font-family: 'Space Mono', monospace;
  font-size: 8px;
  letter-spacing: 2px;
  text-transform: uppercase;
  color: #000;
}
.hero-score-number {
  font-family: 'Archivo Black', sans-serif;
  font-size: 86px;
  line-height: 0.85;
  letter-spacing: -3px;
  color: #000;
}
.hero-score-sub {
  font-family: 'Space Mono', monospace;
  font-size: 10px;
  opacity: 0.6;
  margin-top: -2px;
}
.hero-verdict {
  flex: 1;
  border-left: 4px solid #000;
  background: #e4ff00;
  padding: 10px 12px 8px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  position: relative;
  transition: background 180ms ease-out;
}
.hero-verdict--never   { background: #ff2d4b; }
.hero-verdict--caution { background: #e4ff00; }
.hero-verdict--ok      { background: #7cff6b; }
.hero-verdict--unknown { background: #d4d4d4; }
.hero-verdict-dot {
  position: absolute;
  top: 6px;
  right: 6px;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: #000;
  box-shadow: 0 0 0 2px #fff;
}
.hero-verdict--never .hero-verdict-dot {
  background: #fff;
  box-shadow: 0 0 0 2px #000;
}
.hero-verdict-tag {
  font-family: 'Space Mono', monospace;
  font-size: 8px;
  letter-spacing: 2px;
  text-transform: uppercase;
  color: #000;
}
.hero-verdict-label {
  font-family: 'Archivo Black', sans-serif;
  font-size: 20px;
  line-height: 0.9;
  letter-spacing: -0.5px;
  margin-top: 5px;
  color: #000;
}
.hero-verdict-summary {
  font-family: 'Space Mono', monospace;
  font-size: 9px;
  letter-spacing: 0.3px;
  line-height: 1.4;
  margin-top: 8px;
  border-top: 2px solid #000;
  padding-top: 5px;
  color: #000;
}
`,tr={NEVER:"hero-verdict hero-verdict--never",CAUTION:"hero-verdict hero-verdict--caution",OK:"hero-verdict hero-verdict--ok",UNKNOWN:"hero-verdict hero-verdict--unknown"},sr=({score:t,verdict:e,killers:s,warns:r})=>{const a=Xs(t,600),n=Qs(e),o=qs(s,r);return i.jsxs("div",{className:"hero",children:[i.jsxs("div",{className:"hero-score",children:[i.jsx("div",{className:"hero-score-label",children:"SCORE"}),i.jsx("div",{className:"hero-score-number",children:a}),i.jsx("div",{className:"hero-score-sub",children:"OUT OF 100"})]}),i.jsxs("div",{className:tr[e],children:[s.length>0&&i.jsx("div",{className:"hero-verdict-dot"}),i.jsxs("div",{children:[i.jsx("div",{className:"hero-verdict-tag",children:"◆ VERDICT"}),i.jsx("div",{className:"hero-verdict-label",children:n.split(`
`).map((c,l)=>i.jsxs($t.Fragment,{children:[l>0&&i.jsx("br",{}),c]},l))})]}),i.jsx("div",{className:"hero-verdict-summary",children:o})]})]})},rr=t=>{if(t!==void 0)return`${t.toLocaleString()}km`},ar=t=>{if(!(t===void 0||t===0)){if(t>=1e4){const e=Math.floor(t/1e4),s=t%1e4;return s>0?`${e}억 ${s.toLocaleString()}만원`:`${e}억원`}return`${t.toLocaleString()}만원`}},nr=`
.car-strip {
  padding: 11px 14px;
  border-bottom: 4px double #000;
  display: flex;
  flex-direction: column;
  gap: 3px;
  background: #fff;
}
.car-strip-make {
  font-family: 'Archivo Black', sans-serif;
  font-size: 14px;
  text-transform: uppercase;
  letter-spacing: 0;
  color: #000;
}
.car-strip-spec {
  font-family: 'Space Mono', monospace;
  font-size: 10px;
  opacity: 0.75;
  color: #000;
}
.car-strip-price {
  font-family: 'Archivo Black', sans-serif;
  font-size: 18px;
  margin-top: 4px;
  color: #000;
}
`,ir=({parsed:t,carId:e})=>{const s=t.raw.base;if(s.kind!=="value")return i.jsxs("div",{className:"car-strip",children:[i.jsx("div",{className:"car-strip-make",children:"— NO CAR DATA —"}),i.jsx("div",{className:"car-strip-spec",children:`#${e}`}),i.jsx("div",{className:"car-strip-price",children:"가격 미공개"})]});const r=s.value,a=[r.category.manufacturerName,r.category.modelName].filter(Boolean).join(" "),n=r.category.gradeName??r.category.gradeDetailName,o=xt(r.category.yearMonth),c=rr(r.spec.mileage),l=ar(r.advertisement.price),d=a+(n?` · ${n}`:""),m=[o,c,`#${e}`].filter(k=>k!=null);return i.jsxs("div",{className:"car-strip",children:[i.jsx("div",{className:"car-strip-make",children:d}),i.jsx("div",{className:"car-strip-spec",children:m.join(" · ")}),i.jsx("div",{className:"car-strip-price",children:l??"가격 미공개"})]})},or=[{id:"checklist",label:"CHECKLIST",sub:"◼ 12 RULES"},{id:"ai",label:"AI REVIEW",sub:"◇ GEMINI / GPT"},{id:"mylist",label:"MY LIST",sub:"★ SAVED CARS"}],cr=`
.tab-bar {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  border-bottom: 4px solid #000;
}
.tab-bar-btn {
  padding: 14px 8px 12px;
  border: none;
  border-right: 4px solid #000;
  cursor: pointer;
  text-align: center;
  font-family: 'Archivo Black', sans-serif;
  font-size: 15px;
  text-transform: uppercase;
  letter-spacing: -0.3px;
}
.tab-bar-btn:last-child {
  border-right: none;
}
.tab-bar-btn--active {
  background: #000;
  color: #fff;
}
.tab-bar-btn--inactive {
  background: #fff;
  color: #000;
}
.tab-bar-sub {
  font-family: 'Space Mono', monospace;
  font-size: 8px;
  letter-spacing: 1.5px;
  display: block;
  margin-top: 4px;
  font-weight: 700;
}
.tab-bar-btn--active .tab-bar-sub {
  opacity: 0.75;
}
.tab-bar-btn--inactive .tab-bar-sub {
  opacity: 0.6;
}
.tab-bar-btn--disabled {
  background: #e0e0e0;
  color: #999;
  cursor: not-allowed;
}
.tab-bar-btn--disabled .tab-bar-sub {
  opacity: 0.4;
}
`,lr=({tab:t,onChange:e,disabledTabs:s=[]})=>i.jsx("div",{className:"tab-bar",children:or.map(r=>{const a=t===r.id,n=s.includes(r.id),o=n?"tab-bar-btn tab-bar-btn--disabled":`tab-bar-btn ${a?"tab-bar-btn--active":"tab-bar-btn--inactive"}`;return i.jsxs("button",{className:o,disabled:n,onClick:()=>!n&&e(r.id),children:[r.label,i.jsx("span",{className:"tab-bar-sub",children:r.sub})]},r.id)})}),At=(t,e)=>e<=0?0:Math.round(t/e*100),dr=t=>t>=80?"good":t>=50?"warn":"bad";function ur(t){return mt.map(e=>{const s=t.filter(o=>{var l;return(((l=je[o.ruleId])==null?void 0:l.category)??"투명성")===e}),r=s.length,a=s.filter(o=>o.severity==="pass").length,n=At(a,r);return{category:e,pass:a,total:r,pct:n}})}const fr=`
  .autoverdict-radar-container {
    padding: 4px 14px 12px;
    border-bottom: 4px solid #000;
  }
  .autoverdict-radar-header {
    display: flex;
    justify-content: flex-end;
    margin-bottom: 2px;
  }
  .autoverdict-radar-header-text {
    text-align: right;
    font-family: 'Space Mono', monospace;
    font-size: 9px;
    text-transform: uppercase;
    letter-spacing: 2px;
    line-height: 1.4;
  }
  .autoverdict-radar-header-title {
    opacity: 1;
  }
  .autoverdict-radar-header-index {
    opacity: 0.5;
  }
  .autoverdict-radar-svg {
    width: 100%;
    max-width: 340px;
    height: auto;
    display: block;
    margin: 0 auto;
  }
  .autoverdict-radar-poly {
    animation: autoverdict-radar-draw 500ms ease-out both;
    stroke-dasharray: 2000;
  }
`,Ct=180,Tt=160,xe=110,pr=[110,82,55,28],hr=135,Me=5;function ve(t){return-Math.PI/2+t*(2*Math.PI/Me)}function ye(t,e){return[Ct+t*Math.cos(e),Tt+t*Math.sin(e)]}function dt(t){return t.map(([e,s])=>`${e.toFixed(2)},${s.toFixed(2)}`).join(" ")}function mr(t){return t===4?"end":t===1?"start":"middle"}const gr=({results:t})=>{const e=ur(t),s=pr.map(n=>{const o=Array.from({length:Me},(c,l)=>ye(n,ve(l)));return{r:n,pts:o}}),r=Array.from({length:Me},(n,o)=>{const[c,l]=ye(xe,ve(o));return{x:c,y:l}}),a=e.map((n,o)=>{const c=n.pct/100*xe;return ye(c,ve(o))});return i.jsxs("div",{className:"autoverdict-radar-container",children:[i.jsx("div",{className:"autoverdict-radar-header",children:i.jsxs("div",{className:"autoverdict-radar-header-text",children:[i.jsx("div",{className:"autoverdict-radar-header-title",children:"◇ HEALTH RADAR"}),i.jsx("div",{className:"autoverdict-radar-header-index",children:"01 / 02"})]})}),i.jsxs("svg",{viewBox:"-30 -10 420 330",className:"autoverdict-radar-svg","aria-label":"Health radar chart",children:[i.jsx("defs",{children:i.jsxs("pattern",{id:"autoverdict-hatch",patternUnits:"userSpaceOnUse",width:6,height:6,patternTransform:"rotate(45)",children:[i.jsx("rect",{width:6,height:6,fill:"#e4ff00"}),i.jsx("line",{x1:0,y1:0,x2:0,y2:6,stroke:"#000",strokeWidth:2})]})}),s.map(({r:n,pts:o})=>i.jsx("polygon",{points:dt(o),fill:"none",stroke:"#000",strokeWidth:n===xe?1.5:.75,opacity:n===xe?1:.25},n)),r.map(({x:n,y:o},c)=>i.jsx("line",{x1:Ct,y1:Tt,x2:n,y2:o,stroke:"#000",strokeWidth:1,strokeDasharray:"2 3",opacity:.4},c)),i.jsx("polygon",{points:dt(a),fill:"url(#autoverdict-hatch)",stroke:"#000",strokeWidth:3,className:"autoverdict-radar-poly"}),a.map(([n,o],c)=>i.jsx("circle",{cx:n,cy:o,r:5,fill:"#000"},c)),e.map((n,o)=>{const[c,l]=ye(hr,ve(o)),d=mr(o),m=n.pct<50?"#ff2d4b":"#000",k=n.pct<50?"#ff2d4b":"#000",j=n.pct>=50?.6:1;return i.jsxs("g",{children:[i.jsx("text",{x:c,y:l+4,textAnchor:d,fontFamily:"'Archivo Black', sans-serif",fontSize:11,fill:m,fontWeight:900,children:n.category}),i.jsxs("text",{x:c,y:l+4+12,textAnchor:d,fontFamily:"'Space Mono', monospace",fontSize:9,fill:k,opacity:j,children:[n.pass,"/",n.total," · ",n.pct,"%"]})]},o)})]})]})},xr=`
  .autoverdict-filter-tabs {
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    border-bottom: 4px solid #000;
  }
  .v-tab {
    padding: 12px 2px 10px;
    border-right: 2px solid #000;
    border-top: none;
    border-left: none;
    border-bottom: none;
    text-align: center;
    cursor: pointer;
    position: relative;
    font-family: inherit;
    background: #fff;
    color: #000;
  }
  .v-tab:last-child {
    border-right: none;
  }
  .v-tab::before {
    content: '';
    position: absolute;
    top: -2px;
    left: 0;
    right: 0;
    height: 5px;
    background: transparent;
  }
  .v-tab.is-active::before {
    background: #000;
  }
  .v-tab-all {
    background: #000;
    color: #fff;
  }
  .v-tab-all.is-active::before {
    background: #e4ff00;
  }
  .v-tab-fatal {
    background: #ff2d4b;
    color: #fff;
  }
  .v-tab-warn {
    background: #e4ff00;
    color: #000;
  }
  .v-tab-pass {
    background: #fff;
    color: #000;
  }
  .v-tab-na {
    background: #f0f0f0;
    color: #000;
  }
  .v-tab-count {
    display: block;
    font-family: 'Archivo Black', sans-serif;
    font-size: 28px;
    line-height: 1;
    letter-spacing: -1px;
  }
  .v-tab-label {
    display: block;
    font-family: 'Space Mono', monospace;
    font-size: 8px;
    letter-spacing: 1.2px;
    text-transform: uppercase;
    margin-top: 5px;
    opacity: 0.75;
  }
`,vr=({counts:t,active:e,onChange:s})=>{const r=[{id:"all",count:t.total,label:"All"},{id:"fatal",count:t.killers,label:"Fatal"},{id:"warn",count:t.warns,label:"Warn"},{id:"pass",count:t.passes,label:"Pass"},{id:"na",count:t.unknowns,label:"N/A"}];return i.jsx("div",{className:"autoverdict-filter-tabs",children:r.map(({id:a,count:n,label:o})=>i.jsxs("button",{className:`v-tab v-tab-${a}${e===a?" is-active":""}`,onClick:()=>s(a),type:"button",children:[i.jsx("span",{className:"v-tab-count",children:n}),i.jsx("span",{className:"v-tab-label",children:o})]},a))})};function yr(t){const e=t.match(/\d+/);return e?String(Number(e[0])).padStart(2,"0"):"??"}const br=`
@keyframes autoverdict-stagger-in {
  from { opacity: 0; transform: translateY(6px); }
  to   { opacity: 1; transform: translateY(0); }
}

.rc-stagger {
  animation: autoverdict-stagger-in 300ms ease-out both;
}

.rc-root {
  display: grid;
  grid-template-columns: 28px 1fr auto;
  gap: 10px;
  padding: 11px 14px;
  border-bottom: 1px solid #000;
  align-items: start;
}

.rc-root--killer,
.rc-root--fail {
  background: #ff2d4b;
  color: #fff;
}

.rc-root--warn {
  background: #e4ff00;
  color: #000;
}

.rc-root--pass {
  background: #fff;
  color: #000;
}

.rc-root--unknown {
  background: #fafafa;
  color: #000;
}

.rc-number {
  font-family: 'Archivo Black', sans-serif;
  font-size: 16px;
  line-height: 1.1;
}

.rc-title {
  font-family: 'Archivo Black', sans-serif;
  font-size: 14px;
  letter-spacing: -0.2px;
  line-height: 1.1;
  text-transform: uppercase;
}

.rc-message {
  font-family: 'Inter Tight', sans-serif;
  font-size: 11px;
  line-height: 1.5;
  font-weight: 400;
  margin-top: 4px;
}

.rc-tags {
  display: flex;
  gap: 4px;
  margin-top: 6px;
}

.rc-tag {
  font-family: 'Space Mono', monospace;
  font-size: 8px;
  padding: 2px 5px;
  border: 1px solid currentColor;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.rc-ack {
  font-family: 'Space Mono', monospace;
  font-size: 8px;
  background: transparent;
  color: #fff;
  border: 1px solid #fff;
  padding: 4px 10px;
  cursor: pointer;
  margin-top: 6px;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.rc-mark {
  font-family: 'Archivo Black', sans-serif;
  font-size: 22px;
  line-height: 1;
  padding-top: 2px;
}
`,_r={killer:["KILLER","DO NOT BUY"],warn:["WARN"],unknown:["N/A"]},kr={killer:"✕",fail:"✕",warn:"▲",pass:"✓",unknown:"?"},wr=({result:t,index:e,onAck:s})=>{var c;const r=_r[t.severity]??[],a=kr[t.severity],n=((c=je[t.ruleId])==null?void 0:c.shortTitle)??t.title,o=yr(t.ruleId);return i.jsxs("div",{className:`rc-root rc-root--${t.severity} rc-stagger`,style:{animationDelay:`${e*50}ms`},children:[i.jsx("div",{className:"rc-number",children:o}),i.jsxs("div",{children:[i.jsx("div",{className:"rc-title",children:n}),i.jsx("div",{className:"rc-message",children:t.message}),r.length>0&&i.jsx("div",{className:"rc-tags",children:r.map(l=>i.jsx("span",{className:"rc-tag",children:l},l))}),s&&t.acknowledgeable&&t.severity==="killer"&&i.jsx("button",{className:"rc-ack",onClick:()=>s(t.ruleId),children:"IGNORE 7D"})]}),i.jsx("div",{className:"rc-mark",children:a})]})},Nr={"차량 상태":"Condition",이력:"History",사고:"Accident",가격:"Price",투명성:"Disclosure"},jr=`
.rg-root {
  border-bottom: 3px solid #000;
}

.rg-header {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  padding: 9px 14px 7px;
  background: #000;
  color: #fff;
  font-family: 'Space Mono', monospace;
  font-size: 9px;
  letter-spacing: 2px;
  text-transform: uppercase;
  font-weight: 700;
}

.rg-count {
  font-family: 'Archivo Black', sans-serif;
  font-size: 12px;
  letter-spacing: 0;
  text-transform: none;
}

.rg-count--danger { color: #ff2d4b; }
.rg-count--good   { color: #e4ff00; }
.rg-count--normal { color: #fff; }
`,Sr=({category:t,rules:e,startIndex:s,onAck:r})=>{const a=e.length,n=e.filter(d=>d.severity==="pass").length,o=At(n,a),c=dr(o),l=c==="bad"?"rg-count rg-count--danger":c==="good"?"rg-count rg-count--good":"rg-count rg-count--normal";return i.jsxs("div",{className:"rg-root",children:[i.jsxs("div",{className:"rg-header",children:[i.jsxs("span",{children:["◼ ",t," / ",Nr[t]]}),i.jsxs("span",{className:l,children:[n," / ",a]})]}),i.jsx("div",{children:e.map((d,m)=>i.jsx(wr,{result:d,index:s+m,onAck:r},d.ruleId))})]})},Ar=`
.ab-root {
  display: grid;
  grid-template-columns: 1fr 1fr;
  border-top: 4px double #000;
}

.ab-btn {
  padding: 14px;
  font-family: 'Archivo Black', sans-serif;
  font-size: 13px;
  letter-spacing: -0.2px;
  text-align: center;
  text-transform: uppercase;
  cursor: pointer;
  border: none;
}

.ab-btn--refresh {
  background: #fff;
  color: #000;
  border-right: 2px solid #000;
}

.ab-btn--ai {
  background: #000;
  color: #fff;
}
`,Cr=({onRefresh:t,onGoToAi:e})=>i.jsxs("div",{className:"ab-root",children:[i.jsx("button",{className:"ab-btn ab-btn--refresh",onClick:t,children:"↻ 재평가"}),i.jsx("button",{className:"ab-btn ab-btn--ai",onClick:e,children:"AI 평가 →"})]}),Tr=`
.save-bar {
  display: flex;
  justify-content: center;
  border-bottom: 4px solid #000;
}
.save-bar-btn {
  width: 100%;
  padding: 12px;
  font-family: 'Archivo Black', sans-serif;
  font-size: 13px;
  letter-spacing: 0.5px;
  text-align: center;
  text-transform: uppercase;
  cursor: pointer;
  border: none;
  transition: background 0.15s;
}
.save-bar-btn--unsaved {
  background: #fff;
  color: #000;
}
.save-bar-btn--unsaved:hover {
  background: #f0f0f0;
}
.save-bar-btn--saved {
  background: #CCFF00;
  color: #000;
}
`,Er=({saved:t,onToggle:e})=>i.jsx("div",{className:"save-bar",children:i.jsx("button",{className:`save-bar-btn ${t?"save-bar-btn--saved":"save-bar-btn--unsaved"}`,onClick:e,children:t?"★ SAVED":"☆ SAVE"})}),ut={start:"평가를 시작합니다...",fetching_reports:"이력·진단·사고 리포트 수집 중..."},Ir=`
.lv-container {
  ${gt}
}
.lv-title {
  font-family: 'Archivo Black', sans-serif;
  font-size: 64px;
  line-height: 0.85;
  letter-spacing: -2px;
  color: #000;
}
.lv-stage {
  font-family: 'Space Mono', monospace;
  font-size: 9px;
  letter-spacing: 1.5px;
  text-transform: uppercase;
  opacity: 0.7;
  color: #000;
}
.lv-carid {
  font-family: 'Space Mono', monospace;
  font-size: 9px;
  opacity: 0.4;
  color: #000;
}
.lv-btn {
  font-family: 'Archivo Black', sans-serif;
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: -0.3px;
  color: #000;
  border: 4px solid #000;
  padding: 10px 20px;
  cursor: pointer;
}
`,ft=({stage:t,carId:e,onRefresh:s})=>{const[r,a]=x.useState(!1);x.useEffect(()=>{a(!1);const o=setTimeout(()=>a(!0),25e3);return()=>clearTimeout(o)},[t,e]);const n=r?"응답이 늦어요. 엔카 로딩이 느리거나 페이지가 아직 준비 중일 수 있어요.":t&&t in ut?ut[t]:t?t.toUpperCase():"FETCHING REPORT";return i.jsxs("div",{className:"lv-container",children:[i.jsx("div",{className:"lv-title",children:r?"STUCK?":"LOADING"}),i.jsx("div",{className:"lv-stage",children:n}),e&&i.jsxs("div",{className:"lv-carid",children:["CARID · ",e]}),i.jsx("button",{className:"lv-btn",style:{background:r?"#e4ff00":"#fff"},onClick:s,children:"MANUAL REFETCH"})]})},Or=`
.sc-root {
  border: 3px solid #000;
  border-bottom: none;
  padding: 12px 14px;
  cursor: pointer;
  position: relative;
  transition: background 0.1s;
}
.sc-root:last-child {
  border-bottom: 3px solid #000;
}
.sc-root:hover {
  background: #f5f5f5;
}
.sc-root[data-selected='true'] {
  background: #CCFF00;
}
.sc-top {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  margin-bottom: 4px;
}
.sc-verdict {
  font-family: 'Archivo Black', sans-serif;
  font-size: 14px;
}
.sc-specs {
  font-family: 'Space Mono', monospace;
  font-size: 9px;
  letter-spacing: 1px;
  text-transform: uppercase;
}
.sc-title {
  font-family: 'Inter Tight', sans-serif;
  font-size: 13px;
  font-weight: 600;
  margin-bottom: 2px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.sc-price {
  font-family: 'Archivo Black', sans-serif;
  font-size: 15px;
  margin-bottom: 6px;
}
.sc-bottom {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 6px;
}
.sc-counts {
  font-family: 'Space Mono', monospace;
  font-size: 9px;
  letter-spacing: 0.5px;
}
.sc-actions {
  display: flex;
  gap: 8px;
}
.sc-action-btn {
  font-family: 'Space Mono', monospace;
  font-size: 9px;
  letter-spacing: 1px;
  text-transform: uppercase;
  padding: 4px 8px;
  border: 2px solid #000;
  background: #fff;
  color: #000;
  cursor: pointer;
  text-decoration: none;
}
.sc-action-btn:hover {
  background: #000;
  color: #fff;
}
.sc-checkbox {
  position: absolute;
  top: 12px;
  left: 14px;
  width: 16px;
  height: 16px;
  accent-color: #000;
}
`,Rr=({data:t,selected:e,onSelect:s,onView:r,onDelete:a})=>{const n=o=>{const c=o.target;c.tagName==="INPUT"||c.tagName==="BUTTON"||r(t.carId)};return i.jsxs("div",{className:"sc-root","data-selected":e,onClick:n,children:[i.jsx("input",{type:"checkbox",className:"sc-checkbox",checked:e,onChange:()=>s(t.carId)}),i.jsxs("div",{className:"sc-top",style:{paddingLeft:24},children:[i.jsxs("span",{className:"sc-verdict",style:{color:Lt[t.verdict]},children:["[",t.score,"] ",t.verdict]}),i.jsxs("span",{className:"sc-specs",children:[t.year??"—"," · ",zt(t.mileageKm)]})]}),i.jsxs("div",{className:"sc-title",style:{paddingLeft:24},children:[t.title||"—",t.fuelType?` ${t.fuelType}`:""]}),i.jsx("div",{className:"sc-price",style:{paddingLeft:24},children:Vt(t.priceWon)}),i.jsxs("div",{className:"sc-bottom",style:{paddingLeft:24},children:[i.jsxs("span",{className:"sc-counts",children:["치명 ",t.killerCount," · 주의 ",t.warnCount]}),i.jsxs("div",{className:"sc-actions",children:[i.jsx("a",{className:"sc-action-btn",href:t.url,target:"_blank",rel:"noopener noreferrer",onClick:o=>o.stopPropagation(),children:"엔카 →"}),i.jsx("button",{className:"sc-action-btn",onClick:o=>{o.stopPropagation(),a(t.carId)},children:"삭제"})]})]})]})},Mr=4,pt=10,$r=`
${Or}
.sl-root {
  padding: 0;
}
.sl-empty {
  padding: 32px 16px;
  text-align: center;
  font-family: 'Space Mono', monospace;
  font-size: 10px;
  letter-spacing: 1.5px;
  text-transform: uppercase;
  color: #666;
}
.sl-compare-float {
  position: sticky;
  bottom: 0;
  padding: 12px;
  background: #000;
  text-align: center;
}
.sl-compare-btn {
  font-family: 'Archivo Black', sans-serif;
  font-size: 14px;
  text-transform: uppercase;
  color: #000;
  background: #CCFF00;
  border: none;
  padding: 12px 32px;
  cursor: pointer;
  letter-spacing: 0.5px;
}
.sl-compare-btn:disabled {
  opacity: 0.4;
  cursor: not-allowed;
}
.sl-count {
  padding: 8px 12px;
  font-family: 'Space Mono', monospace;
  font-size: 9px;
  letter-spacing: 1.5px;
  text-transform: uppercase;
  color: #666;
  text-align: right;
}
.sl-count--full {
  color: #FF3B30;
}
`,Et=({onViewCar:t,refreshKey:e})=>{const[s,r]=x.useState([]),[a,n]=x.useState(!0),[o,c]=x.useState(new Set),l=x.useCallback(async()=>{try{const g=await chrome.runtime.sendMessage({type:"GET_SAVED_LIST"});r(g??[])}catch{r([])}n(!1)},[]);x.useEffect(()=>{l()},[l,e]);const d=x.useCallback(async g=>{await chrome.runtime.sendMessage({type:"UNSAVE_CAR",carId:g}).catch(()=>{}),r(E=>E.filter(_=>_.carId!==g)),c(E=>{const _=new Set(E);return _.delete(g),_})},[]),m=x.useCallback(g=>{c(E=>{const _=new Set(E);return _.has(g)?_.delete(g):_.size<Mr&&_.add(g),_})},[]),k=x.useCallback(()=>{if(o.size<2)return;const g=Array.from(o).join(","),E=chrome.runtime.getURL(`src/compare/compare.html?ids=${g}`);chrome.tabs.create({url:E})},[o]);if(a)return i.jsx("div",{className:"sl-empty",children:"LOADING..."});if(s.length===0)return i.jsxs("div",{className:"sl-empty",children:["저장된 매물이 없습니다.",i.jsx("br",{}),"차량 페이지에서 SAVE 버튼을 눌러 추가하세요."]});const j=s.map(g=>({carId:g.carId,url:g.url,title:g.title,year:g.year,mileageKm:g.mileageKm,priceWon:g.priceWon,fuelType:g.fuelType,score:g.report.score,verdict:g.report.verdict,killerCount:g.report.killers.length,warnCount:g.report.warns.length})),b=s.length>=pt;return i.jsxs("div",{className:"sl-root",children:[i.jsxs("div",{className:`sl-count${b?" sl-count--full":""}`,children:[s.length," / ",pt]}),j.map(g=>i.jsx(Rr,{data:g,selected:o.has(g.carId),onSelect:m,onView:t,onDelete:d},g.carId)),o.size>=2&&i.jsx("div",{className:"sl-compare-float",children:i.jsxs("button",{className:"sl-compare-btn",onClick:k,children:["COMPARE ",o.size]})})]})},Lr=`
${$r}
.hp-root {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

/* ── Header ── */
.hp-header {
  padding: 32px 20px 24px;
  border-bottom: 3px solid #000;
  text-align: center;
}
.hp-brand {
  font-family: 'Archivo Black', sans-serif;
  font-size: 28px;
  letter-spacing: -1px;
  line-height: 1;
  color: #000;
}
.hp-sub {
  font-family: 'Space Mono', monospace;
  font-size: 9px;
  letter-spacing: 2px;
  text-transform: uppercase;
  color: #666;
  margin-top: 6px;
}

/* ── Tab bar ── */
.hp-tabs {
  display: grid;
  grid-template-columns: 1fr 1fr;
  border-bottom: 3px solid #000;
}
.hp-tab {
  padding: 10px 0;
  font-family: 'Space Mono', monospace;
  font-size: 10px;
  letter-spacing: 1.5px;
  text-transform: uppercase;
  text-align: center;
  cursor: pointer;
  border: none;
  border-right: 3px solid #000;
  background: #fff;
  color: #000;
  transition: background 0.1s, color 0.1s;
}
.hp-tab:last-child {
  border-right: none;
}
.hp-tab[data-active='true'] {
  background: #000;
  color: #fff;
}

/* ── Home content ── */
.hp-guide {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 35px;
  padding: 100px 20px 32px 0px;
  text-align: center;
}
/* ── CSS Car ── */
.hp-car {
  position: relative;
  width: 160px;
  height: 80px;
  margin: 0 auto;
}
.hp-car-roof {
  position: absolute;
  top: 0;
  left: 37px;
  width: 86px;
  height: 32px;
  background: #000;
  clip-path: polygon(12% 100%, 88% 100%, 72% 0%, 28% 0%);
}
.hp-car-body {
  position: absolute;
  top: 27px;
  left: 0;
  width: 160px;
  height: 37px;
  background: #000;
  border-radius: 3px;
}
.hp-car-window {
  position: absolute;
  top: 4px;
  width: 30px;
  height: 18px;
  background: #CCFF00;
}
.hp-car-window--l {
  left: 40px;
  clip-path: polygon(20% 0%, 100% 0%, 100% 100%, 0% 100%);
}
.hp-car-window--r {
  left: 74px;
  clip-path: polygon(0% 0%, 80% 0%, 100% 100%, 0% 100%);
}
.hp-car-wheel {
  position: absolute;
  bottom: 0;
  width: 26px;
  height: 26px;
  background: #333;
  border: 3px solid #000;
  border-radius: 50%;
}
.hp-car-wheel::after {
  content: '';
  position: absolute;
  top: 50%;
  left: 50%;
  width: 8px;
  height: 8px;
  background: #CCFF00;
  border-radius: 50%;
  transform: translate(-50%, -50%);
}
.hp-car-wheel--l {
  left: 20px;
}
.hp-car-wheel--r {
  right: 20px;
}
.hp-start-btn {
  font-family: 'Archivo Black', sans-serif;
  font-size: 16px;
  letter-spacing: 0.5px;
  color: #000;
  background: #CCFF00;
  border: 3px solid #000;
  padding: 12px 32px;
  cursor: pointer;
  text-transform: uppercase;
  transition: background 0.1s, color 0.1s;
}
.hp-start-btn:hover {
  background: #000;
  color: #CCFF00;
}
.hp-steps {
  display: flex;
  flex-direction: column;
  gap: 8px;
  text-align: left;
  width: 100%;
  max-width: 280px;
}
.hp-step {
  display: flex;
  gap: 10px;
  align-items: baseline;
  font-family: 'Space Mono', monospace;
  font-size: 10px;
  letter-spacing: 0.5px;
  color: #000;
}
.hp-step-num {
  font-family: 'Archivo Black', sans-serif;
  font-size: 14px;
  color: #CCFF00;
  background: #000;
  width: 24px;
  height: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.hp-note {
  font-family: 'Space Mono', monospace;
  font-size: 9px;
  letter-spacing: 1px;
  color: #999;
  margin-top: 4px;
}

/* ── MyList section ── */
.hp-mylist {
  flex: 1;
}
`,zr=({savedListKey:t=0})=>{const[e,s]=x.useState("home"),r=a=>{chrome.runtime.sendMessage({type:"GET_SAVED_ONE",carId:a}).then(n=>{n!=null&&n.url&&chrome.tabs.create({url:n.url})}).catch(()=>{})};return i.jsxs("div",{className:"hp-root",children:[i.jsxs("div",{className:"hp-header",children:[i.jsx("div",{className:"hp-brand",children:"AUTOVERDICT"}),i.jsx("div",{className:"hp-sub",children:"중고차 체크리스트 · 12 Rules"})]}),i.jsxs("div",{className:"hp-tabs",children:[i.jsx("button",{className:"hp-tab","data-active":e==="home",onClick:()=>s("home"),children:"HOME"}),i.jsx("button",{className:"hp-tab","data-active":e==="mylist",onClick:()=>s("mylist"),children:"★ MY LIST"})]}),e==="home"&&i.jsxs("div",{className:"hp-guide",children:[i.jsxs("div",{className:"hp-car",children:[i.jsx("div",{className:"hp-car-roof"}),i.jsxs("div",{className:"hp-car-body",children:[i.jsx("div",{className:"hp-car-window hp-car-window--l"}),i.jsx("div",{className:"hp-car-window hp-car-window--r"})]}),i.jsx("div",{className:"hp-car-wheel hp-car-wheel--l"}),i.jsx("div",{className:"hp-car-wheel hp-car-wheel--r"})]}),i.jsx("button",{className:"hp-start-btn",onClick:()=>chrome.tabs.create({url:"https://encar.com"}),children:"시작하기 →"}),i.jsxs("div",{className:"hp-steps",children:[i.jsxs("div",{className:"hp-step",children:[i.jsx("span",{className:"hp-step-num",children:"1"}),i.jsx("span",{children:"엔카 에서 매물 검색"})]}),i.jsxs("div",{className:"hp-step",children:[i.jsx("span",{className:"hp-step-num",children:"2"}),i.jsx("span",{children:"매물 상세 페이지 클릭"})]}),i.jsxs("div",{className:"hp-step",children:[i.jsx("span",{className:"hp-step-num",children:"3"}),i.jsx("span",{children:"자동 평가 결과 확인"})]})]}),i.jsx("div",{className:"hp-note",children:"* 보험이력·소유자 변경 정보는 엔카 로그인 필요"})]}),e==="mylist"&&i.jsx("div",{className:"hp-mylist",children:i.jsx(Et,{onViewCar:r,refreshKey:t})})]})},Vr=`
.ev-container {
  position: relative;
  ${gt}
}
.ev-dot {
  position: absolute;
  top: 12px;
  right: 12px;
  width: 16px;
  height: 16px;
  background: #ff2d4b;
  border: 3px solid #000;
}
.ev-title {
  font-family: 'Archivo Black', sans-serif;
  font-size: 64px;
  line-height: 0.85;
  letter-spacing: -2px;
  color: #000;
}
.ev-reason {
  font-family: 'Inter Tight', sans-serif;
  font-size: 13px;
  line-height: 1.5;
  color: #000;
}
.ev-btn {
  font-family: 'Archivo Black', sans-serif;
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: -0.3px;
  background: #e4ff00;
  color: #000;
  border: 4px solid #000;
  padding: 10px 20px;
  cursor: pointer;
}
`,Zr=({reason:t,onRetry:e})=>{const s=t==="watchdog_timeout"?"엔카 응답이 22초 내에 오지 않았어요. 잠시 후 다시 시도해 주세요.":t;return i.jsxs("div",{className:"ev-container",children:[i.jsx("div",{className:"ev-dot"}),i.jsx("div",{className:"ev-title",children:"ERROR"}),i.jsx("div",{className:"ev-reason",children:s}),i.jsx("button",{className:"ev-btn",onClick:e,children:"↻ RETRY"})]})},Dr=Zt+er+nr+Tr+cr+fr+xr+jr+br+Ar+Ir+Lr+Vr+Ks,Pr=t=>({total:t.length,killers:t.filter(e=>e.severity==="killer").length,warns:t.filter(e=>e.severity==="warn").length,passes:t.filter(e=>e.severity==="pass").length,unknowns:t.filter(e=>e.severity==="unknown").length}),Br=(t,e)=>e==="all"?t:e==="fatal"?t.filter(s=>s.severity==="killer"||s.severity==="fail"):e==="warn"?t.filter(s=>s.severity==="warn"):e==="pass"?t.filter(s=>s.severity==="pass"):t.filter(s=>s.severity==="unknown"),Ur=t=>{var s;const e=new Map;for(const r of t){const a=((s=je[r.ruleId])==null?void 0:s.category)??"투명성",n=e.get(a)??[];n.push(r),e.set(a,n)}return mt.filter(r=>e.has(r)).map(r=>[r,e.get(r)])},re=({children:t})=>i.jsxs("div",{style:{minHeight:"100vh",background:"#ffffff",color:"#000000",fontFamily:"'Inter Tight', sans-serif"},children:[i.jsx("style",{children:Dr}),t]}),Fr=()=>{const{active:t,row:e,loading:s,progressStage:r,loadError:a,refresh:n,ack:o}=Ys(),[c,l]=x.useState("checklist"),[d,m]=x.useState("all"),{savedState:k,savedListKey:j,viewingSavedCarId:b,savedRow:g,handleToggleSave:E,handleViewSavedCar:_,clearOverride:I}=Js(e),O=async F=>{!b&&e&&e.carId===F||(await _(F),l("checklist"))},w=b?g:e,A=x.useMemo(()=>w?Pr(w.report.results):{total:0,killers:0,warns:0,passes:0,unknowns:0},[w]),U=x.useMemo(()=>w?Br(w.report.results,d):[],[w,d]),It=x.useMemo(()=>Ur(U),[U]);if(!t||!Bt(t.url))return i.jsx(re,{children:i.jsx(zr,{savedListKey:j})});const Ot=!!(e&&t.carId&&t.carId!==e.carId);if(a)return i.jsx(re,{children:i.jsx(Zr,{reason:a,onRetry:n})});if(s||r!==null||!e||Ot)return i.jsx(re,{children:i.jsx(ft,{stage:r,carId:t.carId??void 0,onRefresh:n})});if(!w)return i.jsx(re,{children:i.jsx(ft,{stage:null,carId:b??void 0,onRefresh:n})});let Le=0;const ze=It.map(([F,me])=>{const Se=Le;return Le+=me.length,{cat:F,rules:me,startIndex:Se}});return i.jsxs(re,{children:[b&&i.jsx("button",{style:{width:"100%",padding:"10px",fontFamily:"'Space Mono', monospace",fontSize:"10px",letterSpacing:"1.5px",textTransform:"uppercase",background:"#CCFF00",border:"none",borderBottom:"3px solid #000",cursor:"pointer"},onClick:I,children:"← BACK TO LIVE TAB"}),i.jsx(sr,{score:w.report.score,verdict:w.report.verdict,killers:w.report.killers,warns:w.report.warns}),i.jsx(ir,{parsed:w.parsed,carId:w.carId}),i.jsx(Er,{saved:k,onToggle:E}),i.jsx(lr,{tab:c,onChange:l,disabledTabs:b?["ai"]:[]}),c==="checklist"&&i.jsxs(i.Fragment,{children:[i.jsx(gr,{results:w.report.results}),i.jsx(vr,{counts:A,active:d,onChange:m}),ze.length===0?i.jsx("div",{style:{padding:24,textAlign:"center",fontFamily:"'Space Mono', monospace",fontSize:10,letterSpacing:2,textTransform:"uppercase",borderBottom:"3px solid #000"},children:"NOTHING MATCHES FILTER"}):ze.map(({cat:F,rules:me,startIndex:Se})=>i.jsx(Sr,{category:F,rules:me,startIndex:Se,onAck:o},F)),i.jsx(Cr,{onRefresh:n,onGoToAi:()=>l("ai")})]}),c==="ai"&&i.jsx(Hs,{parsed:e.parsed,facts:e.facts,report:e.report}),c==="mylist"&&i.jsx(Et,{onViewCar:O,refreshKey:j})]})},ht=document.getElementById("app");ht&&Dt(ht).render(i.jsx(Fr,{}));
