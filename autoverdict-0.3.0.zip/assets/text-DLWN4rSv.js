const r=(t,e=".")=>!t||typeof t!="string"||t.length<6?null:`${t.slice(0,4)}${e}${t.slice(4,6)}`;export{r as f};
