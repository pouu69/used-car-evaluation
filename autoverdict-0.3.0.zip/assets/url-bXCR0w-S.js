const a=/\/cars\/detail\/(\d+)/,c=/^https:\/\/fem\.encar\.com\/cars\/detail\//,s=t=>{var e;return t?((e=a.exec(t))==null?void 0:e[1])??null:null},n=t=>!!t&&c.test(t);export{s as e,n as i};
